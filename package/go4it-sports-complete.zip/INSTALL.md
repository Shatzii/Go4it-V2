
# Go4It Sports Installation Guide

## Deployment to Your Server

Follow these steps to deploy the application to your server:

1. Upload and extract this package to your server:
   ```bash
   scp go4it-sports-complete.zip user@your-server:/var/www/
   ssh user@your-server
   cd /var/www/
   unzip go4it-sports-complete.zip -d go4itsports
   cd go4itsports
   ```

2. Set up the directory structure:
   ```bash
   mkdir -p client server shared backup deploy
   cp -r client/* client/
   cp -r server/* server/
   cp -r shared/* shared/
   cp -r deploy/* deploy/
   chmod -R 755 .
   chmod +x deploy/deploy.sh
   ```

3. Install dependencies:
   ```bash
   cd server
   npm install
   ```

4. Configure environment variables:
   ```bash
   cp .env.example .env
   nano .env
   # Set your database connection and API keys
   ```

5. Start the application with PM2:
   ```bash
   npm install -g pm2
   pm2 start deploy/ecosystem.config.js
   pm2 save
   pm2 startup
   ```

6. Configure Nginx:
   ```bash
   # Create an Nginx configuration file for your domain
   nano /etc/nginx/sites-available/yourdomain.com
   # Add the configuration provided below
   
   # Enable the site
   ln -s /etc/nginx/sites-available/yourdomain.com /etc/nginx/sites-enabled/
   nginx -t
   systemctl reload nginx
   ```

7. Set up SSL with Certbot:
   ```bash
   apt-get update
   apt-get install -y certbot python3-certbot-nginx
   certbot --nginx -d yourdomain.com -d www.yourdomain.com
   ```

## Nginx Configuration Example

```
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;
    
    # Redirect HTTP to HTTPS
    location / {
        return 301 https://$host$request_uri;
    }
}

server {
    listen 443 ssl;
    server_name yourdomain.com www.yourdomain.com;
    
    # SSL configuration will be added by Certbot
    
    # Client files
    root /var/www/go4itsports/client;
    index index.html;
    
    # Handle SPA routing
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    # API endpoints
    location /api/ {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## Troubleshooting

If you encounter any issues:

1. Check Nginx logs: `tail -f /var/log/nginx/error.log`
2. Check PM2 logs: `pm2 logs`
3. Make sure all environment variables are properly set
4. Verify permissions: `chmod -R 755 /var/www/go4itsports`

For additional support, please contact support@go4itsports.org
