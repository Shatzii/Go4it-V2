
module.exports = {
  apps: [{
    name: "go4itsports",
    script: "/var/www/go4itsports/server/index.js",
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: "1G",
    env: {
      NODE_ENV: "production",
      PORT: 5000
    }
  }]
};
