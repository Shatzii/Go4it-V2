#!/bin/bash

# ShatziiOS CEO Dashboard Deployment Script
# This script packages and deploys the CEO Dashboard to the specified server

# Configuration
TARGET_SERVER="18.188.245.209"
TARGET_USERNAME="shotziadmin"
TARGET_PATH="/var/www/go4itsports/pharaoh/ceo_dashboard"
PACKAGE_NAME="ceo-dashboard.tar.gz"

# Print banner
echo "==================================================="
echo "  ShatziiOS CEO Dashboard Deployment"
echo "  Target: $TARGET_SERVER:$TARGET_PATH"
echo "==================================================="

# Check if we're in the right directory
if [ ! -f "index.html" ] || [ ! -d "css" ] || [ ! -d "js" ]; then
    echo "Error: This script must be run from the CEO Dashboard directory"
    echo "Please cd to the ceo-dashboard directory first"
    exit 1
fi

# Create archive
echo "Creating deployment package..."
tar -czf ../$PACKAGE_NAME .

echo "Package created: ../$PACKAGE_NAME"
echo ""

# Deploy instructions
echo "Deployment Instructions:"
echo "-----------------------"
echo "1. Transfer the package to the server:"
echo "   scp ../$PACKAGE_NAME $TARGET_USERNAME@$TARGET_SERVER:/tmp/"
echo ""
echo "2. SSH into the server:"
echo "   ssh $TARGET_USERNAME@$TARGET_SERVER"
echo ""
echo "3. Execute the following commands on the server:"
echo "   sudo mkdir -p $TARGET_PATH"
echo "   sudo tar -xzf /tmp/$PACKAGE_NAME -C $TARGET_PATH"
echo "   sudo chown -R www-data:www-data $TARGET_PATH"
echo "   sudo chmod -R 755 $TARGET_PATH"
echo ""
echo "4. Configure your web server (Apache/Nginx) to serve from $TARGET_PATH"
echo ""
echo "==================================================="
echo "Deployment package is ready at ../$PACKAGE_NAME"
echo "==================================================="