/**
 * ShatziiOS CEO Dashboard
 * Main JavaScript for dashboard functionality
 */

document.addEventListener('DOMContentLoaded', function() {
  // Initialize charts
  initEngagementChart();
  
  // Set up event listeners
  setupEventListeners();
  
  // Initialize dashboard data
  refreshDashboardData();
});

/**
 * Initialize the student engagement chart
 */
function initEngagementChart() {
  const ctx = document.getElementById('engagementChart').getContext('2d');
  
  // Sample data for the chart
  const data = {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [
      {
        label: 'Elementary',
        data: [85, 87, 92, 90, 88, 75, 73],
        backgroundColor: 'rgba(255, 87, 34, 0.2)',
        borderColor: 'rgba(255, 87, 34, 1)',
        borderWidth: 2,
        tension: 0.4
      },
      {
        label: 'Middle School',
        data: [80, 82, 85, 87, 84, 70, 68],
        backgroundColor: 'rgba(255, 152, 0, 0.2)',
        borderColor: 'rgba(255, 152, 0, 1)',
        borderWidth: 2,
        tension: 0.4
      },
      {
        label: 'High School',
        data: [78, 80, 82, 85, 83, 65, 63],
        backgroundColor: 'rgba(33, 150, 243, 0.2)',
        borderColor: 'rgba(33, 150, 243, 1)',
        borderWidth: 2,
        tension: 0.4
      },
      {
        label: 'Law School',
        data: [90, 92, 93, 95, 94, 85, 83],
        backgroundColor: 'rgba(156, 39, 176, 0.2)',
        borderColor: 'rgba(156, 39, 176, 1)',
        borderWidth: 2,
        tension: 0.4
      }
    ]
  };
  
  const config = {
    type: 'line',
    data: data,
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'top',
        }
      },
      scales: {
        y: {
          beginAtZero: false,
          min: 50,
          max: 100,
          title: {
            display: true,
            text: 'Engagement %'
          }
        }
      }
    }
  };
  
  // Create the chart
  window.engagementChart = new Chart(ctx, config);
}

/**
 * Set up event listeners for dashboard interactions
 */
function setupEventListeners() {
  // Set up filter buttons for the chart
  const filterButtons = document.querySelectorAll('.chart-filter');
  filterButtons.forEach(button => {
    button.addEventListener('click', function() {
      // Remove active class from all buttons
      filterButtons.forEach(btn => btn.classList.remove('active'));
      // Add active class to clicked button
      this.classList.add('active');
      
      // Update chart data based on selected filter
      updateChartData(this.textContent.trim());
    });
  });
  
  // Set up action buttons
  const actionButtons = document.querySelectorAll('.section-action-button');
  actionButtons.forEach(button => {
    button.addEventListener('click', function() {
      if (this.textContent.trim() === 'Generate Report') {
        alert('Generating report for all schools...');
      } else if (this.textContent.trim() === 'Add School') {
        alert('Opening school creation form...');
      }
    });
  });
  
  // Set up action menus in the table
  const actionMenus = document.querySelectorAll('.action-menu');
  actionMenus.forEach(menu => {
    menu.addEventListener('click', function() {
      const schoolName = this.closest('tr').querySelector('.school-details h3').textContent;
      alert(`Actions for ${schoolName}:\n- View Details\n- Edit School\n- View Analytics\n- Manage Staff`);
    });
  });
}

/**
 * Update chart data based on selected time filter
 * @param {string} timeFrame - The selected time frame (Day, Week, Month, Year)
 */
function updateChartData(timeFrame) {
  console.log(`Updating chart data for time frame: ${timeFrame}`);
  
  // In a real application, this would fetch new data based on the time frame
  // For demo purposes, we'll just modify the existing data
  
  let labels = [];
  let dataSets = [];
  
  switch(timeFrame) {
    case 'Day':
      labels = ['9AM', '10AM', '11AM', '12PM', '1PM', '2PM', '3PM', '4PM', '5PM'];
      dataSets = [
        [88, 90, 92, 85, 87, 89, 91, 93, 90],
        [83, 85, 87, 80, 82, 84, 86, 88, 85],
        [81, 83, 85, 78, 80, 82, 84, 86, 83],
        [92, 94, 95, 90, 91, 93, 94, 96, 94]
      ];
      break;
    case 'Week':
      // Keep existing data (already set up)
      return;
    case 'Month':
      labels = ['Week 1', 'Week 2', 'Week 3', 'Week 4'];
      dataSets = [
        [87, 89, 92, 94],
        [82, 84, 87, 89],
        [80, 82, 85, 87],
        [91, 93, 95, 96]
      ];
      break;
    case 'Year':
      labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      dataSets = [
        [82, 84, 86, 88, 90, 92, 90, 88, 89, 91, 93, 95],
        [77, 79, 81, 83, 85, 87, 85, 83, 84, 86, 88, 90],
        [75, 77, 79, 81, 83, 85, 83, 81, 82, 84, 86, 88],
        [86, 88, 90, 92, 94, 96, 94, 92, 93, 95, 97, 98]
      ];
      break;
  }
  
  if (labels.length > 0) {
    window.engagementChart.data.labels = labels;
    
    // Update dataset values
    for (let i = 0; i < Math.min(dataSets.length, window.engagementChart.data.datasets.length); i++) {
      window.engagementChart.data.datasets[i].data = dataSets[i];
    }
    
    window.engagementChart.update();
  }
}

/**
 * Refresh dashboard data - in a real application, this would fetch
 * fresh data from the server
 */
function refreshDashboardData() {
  console.log('Refreshing dashboard data...');
  // This would be an API call in a real application
  
  // For demo purposes, we'll just set up automatic refreshes
  setInterval(() => {
    // Simulate small changes in the chart data
    window.engagementChart.data.datasets.forEach((dataset) => {
      dataset.data = dataset.data.map(value => {
        // Add small random variation (±2%)
        const change = (Math.random() * 4) - 2;
        return Math.max(50, Math.min(100, value + change));
      });
    });
    window.engagementChart.update();
  }, 60000); // Update every minute
}