#!/bin/bash
#
# Sentinel 4.5 Security System - Deployment Script
# 
# This script deploys the Sentinel security system to the target server at 188.245.209.124
# It handles packaging, transferring files, and setting up the system on the server.
#
# Usage: ./deploy-to-188.245.209.124.sh [options]
# Options:
#   --user <username>     SSH username (default: deploy)
#   --key <path>          Path to SSH key (default: ~/.ssh/id_rsa)
#   --port <port>         SSH port (default: 22)
#   --env <env>           Environment (default: production)
#   --help                Show this help message
#

# Exit on error
set -e

# Default values
SSH_USER="deploy"
SSH_KEY="~/.ssh/id_rsa"
SSH_PORT="22"
SERVER_IP="188.245.209.124"
ENVIRONMENT="production"
DEPLOY_DIR="/var/www/sentinel"
LOG_DIR="/var/log/sentinel"
SERVICE_NAME="sentinel"

# Banner
echo "┌─────────────────────────────────────────────────┐"
echo "│                                                 │"
echo "│   🛡️  SENTINEL 4.5 DEPLOYMENT SCRIPT  🛡️         │"
echo "│                                                 │"
echo "│   Target: $SERVER_IP                          │"
echo "│                                                 │"
echo "└─────────────────────────────────────────────────┘"
echo ""

# Parse arguments
while [[ $# -gt 0 ]]; do
  case $1 in
    --user)
      SSH_USER="$2"
      shift 2
      ;;
    --key)
      SSH_KEY="$2"
      shift 2
      ;;
    --port)
      SSH_PORT="$2"
      shift 2
      ;;
    --env)
      ENVIRONMENT="$2"
      shift 2
      ;;
    --help)
      echo "Usage: ./deploy-to-188.245.209.124.sh [options]"
      echo "Options:"
      echo "  --user <username>     SSH username (default: deploy)"
      echo "  --key <path>          Path to SSH key (default: ~/.ssh/id_rsa)"
      echo "  --port <port>         SSH port (default: 22)"
      echo "  --env <env>           Environment (default: production)"
      echo "  --help                Show this help message"
      exit 0
      ;;
    *)
      echo "Unknown option: $1"
      exit 1
      ;;
  esac
done

# SSH command prefix
SSH_CMD="ssh -i $SSH_KEY -p $SSH_PORT $SSH_USER@$SERVER_IP"
SCP_CMD="scp -i $SSH_KEY -P $SSH_PORT"

# Check if we can connect to the server
echo "🔍 Testing SSH connection to $SERVER_IP..."
if ! $SSH_CMD "echo 'Connection successful'"; then
  echo "❌ Failed to connect to $SERVER_IP"
  exit 1
fi
echo "✅ SSH connection successful"

# Build the application
echo "🔨 Building the application..."
npm run build
echo "✅ Build completed"

# Create deployment package
echo "📦 Creating deployment package..."
PACKAGE_NAME="sentinel-4.5-$(date +%Y%m%d%H%M%S).tar.gz"
tar -czf $PACKAGE_NAME \
  --exclude="node_modules" \
  --exclude=".git" \
  --exclude="logs" \
  --exclude="*.log" \
  --exclude="*.tar.gz" \
  dist/ \
  package.json \
  package-lock.json \
  .env.$ENVIRONMENT \
  public/ \
  README.md \
  LICENSE
echo "✅ Created package: $PACKAGE_NAME"

# Create remote directories
echo "📁 Creating remote directories..."
$SSH_CMD "mkdir -p $DEPLOY_DIR $LOG_DIR"
echo "✅ Remote directories created"

# Transfer package to server
echo "📤 Transferring package to server..."
$SCP_CMD $PACKAGE_NAME $SSH_USER@$SERVER_IP:$DEPLOY_DIR/
echo "✅ Package transferred"

# Setup on the server
echo "🔧 Setting up on the server..."
$SSH_CMD "cd $DEPLOY_DIR && tar -xzf $PACKAGE_NAME && rm $PACKAGE_NAME"
$SSH_CMD "cd $DEPLOY_DIR && npm ci --production"
$SSH_CMD "cd $DEPLOY_DIR && cp .env.$ENVIRONMENT .env"
echo "✅ Setup completed"

# Create systemd service
echo "🔄 Creating systemd service..."
SERVICE_FILE=$(cat <<EOF
[Unit]
Description=Sentinel 4.5 Security System
After=network.target

[Service]
Type=simple
User=$SSH_USER
WorkingDirectory=$DEPLOY_DIR
ExecStart=/usr/bin/node $DEPLOY_DIR/dist/index.js
Restart=on-failure
RestartSec=10
StandardOutput=append:$LOG_DIR/sentinel.log
StandardError=append:$LOG_DIR/sentinel-error.log
Environment=NODE_ENV=$ENVIRONMENT
Environment=SERVER_ADDRESS=$SERVER_IP

[Install]
WantedBy=multi-user.target
EOF
)

echo "$SERVICE_FILE" > sentinel.service
$SCP_CMD sentinel.service $SSH_USER@$SERVER_IP:/tmp/
$SSH_CMD "sudo mv /tmp/sentinel.service /etc/systemd/system/$SERVICE_NAME.service"
$SSH_CMD "sudo systemctl daemon-reload"
$SSH_CMD "sudo systemctl enable $SERVICE_NAME"
rm sentinel.service
echo "✅ Systemd service created"

# Start the service
echo "🚀 Starting the service..."
$SSH_CMD "sudo systemctl restart $SERVICE_NAME"
echo "✅ Service started"

# Check service status
echo "🔍 Checking service status..."
$SSH_CMD "sudo systemctl status $SERVICE_NAME --no-pager"

echo ""
echo "✅ Deployment completed successfully!"
echo "📊 Dashboard: https://$SERVER_IP/security-dashboard"
echo "🔒 API: https://$SERVER_IP/api/security"
echo ""
echo "Useful commands on the server:"
echo "  sudo systemctl status $SERVICE_NAME   # Check service status"
echo "  sudo systemctl restart $SERVICE_NAME  # Restart the service"
echo "  sudo systemctl stop $SERVICE_NAME     # Stop the service"
echo "  sudo journalctl -u $SERVICE_NAME -f   # View service logs"
echo ""