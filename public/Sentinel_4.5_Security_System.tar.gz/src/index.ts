/**
 * Sentinel 4.5 Security System
 * 
 * This is the main entry point for the Sentinel security system.
 * It initializes all security modules and provides the API for integration with school platforms.
 */

import path from 'path';
import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import cookieParser from 'cookie-parser';
import fs from 'fs';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Import core modules
import { initializeLogger, logger } from './core/logger';
import { loadConfiguration } from './core/config-loader';
import { setupDatabase } from './core/database';
import { setupSecurityModules } from './core/security-modules';
import { apiRouter } from './api/routes';
import { setupDashboard } from './dashboard/server';
import { errorHandler } from './middleware/error-handler';
import { requestLogger } from './middleware/request-logger';
import { setupIntegrations } from './core/integrations';
import { checkServerHealth } from './utils/health-checker';

// Banner
const displayBanner = () => {
  console.log(`
  ┌─────────────────────────────────────────────────┐
  │                                                 │
  │   🛡️  SENTINEL 4.5 SECURITY SYSTEM  🛡️          │
  │                                                 │
  │   Version: 4.5.0                               │
  │   Environment: ${process.env.NODE_ENV || 'development'}                        │
  │   Server: ${process.env.SENTINEL_HOST || '0.0.0.0'}:${process.env.SENTINEL_PORT || '8080'}                      │
  │                                                 │
  └─────────────────────────────────────────────────┘
  `);
};

// Initialize the application
const initializeApp = async () => {
  try {
    displayBanner();
    
    // Initialize logger
    initializeLogger();
    logger.info('Starting Sentinel 4.5 Security System...');
    
    // Load configuration
    const config = loadConfiguration();
    logger.info('Configuration loaded successfully');
    
    // Setup the Express application
    const app = express();
    
    // Apply basic middleware
    app.use(helmet());
    app.use(cors(config.server.cors));
    app.use(express.json({ limit: '1mb' }));
    app.use(express.urlencoded({ extended: true, limit: '1mb' }));
    app.use(cookieParser(config.integration.authentication.cookieSecret));
    
    // Apply rate limiting
    const limiter = rateLimit({
      windowMs: config.server.rateLimit.windowMs,
      max: config.server.rateLimit.max,
      standardHeaders: config.server.rateLimit.standardHeaders,
      legacyHeaders: config.server.rateLimit.legacyHeaders,
    });
    app.use(limiter);
    
    // Setup request logging
    app.use(requestLogger);
    
    // Setup database if configured
    if (process.env.DB_HOST) {
      await setupDatabase();
      logger.info('Database connection established');
    } else {
      logger.info('Running without external database');
    }
    
    // Initialize security modules
    const securityModules = setupSecurityModules(config);
    logger.info(`Initialized ${Object.keys(securityModules).length} security modules`);
    
    // Setup integrations with parent application
    setupIntegrations(config);
    
    // Mount API routes
    app.use(config.server.apiPrefix, apiRouter);
    
    // Setup dashboard if enabled
    if (config.integration.dashboard.embedInParentApp) {
      setupDashboard(app, config.server.dashboardPath);
      logger.info(`Security dashboard available at ${config.server.dashboardPath}`);
    }
    
    // Health check endpoint
    app.get('/health', (req, res) => {
      const health = checkServerHealth();
      res.status(health.status === 'healthy' ? 200 : 503).json(health);
    });
    
    // Static assets
    const publicDir = path.join(__dirname, '../public');
    if (fs.existsSync(publicDir)) {
      app.use('/sentinel-assets', express.static(publicDir));
    }
    
    // Error handling middleware
    app.use(errorHandler);
    
    // Start the server
    const port = process.env.SENTINEL_PORT || 8080;
    const host = process.env.SENTINEL_HOST || '0.0.0.0';
    
    app.listen(parseInt(port.toString()), host, () => {
      logger.info(`Sentinel 4.5 Security System is running on ${host}:${port}`);
      logger.info(`API available at ${config.server.apiPrefix}`);
      logger.info(`Environment: ${process.env.NODE_ENV || 'development'}`);
      
      // Log server address for external access
      logger.info(`Server public address: ${process.env.SERVER_ADDRESS || '188.245.209.124'}`);
    });
    
    // Handle termination signals
    process.on('SIGTERM', () => {
      logger.info('SIGTERM received, shutting down gracefully');
      process.exit(0);
    });
    
    process.on('SIGINT', () => {
      logger.info('SIGINT received, shutting down gracefully');
      process.exit(0);
    });
    
  } catch (error) {
    console.error('Failed to start Sentinel 4.5 Security System:', error);
    logger.error('Failed to start Sentinel 4.5 Security System', { error });
    process.exit(1);
  }
};

// Start the application
initializeApp();