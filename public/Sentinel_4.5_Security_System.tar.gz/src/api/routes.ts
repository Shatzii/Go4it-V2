/**
 * Sentinel 4.5 Security System - API Routes
 * 
 * This module defines the API routes for the Sentinel security system.
 */

import express, { Request, Response } from 'express';
import { logger } from '../core/logger';
import { getConfig } from '../core/config-loader';
import { authenticateRequest } from '../middleware/auth';
import { rateLimiterMiddleware } from '../middleware/rate-limiter';
import { getSecurityModules, runSecurityScan } from '../core/security-modules';
import { getSystemMetrics } from '../utils/system-metrics';
import { getSecurityAlerts, getSecurityStatus } from '../core/security-status';

// Create router
export const apiRouter = express.Router();

// Apply middleware for all routes
apiRouter.use(rateLimiterMiddleware);

// Get API configuration
const config = getConfig();

// Require authentication if configured
if (config.integration.api.requireAuth) {
  apiRouter.use(authenticateRequest);
}

/**
 * Authentication middleware for admin-only routes
 */
function adminOnly(req: Request, res: Response, next: express.NextFunction) {
  // Skip if authentication is disabled
  if (!config.integration.api.requireAuth) {
    return next();
  }
  
  // Get admin roles from configuration
  const adminRoles = config.integration.api.adminRoles || ['admin', 'security_admin'];
  
  // Check if user has admin role
  const userRoles = (req as any).user?.roles || [];
  const isAdmin = userRoles.some((role: string) => adminRoles.includes(role));
  
  if (!isAdmin) {
    logger.security('Unauthorized access attempt to admin API', {
      ip: req.ip,
      user: (req as any).user?.username || 'anonymous',
      path: req.path
    });
    
    return res.status(403).json({
      success: false,
      message: 'Access denied. Requires security administrator privileges.'
    });
  }
  
  next();
}

// API Routes

/**
 * GET /status
 * Get overall security status
 */
apiRouter.get('/status', (req, res) => {
  const status = getSecurityStatus();
  
  // Log the request
  logger.info('Security status requested', {
    ip: req.ip,
    user: (req as any).user?.username || 'anonymous'
  });
  
  res.json({
    success: true,
    data: status
  });
});

/**
 * GET /modules
 * Get active security modules and their status
 */
apiRouter.get('/modules', (req, res) => {
  const modules = getSecurityModules();
  
  res.json({
    success: true,
    data: modules
  });
});

/**
 * GET /alerts
 * Get security alerts with optional filtering
 */
apiRouter.get('/alerts', (req, res) => {
  // Parse query parameters
  const limit = parseInt(req.query.limit as string) || 50;
  const offset = parseInt(req.query.offset as string) || 0;
  const severity = req.query.severity as string || undefined;
  const status = req.query.status as string || undefined;
  const type = req.query.type as string || undefined;
  
  // Get filtered alerts
  const alerts = getSecurityAlerts({ limit, offset, severity, status, type });
  
  res.json({
    success: true,
    data: alerts
  });
});

/**
 * POST /alerts/:id/acknowledge
 * Acknowledge a security alert
 */
apiRouter.post('/alerts/:id/acknowledge', adminOnly, (req, res) => {
  const alertId = req.params.id;
  const user = (req as any).user?.username || 'system';
  
  try {
    // Acknowledge the alert
    const updated = false; // TODO: Implement alert acknowledgement
    
    if (updated) {
      logger.audit(user, `Acknowledged security alert ${alertId}`);
      
      res.json({
        success: true,
        message: 'Alert acknowledged'
      });
    } else {
      res.status(404).json({
        success: false,
        message: 'Alert not found'
      });
    }
  } catch (error) {
    logger.error('Failed to acknowledge alert', { alertId, error });
    
    res.status(500).json({
      success: false,
      message: 'Failed to acknowledge alert'
    });
  }
});

/**
 * POST /alerts/:id/resolve
 * Resolve a security alert
 */
apiRouter.post('/alerts/:id/resolve', adminOnly, (req, res) => {
  const alertId = req.params.id;
  const user = (req as any).user?.username || 'system';
  
  try {
    // Resolve the alert
    const updated = false; // TODO: Implement alert resolution
    
    if (updated) {
      logger.audit(user, `Resolved security alert ${alertId}`);
      
      res.json({
        success: true,
        message: 'Alert resolved'
      });
    } else {
      res.status(404).json({
        success: false,
        message: 'Alert not found'
      });
    }
  } catch (error) {
    logger.error('Failed to resolve alert', { alertId, error });
    
    res.status(500).json({
      success: false,
      message: 'Failed to resolve alert'
    });
  }
});

/**
 * POST /scan
 * Run a security scan
 */
apiRouter.post('/scan', adminOnly, async (req, res) => {
  const user = (req as any).user?.username || 'system';
  
  try {
    // Run the security scan
    const scanResults = await runSecurityScan(user);
    
    logger.audit(user, 'Initiated security scan', { scanId: scanResults.scanId });
    
    res.json({
      success: true,
      data: scanResults
    });
  } catch (error) {
    logger.error('Failed to run security scan', { error });
    
    res.status(500).json({
      success: false,
      message: 'Failed to run security scan',
      error: error instanceof Error ? error.message : String(error)
    });
  }
});

/**
 * GET /metrics
 * Get system metrics
 */
apiRouter.get('/metrics', adminOnly, async (req, res) => {
  try {
    // Get system metrics
    const metrics = await getSystemMetrics();
    
    res.json({
      success: true,
      data: metrics
    });
  } catch (error) {
    logger.error('Failed to get system metrics', { error });
    
    res.status(500).json({
      success: false,
      message: 'Failed to get system metrics',
      error: error instanceof Error ? error.message : String(error)
    });
  }
});

/**
 * GET /config
 * Get security configuration (admin only)
 */
apiRouter.get('/config', adminOnly, (req, res) => {
  // Get configuration with sensitive data removed
  const config = getConfig();
  
  // Deep clone the configuration to avoid modifying the original
  const safeConfig = JSON.parse(JSON.stringify(config));
  
  // Remove sensitive data
  if (safeConfig.integration?.authentication) {
    delete safeConfig.integration.authentication.jwtSecret;
    delete safeConfig.integration.authentication.cookieSecret;
  }
  
  res.json({
    success: true,
    data: safeConfig
  });
});

/**
 * POST /check-request
 * Check if a request should be allowed
 */
apiRouter.post('/check-request', async (req, res) => {
  const { ip, path, method, headers, body } = req.body;
  
  // Default response
  const response = {
    block: false,
    reason: null,
    riskScore: 0
  };
  
  // TODO: Implement security check for request
  
  res.json(response);
});

/**
 * GET /dashboard-data
 * Get all data needed for the security dashboard
 */
apiRouter.get('/dashboard-data', (req, res) => {
  try {
    // Get all data needed for the dashboard
    const status = getSecurityStatus();
    const alerts = getSecurityAlerts({ limit: 10 });
    const modules = getSecurityModules();
    
    res.json({
      success: true,
      data: {
        status,
        alerts,
        modules
      }
    });
  } catch (error) {
    logger.error('Failed to get dashboard data', { error });
    
    res.status(500).json({
      success: false,
      message: 'Failed to get dashboard data',
      error: error instanceof Error ? error.message : String(error)
    });
  }
});

// Export router
export default apiRouter;