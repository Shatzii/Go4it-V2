/**
 * Sentinel 4.5 Security System - Request Logger Middleware
 * 
 * This module provides request logging middleware for the security system.
 */

import { Request, Response, NextFunction } from 'express';
import { logger } from '../core/logger';
import { getConfig } from '../core/config-loader';
import { trackRequest } from '../utils/system-metrics';

/**
 * Request logging middleware
 * @param req Express request
 * @param res Express response
 * @param next Express next function
 */
export function requestLogger(req: Request, res: Response, next: NextFunction): void {
  // Skip logging for health checks and static assets to reduce noise
  if (
    req.path === '/health' ||
    req.path.startsWith('/sentinel-assets/') ||
    req.path === '/favicon.ico'
  ) {
    return next();
  }
  
  // Get start time
  const startTime = process.hrtime();
  
  // Log request
  logger.debug(`${req.method} ${req.path}`, {
    method: req.method,
    path: req.path,
    ip: req.ip,
    userAgent: req.headers['user-agent'],
    referer: req.headers.referer,
    user: (req as any).user?.username || 'anonymous'
  });
  
  // Capture response
  const originalEnd = res.end;
  let statusCode = 200;
  
  res.end = function(chunk?: any, encoding?: any, callback?: any): any {
    // Restore original end
    res.end = originalEnd;
    
    // Calculate duration
    const hrTime = process.hrtime(startTime);
    const durationMs = hrTime[0] * 1000 + hrTime[1] / 1000000;
    
    // Get status code
    statusCode = res.statusCode;
    
    // Log response
    if (statusCode >= 500) {
      logger.error(`${req.method} ${req.path} ${statusCode} - ${durationMs.toFixed(2)}ms`, {
        method: req.method,
        path: req.path,
        statusCode,
        durationMs,
        ip: req.ip,
        user: (req as any).user?.username || 'anonymous'
      });
    } else if (statusCode >= 400) {
      logger.warn(`${req.method} ${req.path} ${statusCode} - ${durationMs.toFixed(2)}ms`, {
        method: req.method,
        path: req.path,
        statusCode,
        durationMs,
        ip: req.ip,
        user: (req as any).user?.username || 'anonymous'
      });
    } else {
      logger.debug(`${req.method} ${req.path} ${statusCode} - ${durationMs.toFixed(2)}ms`, {
        method: req.method,
        path: req.path,
        statusCode,
        durationMs,
        ip: req.ip,
        user: (req as any).user?.username || 'anonymous'
      });
    }
    
    // Track metrics
    trackRequest(durationMs, statusCode >= 400);
    
    // Call original end
    return originalEnd.call(this, chunk, encoding, callback);
  };
  
  next();
}