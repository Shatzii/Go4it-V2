/**
 * Sentinel 4.5 Security System - Error Handler Middleware
 * 
 * This module provides error handling middleware for the security system.
 */

import { Request, Response, NextFunction } from 'express';
import { logger } from '../core/logger';

/**
 * Custom error with HTTP status code
 */
export class HttpError extends Error {
  statusCode: number;
  
  constructor(message: string, statusCode: number = 500) {
    super(message);
    this.statusCode = statusCode;
    this.name = 'HttpError';
  }
}

/**
 * Error handling middleware
 * @param err Error object
 * @param req Express request
 * @param res Express response
 * @param next Express next function
 */
export function errorHandler(
  err: Error,
  req: Request,
  res: Response,
  next: NextFunction
): void {
  // Determine status code
  const statusCode = err instanceof HttpError ? err.statusCode : 500;
  
  // Create error response
  const errorResponse = {
    success: false,
    message: err.message || 'Internal Server Error',
    path: req.path,
    timestamp: new Date().toISOString()
  };
  
  // Log the error
  if (statusCode >= 500) {
    logger.error('Server error', {
      error: err,
      path: req.path,
      method: req.method,
      statusCode,
      ip: req.ip,
      userAgent: req.headers['user-agent'],
      query: req.query,
      user: (req as any).user?.username || 'anonymous'
    });
  } else {
    logger.warn('Client error', {
      error: err.message,
      path: req.path,
      method: req.method,
      statusCode,
      ip: req.ip,
      user: (req as any).user?.username || 'anonymous'
    });
  }
  
  // Skip if headers already sent
  if (res.headersSent) {
    return next(err);
  }
  
  // Send error response
  res.status(statusCode).json(errorResponse);
}