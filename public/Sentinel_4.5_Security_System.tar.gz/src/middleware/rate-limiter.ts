/**
 * Sentinel 4.5 Security System - Rate Limiter Middleware
 * 
 * This module provides rate limiting middleware to protect APIs from abuse.
 */

import { Request, Response, NextFunction } from 'express';
import rateLimit from 'express-rate-limit';
import { getConfig } from '../core/config-loader';
import { logger } from '../core/logger';

// Use in-memory store for rate limiting
const limiterStore = new Map();

/**
 * Rate limiter middleware for API routes
 */
export const rateLimiterMiddleware = (req: Request, res: Response, next: NextFunction): void => {
  // Get config
  const config = getConfig();
  
  // Skip rate limiting for whitelisted IPs
  const ipWhitelist = config.modules.ipBlocking.ipWhitelist || [];
  if (ipWhitelist.includes(req.ip)) {
    return next();
  }
  
  // Determine which rate limit to apply based on the path
  const path = req.path;
  let windowMs = config.server.rateLimit.windowMs;
  let max = config.server.rateLimit.max;
  
  // Apply stricter limits for authentication endpoints
  if (path.includes('/login') || path.includes('/register') || path.includes('/auth')) {
    windowMs = config.modules.rateLimiting.authWindowMs;
    max = config.modules.rateLimiting.authMax;
  } 
  // Apply stricter limits for admin endpoints
  else if (path.includes('/admin') || path.includes('/config')) {
    windowMs = config.modules.rateLimiting.adminWindowMs;
    max = config.modules.rateLimiting.adminMax;
  } 
  // Standard API endpoints
  else {
    windowMs = config.modules.rateLimiting.standardWindowMs;
    max = config.modules.rateLimiting.standardMax;
  }
  
  // Create limiter
  const limiter = rateLimit({
    windowMs,
    max,
    standardHeaders: true,
    legacyHeaders: false,
    skip: (req) => {
      // Skip rate limiting for whitelisted IPs (double check)
      return ipWhitelist.includes(req.ip);
    },
    handler: (req, res) => {
      // Log rate limit exceeded
      logger.security('Rate limit exceeded', {
        ip: req.ip,
        path: req.path,
        method: req.method,
        user: (req as any).user?.username || 'anonymous',
        userAgent: req.headers['user-agent']
      });
      
      res.status(429).json({
        success: false,
        message: 'Too many requests, please try again later.',
        retryAfter: Math.ceil(windowMs / 1000) // Convert to seconds
      });
    }
  });
  
  // Apply limiter
  limiter(req, res, next);
};

/**
 * Get rate limit status for a specific IP
 * @param ip The IP address
 * @returns Rate limit status or null if no limit is set
 */
export function getRateLimitStatus(ip: string): any {
  // Get from store
  return limiterStore.get(ip) || null;
}

/**
 * Reset rate limit for a specific IP
 * @param ip The IP address
 * @returns True if the rate limit was reset
 */
export function resetRateLimit(ip: string): boolean {
  // Remove from store
  return limiterStore.delete(ip);
}