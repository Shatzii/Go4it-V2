/**
 * Sentinel 4.5 Security System - Authentication Middleware
 * 
 * This module provides authentication middleware for the security system.
 */

import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { getConfig } from '../core/config-loader';
import { logger } from '../core/logger';

/**
 * Interface for the JWT payload
 */
interface JwtPayload {
  id: number | string;
  username: string;
  roles: string[];
  exp: number;
  iat: number;
}

/**
 * Authenticate the request
 * @param req Express request
 * @param res Express response
 * @param next Express next function
 */
export function authenticateRequest(req: Request, res: Response, next: NextFunction): void {
  // Skip authentication if disabled
  if (getConfig().integration.authentication.useParentAuth === false) {
    return next();
  }
  
  // Get JWT secret from configuration
  const jwtSecret = getConfig().integration.authentication.jwtSecret;
  
  // Get token from request
  const token = getTokenFromRequest(req);
  
  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Authentication required'
    });
  }
  
  try {
    // Verify token
    const decoded = jwt.verify(token, jwtSecret) as JwtPayload;
    
    // Set user on request
    (req as any).user = decoded;
    
    // Check if token is about to expire
    const tokenExp = decoded.exp;
    const now = Math.floor(Date.now() / 1000);
    const timeLeft = tokenExp - now;
    
    // If token is about to expire (less than 5 minutes), add refresh token to response
    if (timeLeft < 300) {
      const refreshToken = generateRefreshToken(decoded, jwtSecret);
      res.setHeader('X-Refresh-Token', refreshToken);
    }
    
    next();
  } catch (error) {
    logger.security('Invalid authentication token', {
      ip: req.ip,
      error: error instanceof Error ? error.message : String(error)
    });
    
    res.status(401).json({
      success: false,
      message: 'Invalid or expired authentication token'
    });
  }
}

/**
 * Generate a refresh token
 * @param user User data
 * @param secret JWT secret
 * @returns JWT token
 */
function generateRefreshToken(user: JwtPayload, secret: string): string {
  // Create token payload
  const payload = {
    id: user.id,
    username: user.username,
    roles: user.roles
  };
  
  // Generate token
  return jwt.sign(payload, secret, {
    expiresIn: getConfig().integration.authentication.refreshTokenExpiresIn || '1d'
  });
}

/**
 * Get token from request
 * @param req Express request
 * @returns JWT token or null
 */
function getTokenFromRequest(req: Request): string | null {
  // Try to get token from authorization header
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7);
  }
  
  // Try to get token from cookie
  const cookieName = getConfig().integration.authentication.cookieName || 'sentinel_token';
  if (req.cookies && req.cookies[cookieName]) {
    return req.cookies[cookieName];
  }
  
  // Try to get token from query parameter
  if (req.query.token) {
    return req.query.token as string;
  }
  
  return null;
}