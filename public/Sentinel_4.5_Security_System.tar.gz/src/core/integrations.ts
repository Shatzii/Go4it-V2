/**
 * Sentinel 4.5 Security System - Integrations
 * 
 * This module handles integrations with external systems and parent applications.
 */

import { logger } from './logger';
import { getConfig } from './config-loader';
import { addSecurityAlert, addSecurityEvent } from './security-status';

/**
 * Integration services
 */
const integrationServices: Record<string, any> = {};

/**
 * Setup integrations with parent applications
 * @param config Configuration
 */
export function setupIntegrations(config: any): void {
  logger.info('Setting up integrations');
  
  // Get platforms to integrate with
  const platforms = process.env.SCHOOL_PLATFORMS ? 
    process.env.SCHOOL_PLATFORMS.split(',') : 
    ['lawyer-makers', 'neurodivergent-school', 'language-school'];
  
  // Setup each platform integration
  platforms.forEach(platform => {
    const trimmedPlatform = platform.trim();
    
    // Setup platform-specific integration
    switch (trimmedPlatform) {
      case 'lawyer-makers':
        setupLawyerMakersIntegration();
        break;
      case 'neurodivergent-school':
        setupNeurodivergentSchoolIntegration();
        break;
      case 'language-school':
        setupLanguageSchoolIntegration();
        break;
      default:
        logger.warn(`Unknown platform: ${trimmedPlatform}`);
    }
  });
  
  logger.info(`Integrations setup complete for ${Object.keys(integrationServices).length} platforms`);
}

/**
 * Setup integration with The Lawyer Makers platform
 */
function setupLawyerMakersIntegration(): void {
  logger.info('Setting up integration with The Lawyer Makers platform');
  
  try {
    // Create integration service
    integrationServices['lawyer-makers'] = {
      platform: 'lawyer-makers',
      name: 'The Lawyer Makers',
      enabled: true,
      
      // Push security alert to the platform
      pushAlert: async (alert: any) => {
        // In a real implementation, this would call an API endpoint
        logger.debug('Pushing alert to The Lawyer Makers platform', { alert });
        return true;
      },
      
      // Fetch authentication status from the platform
      getAuthStatus: async () => {
        // In a real implementation, this would call an API endpoint
        return {
          enabled: true,
          lastSync: new Date().toISOString(),
          userCount: 1250,
          status: 'active'
        };
      }
    };
    
    logger.info('The Lawyer Makers integration setup complete');
    
    // Add integration event
    addSecurityEvent({
      type: 'integration_setup',
      message: 'Integration with The Lawyer Makers platform established',
      platform: 'lawyer-makers'
    });
  } catch (error) {
    logger.error('Failed to setup integration with The Lawyer Makers platform', { error });
    
    // Add alert for integration failure
    addSecurityAlert({
      type: 'integration_failure',
      source: 'system',
      severity: 'medium',
      message: 'Failed to establish integration with The Lawyer Makers platform',
      details: {
        platform: 'lawyer-makers',
        error: error instanceof Error ? error.message : String(error)
      }
    });
  }
}

/**
 * Setup integration with Neurodivergent School platform
 */
function setupNeurodivergentSchoolIntegration(): void {
  logger.info('Setting up integration with Neurodivergent School platform');
  
  try {
    // Create integration service
    integrationServices['neurodivergent-school'] = {
      platform: 'neurodivergent-school',
      name: 'Neurodivergent School',
      enabled: true,
      
      // Push security alert to the platform
      pushAlert: async (alert: any) => {
        // In a real implementation, this would call an API endpoint
        logger.debug('Pushing alert to Neurodivergent School platform', { alert });
        return true;
      },
      
      // Fetch authentication status from the platform
      getAuthStatus: async () => {
        // In a real implementation, this would call an API endpoint
        return {
          enabled: true,
          lastSync: new Date().toISOString(),
          userCount: 850,
          status: 'active'
        };
      }
    };
    
    logger.info('Neurodivergent School integration setup complete');
    
    // Add integration event
    addSecurityEvent({
      type: 'integration_setup',
      message: 'Integration with Neurodivergent School platform established',
      platform: 'neurodivergent-school'
    });
  } catch (error) {
    logger.error('Failed to setup integration with Neurodivergent School platform', { error });
    
    // Add alert for integration failure
    addSecurityAlert({
      type: 'integration_failure',
      source: 'system',
      severity: 'medium',
      message: 'Failed to establish integration with Neurodivergent School platform',
      details: {
        platform: 'neurodivergent-school',
        error: error instanceof Error ? error.message : String(error)
      }
    });
  }
}

/**
 * Setup integration with Language School platform
 */
function setupLanguageSchoolIntegration(): void {
  logger.info('Setting up integration with Language School platform');
  
  try {
    // Create integration service
    integrationServices['language-school'] = {
      platform: 'language-school',
      name: 'Language School',
      enabled: true,
      
      // Push security alert to the platform
      pushAlert: async (alert: any) => {
        // In a real implementation, this would call an API endpoint
        logger.debug('Pushing alert to Language School platform', { alert });
        return true;
      },
      
      // Fetch authentication status from the platform
      getAuthStatus: async () => {
        // In a real implementation, this would call an API endpoint
        return {
          enabled: true,
          lastSync: new Date().toISOString(),
          userCount: 620,
          status: 'active'
        };
      }
    };
    
    logger.info('Language School integration setup complete');
    
    // Add integration event
    addSecurityEvent({
      type: 'integration_setup',
      message: 'Integration with Language School platform established',
      platform: 'language-school'
    });
  } catch (error) {
    logger.error('Failed to setup integration with Language School platform', { error });
    
    // Add alert for integration failure
    addSecurityAlert({
      type: 'integration_failure',
      source: 'system',
      severity: 'medium',
      message: 'Failed to establish integration with Language School platform',
      details: {
        platform: 'language-school',
        error: error instanceof Error ? error.message : String(error)
      }
    });
  }
}

/**
 * Push security alert to all integrated platforms
 * @param alert The alert to push
 */
export async function pushAlertToAllPlatforms(alert: any): Promise<void> {
  logger.debug('Pushing alert to all platforms', { alert });
  
  // Get enabled integrations
  const enabledIntegrations = Object.values(integrationServices).filter(
    (service: any) => service.enabled
  );
  
  // Push to each platform
  for (const service of enabledIntegrations) {
    try {
      await service.pushAlert(alert);
    } catch (error) {
      logger.error(`Failed to push alert to ${service.name} platform`, { error });
    }
  }
}

/**
 * Get authentication status from all integrated platforms
 * @returns Authentication status for all platforms
 */
export async function getAuthStatusFromAllPlatforms(): Promise<Record<string, any>> {
  const results: Record<string, any> = {};
  
  // Get enabled integrations
  const enabledIntegrations = Object.values(integrationServices).filter(
    (service: any) => service.enabled
  );
  
  // Get status from each platform
  for (const service of enabledIntegrations) {
    try {
      results[service.platform] = await service.getAuthStatus();
    } catch (error) {
      logger.error(`Failed to get auth status from ${service.name} platform`, { error });
      results[service.platform] = {
        enabled: false,
        status: 'error',
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }
  
  return results;
}

/**
 * Get all integration services
 * @returns Integration services
 */
export function getIntegrationServices(): Record<string, any> {
  return integrationServices;
}