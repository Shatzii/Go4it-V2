/**
 * Sentinel 4.5 Security System - Configuration Loader
 * 
 * This module loads configuration settings from various sources:
 * 1. Default configuration
 * 2. Configuration file (config.js)
 * 3. Environment variables
 */

import fs from 'fs';
import path from 'path';
import { logger } from './logger';

// Default configuration
const defaultConfig = {
  // Core system settings
  system: {
    name: "Sentinel 4.5",
    version: "4.5.0",
    environment: process.env.NODE_ENV || "development",
    debug: process.env.DEBUG_MODE === "true",
  },
  
  // Server configuration
  server: {
    port: process.env.SENTINEL_PORT || 8080,
    host: process.env.SENTINEL_HOST || "0.0.0.0",
    apiPrefix: process.env.API_PREFIX || "/api/security",
    dashboardPath: process.env.DASHBOARD_PATH || "/security-dashboard",
    cors: {
      origins: process.env.CORS_ORIGINS ? 
        process.env.CORS_ORIGINS.split(",") : 
        ["http://localhost:3000", "https://localhost:3000"],
      credentials: true
    },
    rateLimit: {
      windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || "900000"),
      max: parseInt(process.env.RATE_LIMIT_MAX || "100"),
      standardHeaders: true,
      legacyHeaders: false,
    }
  },
  
  // Security modules configuration
  modules: {
    authSecurity: {
      enabled: process.env.MODULE_AUTH_SECURITY !== "false",
      maxAttempts: parseInt(process.env.AUTH_MAX_ATTEMPTS || "5"),
      lockoutTime: parseInt(process.env.AUTH_LOCKOUT_TIME || "900"),
      ipWhitelist: process.env.IP_WHITELIST ? 
        process.env.IP_WHITELIST.split(",") : 
        ["127.0.0.1"]
    },
    rateLimiting: {
      enabled: process.env.MODULE_RATE_LIMITING !== "false",
      standardWindowMs: parseInt(process.env.RATE_STANDARD_WINDOW || "60000"),
      standardMax: parseInt(process.env.RATE_STANDARD_MAX || "60"),
      authWindowMs: parseInt(process.env.RATE_AUTH_WINDOW || "300000"),
      authMax: parseInt(process.env.RATE_AUTH_MAX || "20"),
      adminWindowMs: parseInt(process.env.RATE_ADMIN_WINDOW || "900000"),
      adminMax: parseInt(process.env.RATE_ADMIN_MAX || "100")
    },
    fileUploadSecurity: {
      enabled: process.env.MODULE_FILE_UPLOAD !== "false",
      maxSize: parseInt(process.env.UPLOAD_MAX_SIZE || "10485760"),
      scanUploads: process.env.SCAN_UPLOADS !== "false",
      allowedTypes: process.env.ALLOWED_TYPES ? 
        process.env.ALLOWED_TYPES.split(",") : 
        ["image/jpeg", "image/png", "image/gif", "application/pdf", "text/plain"]
    },
    honeypot: {
      enabled: process.env.MODULE_HONEYPOT !== "false",
      trapRoutes: process.env.HONEYPOT_ROUTES ? 
        process.env.HONEYPOT_ROUTES.split(",") : 
        ["/admin.php", "/wp-login.php", "/phpmyadmin", "/.env"],
      delayResponse: process.env.HONEYPOT_DELAY !== "false",
      trackIpAddresses: process.env.HONEYPOT_TRACK !== "false"
    },
    anomalyDetection: {
      enabled: process.env.MODULE_ANOMALY !== "false",
      sensitivity: parseFloat(process.env.ANOMALY_SENSITIVITY || "0.7"),
      baselineTrainingDays: parseInt(process.env.ANOMALY_BASELINE_DAYS || "7"),
      minimumDataPoints: parseInt(process.env.ANOMALY_MIN_DATA || "100"),
      alertOnDeviation: parseFloat(process.env.ANOMALY_ALERT_DEVIATION || "3.0")
    },
    ipBlocking: {
      enabled: process.env.MODULE_IP_BLOCKING !== "false",
      blockTime: parseInt(process.env.IP_BLOCK_TIME || "86400"),
      maxViolationsBeforeBlock: parseInt(process.env.MAX_VIOLATIONS || "5"),
      checkReputation: process.env.CHECK_IP_REPUTATION !== "false",
      ipWhitelist: process.env.IP_WHITELIST ? 
        process.env.IP_WHITELIST.split(",") : 
        ["127.0.0.1"]
    },
    contentSecurity: { enabled: process.env.MODULE_CONTENT_SECURITY !== "false" },
    threatIntelligence: { enabled: process.env.MODULE_THREAT_INTEL !== "false" },
    databaseMonitor: { enabled: process.env.MODULE_DB_MONITOR !== "false" },
    userBehavior: { enabled: process.env.MODULE_USER_BEHAVIOR !== "false" },
    correlationEngine: { 
      enabled: process.env.MODULE_CORRELATION !== "false",
      maxEventsCorrelated: parseInt(process.env.MAX_EVENTS_CORRELATED || "1000")
    },
    secureSession: { 
      enabled: process.env.MODULE_SECURE_SESSION !== "false",
      maxConcurrentSessions: parseInt(process.env.MAX_CONCURRENT_SESSIONS || "3")
    },
    vulnerabilityScanner: { 
      enabled: process.env.MODULE_VULNERABILITY_SCANNER !== "false",
      scanInterval: parseInt(process.env.VULNERABILITY_SCAN_INTERVAL || "86400")
    },
    apiKeyManager: { enabled: process.env.MODULE_API_KEY_MANAGER !== "false" },
    securityScoring: { enabled: process.env.MODULE_SECURITY_SCORING !== "false" }
  },
  
  // Logging configuration
  logging: {
    level: process.env.LOG_LEVEL || "info",
    format: process.env.LOG_FORMAT || "json",
    directory: process.env.LOG_DIR || "./logs",
    maxFiles: parseInt(process.env.LOG_MAX_FILES || "14"),
    maxSize: process.env.LOG_MAX_SIZE || "50m",
    
    // Security event logging
    securityEvents: {
      logToFile: process.env.LOG_SECURITY_EVENTS !== "false",
      alertOnHigh: process.env.ALERT_ON_HIGH !== "false",
      retentionDays: parseInt(process.env.LOG_RETENTION_DAYS || "90")
    },
    
    // Log rotation
    rotation: {
      enabled: true,
      frequency: "daily",
      maxFiles: parseInt(process.env.LOG_RETENTION_DAYS || "90"),
      compress: true
    }
  },
  
  // System monitoring
  monitoring: {
    // Resource monitoring
    resources: {
      enabled: process.env.MONITOR_RESOURCES !== "false",
      checkInterval: parseInt(process.env.RESOURCE_CHECK_INTERVAL || "60000"),
      memoryThreshold: parseInt(process.env.MEMORY_THRESHOLD || "85"),
      cpuThreshold: parseInt(process.env.CPU_THRESHOLD || "90"),
      diskThreshold: parseInt(process.env.DISK_THRESHOLD || "90")
    },
    
    // Health checks
    healthCheck: {
      enabled: process.env.HEALTH_CHECK !== "false",
      endpoint: process.env.HEALTH_ENDPOINT || "/health",
      interval: parseInt(process.env.HEALTH_CHECK_INTERVAL || "300000"),
      timeout: parseInt(process.env.HEALTH_CHECK_TIMEOUT || "5000")
    }
  },
  
  // Integration with the main application
  integration: {
    // Authentication integration
    authentication: {
      useParentAuth: process.env.USE_PARENT_AUTH === "true",
      jwtSecret: process.env.JWT_SECRET || "change-this-in-production",
      cookieSecret: process.env.COOKIE_SECRET || "change-this-in-production"
    },
    
    // API integration
    api: {
      standalone: process.env.API_STANDALONE === "true",
      requireAuth: process.env.API_REQUIRE_AUTH !== "false",
      adminRoles: process.env.ADMIN_ROLES ? 
        process.env.ADMIN_ROLES.split(",") : 
        ["admin", "security_admin"]
    },
    
    // Dashboard integration
    dashboard: {
      embedInParentApp: process.env.EMBED_DASHBOARD !== "false",
      theme: process.env.DASHBOARD_THEME || "dark",
      autoRefresh: process.env.DASHBOARD_AUTO_REFRESH !== "false",
      refreshInterval: parseInt(process.env.DASHBOARD_REFRESH_INTERVAL || "30")
    }
  }
};

/**
 * Load configuration from file
 * @returns The loaded configuration file or null if not found
 */
function loadConfigFile(): any {
  const configPaths = [
    path.resolve(process.cwd(), 'config.js'),
    path.resolve(process.cwd(), 'server-config.js'),
    path.resolve(process.cwd(), 'sentinel.config.js'),
    path.resolve(process.cwd(), '.sentinelrc.js')
  ];
  
  for (const configPath of configPaths) {
    if (fs.existsSync(configPath)) {
      try {
        const config = require(configPath);
        logger.info(`Loaded configuration from ${configPath}`);
        return config;
      } catch (error) {
        logger.error(`Failed to load configuration from ${configPath}`, { error });
      }
    }
  }
  
  logger.warn('No configuration file found, using default configuration');
  return null;
}

/**
 * Deep merge two objects
 * @param target The target object
 * @param source The source object
 * @returns The merged object
 */
function deepMerge(target: any, source: any): any {
  const output = { ...target };
  
  if (isObject(target) && isObject(source)) {
    Object.keys(source).forEach(key => {
      if (isObject(source[key])) {
        if (!(key in target)) {
          output[key] = source[key];
        } else {
          output[key] = deepMerge(target[key], source[key]);
        }
      } else {
        output[key] = source[key];
      }
    });
  }
  
  return output;
}

/**
 * Check if value is an object
 * @param item The item to check
 * @returns True if the item is an object
 */
function isObject(item: any): boolean {
  return (item && typeof item === 'object' && !Array.isArray(item));
}

// Store the loaded configuration
let loadedConfig: any = null;

/**
 * Load configuration from various sources
 * @returns The merged configuration
 */
export function loadConfiguration(): any {
  // Return cached configuration if already loaded
  if (loadedConfig) {
    return loadedConfig;
  }
  
  // Load configuration from file
  const fileConfig = loadConfigFile();
  
  // Merge configurations
  loadedConfig = fileConfig ? deepMerge(defaultConfig, fileConfig) : defaultConfig;
  
  // Optimize for the server if specified
  if (process.env.TARGET_SERVER) {
    loadedConfig.server.host = process.env.TARGET_SERVER;
    logger.info(`Configuration optimized for server: ${process.env.TARGET_SERVER}`);
    
    // Add server to CORS origins if not already present
    const serverUrl = `https://${process.env.TARGET_SERVER}`;
    if (!loadedConfig.server.cors.origins.includes(serverUrl)) {
      loadedConfig.server.cors.origins.push(serverUrl);
      loadedConfig.server.cors.origins.push(`http://${process.env.TARGET_SERVER}`);
    }
  }
  
  // Special configuration for 188.245.209.124
  if (loadedConfig.server.host === '188.245.209.124' || process.env.TARGET_SERVER === '188.245.209.124') {
    logger.info('Applying specific optimizations for server 188.245.209.124');
    
    // Add school-specific domains to CORS
    const schoolDomains = [
      'https://lawyer-makers.shatzios.edu',
      'https://neurodivergent-school.shatzios.edu',
      'https://language-school.shatzios.edu'
    ];
    
    schoolDomains.forEach(domain => {
      if (!loadedConfig.server.cors.origins.includes(domain)) {
        loadedConfig.server.cors.origins.push(domain);
      }
    });
    
    // Set optimized rate limits based on server capacity
    loadedConfig.server.rateLimit.windowMs = 15 * 60 * 1000; // 15 minutes
    loadedConfig.server.rateLimit.max = 100; // 100 requests per window
    
    // Set resource thresholds based on server specs
    loadedConfig.monitoring.resources.memoryThreshold = 85; // 85% memory threshold
    loadedConfig.monitoring.resources.cpuThreshold = 90; // 90% CPU threshold
    loadedConfig.monitoring.resources.diskThreshold = 90; // 90% disk threshold
    
    // Add server IP to whitelist
    if (!loadedConfig.modules.ipBlocking.ipWhitelist.includes('188.245.209.124')) {
      loadedConfig.modules.ipBlocking.ipWhitelist.push('188.245.209.124');
    }
  }
  
  return loadedConfig;
}

/**
 * Get the current configuration
 * @returns The current configuration
 */
export function getConfig(): any {
  if (!loadedConfig) {
    return loadConfiguration();
  }
  return loadedConfig;
}

/**
 * Update a configuration value
 * @param path The path to the configuration value
 * @param value The new value
 */
export function updateConfig(path: string, value: any): void {
  if (!loadedConfig) {
    loadConfiguration();
  }
  
  const parts = path.split('.');
  let current = loadedConfig;
  
  for (let i = 0; i < parts.length - 1; i++) {
    if (!current[parts[i]]) {
      current[parts[i]] = {};
    }
    current = current[parts[i]];
  }
  
  current[parts[parts.length - 1]] = value;
  
  logger.info(`Updated configuration: ${path}`, { newValue: value });
}