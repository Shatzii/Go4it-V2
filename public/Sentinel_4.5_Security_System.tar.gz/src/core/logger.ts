/**
 * Sentinel 4.5 Security System - Logger
 * 
 * This module provides logging functionality for the security system,
 * with different log levels and file rotation.
 */

import fs from 'fs';
import path from 'path';
import { createLogger, format, transports } from 'winston';
import 'winston-daily-rotate-file';

// Default log directory
const DEFAULT_LOG_DIR = './logs';

// Logger interface
export interface Logger {
  info(message: string, meta?: any): void;
  warn(message: string, meta?: any): void;
  error(message: string, meta?: any): void;
  debug(message: string, meta?: any): void;
  security(message: string, meta?: any): void;
  audit(user: string, action: string, meta?: any): void;
}

// Winston logger instance
let winstonLogger: any;

/**
 * Initialize the logger
 */
export function initializeLogger(): void {
  // Get configuration from environment
  const logLevel = process.env.LOG_LEVEL || 'info';
  const logFormat = process.env.LOG_FORMAT || 'json';
  const logDir = process.env.LOG_DIR || DEFAULT_LOG_DIR;
  
  // Ensure log directory exists
  if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir, { recursive: true });
  }
  
  // Define log format
  const logFormatter = logFormat === 'json'
    ? format.combine(
        format.timestamp(),
        format.json()
      )
    : format.combine(
        format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        format.printf(({ level, message, timestamp, ...meta }) => {
          return `${timestamp} [${level.toUpperCase()}] ${message}${
            Object.keys(meta).length ? ' ' + JSON.stringify(meta) : ''
          }`;
        })
      );
  
  // Create separate transports for different log types
  const systemTransport = new transports.DailyRotateFile({
    filename: path.join(logDir, 'system-%DATE%.log'),
    datePattern: 'YYYY-MM-DD',
    zippedArchive: true,
    maxSize: process.env.LOG_MAX_SIZE || '20m',
    maxFiles: process.env.LOG_MAX_FILES || '14d',
    level: logLevel
  });
  
  const securityTransport = new transports.DailyRotateFile({
    filename: path.join(logDir, 'security-%DATE%.log'),
    datePattern: 'YYYY-MM-DD',
    zippedArchive: true,
    maxSize: process.env.LOG_MAX_SIZE || '20m',
    maxFiles: process.env.LOG_RETENTION_DAYS || '90d',
    level: 'info'
  });
  
  const auditTransport = new transports.DailyRotateFile({
    filename: path.join(logDir, 'audit-%DATE%.log'),
    datePattern: 'YYYY-MM-DD',
    zippedArchive: true,
    maxSize: process.env.LOG_MAX_SIZE || '20m',
    maxFiles: process.env.LOG_RETENTION_DAYS || '90d',
    level: 'info'
  });
  
  const errorTransport = new transports.DailyRotateFile({
    filename: path.join(logDir, 'error-%DATE%.log'),
    datePattern: 'YYYY-MM-DD',
    zippedArchive: true,
    maxSize: process.env.LOG_MAX_SIZE || '20m',
    maxFiles: process.env.LOG_MAX_FILES || '14d',
    level: 'error'
  });
  
  // Add console transport in development
  const allTransports = [
    systemTransport,
    securityTransport,
    auditTransport,
    errorTransport
  ];
  
  if (process.env.NODE_ENV !== 'production') {
    allTransports.push(new transports.Console({
      level: 'debug',
      format: format.combine(
        format.colorize(),
        format.timestamp({ format: 'HH:mm:ss' }),
        format.printf(({ level, message, timestamp, ...meta }) => {
          return `${timestamp} ${level}: ${message}${
            Object.keys(meta).length ? ' ' + JSON.stringify(meta) : ''
          }`;
        })
      )
    }));
  }
  
  // Create the logger
  winstonLogger = createLogger({
    level: logLevel,
    format: logFormatter,
    defaultMeta: { service: 'sentinel-security' },
    transports: allTransports
  });
  
  winstonLogger.info('Logger initialized', {
    logLevel,
    logFormat,
    logDir
  });
}

// Logger implementation
class LoggerImplementation implements Logger {
  info(message: string, meta?: any): void {
    winstonLogger.info(message, meta);
  }
  
  warn(message: string, meta?: any): void {
    winstonLogger.warn(message, meta);
  }
  
  error(message: string, meta?: any): void {
    winstonLogger.error(message, meta);
  }
  
  debug(message: string, meta?: any): void {
    winstonLogger.debug(message, meta);
  }
  
  security(message: string, meta?: any): void {
    winstonLogger.log({
      level: 'info',
      message,
      ...meta,
      securityEvent: true
    });
  }
  
  audit(user: string, action: string, meta?: any): void {
    winstonLogger.log({
      level: 'info',
      message: `User '${user}' ${action}`,
      user,
      action,
      ...meta,
      auditEvent: true
    });
  }
}

// Export logger instance
export const logger: Logger = new LoggerImplementation();