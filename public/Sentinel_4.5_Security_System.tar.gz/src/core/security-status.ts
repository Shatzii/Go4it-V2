/**
 * Sentinel 4.5 Security System - Security Status
 * 
 * This module manages the overall security status and alerts
 * for the system, tracking threats and incidents.
 */

import { getConfig } from './config-loader';
import { logger } from './logger';
import { getSecurityModules } from './security-modules';

// Alert types
export type AlertSeverity = 'low' | 'medium' | 'high' | 'critical';
export type AlertStatus = 'new' | 'acknowledged' | 'resolved';

// Security alert interface
export interface SecurityAlert {
  id: string;
  timestamp: string;
  type: string;
  source: string;
  severity: AlertSeverity;
  status: AlertStatus;
  message: string;
  details?: any;
  ip?: string;
  user?: string;
  acknowledged?: {
    by: string;
    at: string;
  };
  resolved?: {
    by: string;
    at: string;
  };
}

// Security status interface
export interface SecurityStatus {
  status: 'secure' | 'warning' | 'critical';
  lastUpdated: string;
  alertCounts: {
    total: number;
    new: number;
    acknowledged: number;
    resolved: number;
    low: number;
    medium: number;
    high: number;
    critical: number;
  };
  threatLevel: number; // 0-100
  activeThreats: number;
  securityScore: number; // 0-100
  systemStatus: {
    modules: {
      total: number;
      active: number;
      inactive: number;
      failed: number;
    };
    uptime: number;
  };
  recentEvents: Array<{
    id: string;
    timestamp: string;
    type: string;
    message: string;
  }>;
}

// In-memory storage for alerts (in a real implementation, this would be a database)
const securityAlerts: SecurityAlert[] = [];
const securityEvents: any[] = [];

// Cache for security status to avoid recalculation on every request
let cachedSecurityStatus: SecurityStatus | null = null;
let lastStatusUpdate = 0;
const statusCacheDuration = 5 * 1000; // 5 seconds

/**
 * Get the current security status
 * @returns The security status
 */
export function getSecurityStatus(): SecurityStatus {
  const now = Date.now();
  
  // Return cached status if available and not expired
  if (cachedSecurityStatus && now - lastStatusUpdate < statusCacheDuration) {
    return cachedSecurityStatus;
  }
  
  // Get module status
  const modules = getSecurityModules();
  const activeModules = modules.filter(m => m.status === 'active');
  const inactiveModules = modules.filter(m => m.status === 'inactive');
  const failedModules = modules.filter(m => m.status === 'failed');
  
  // Count alerts by status and severity
  const newAlerts = securityAlerts.filter(a => a.status === 'new');
  const acknowledgedAlerts = securityAlerts.filter(a => a.status === 'acknowledged');
  const resolvedAlerts = securityAlerts.filter(a => a.status === 'resolved');
  const lowAlerts = securityAlerts.filter(a => a.severity === 'low');
  const mediumAlerts = securityAlerts.filter(a => a.severity === 'medium');
  const highAlerts = securityAlerts.filter(a => a.severity === 'high');
  const criticalAlerts = securityAlerts.filter(a => a.severity === 'critical');
  
  // Calculate active threats (non-resolved alerts weighted by severity)
  const activeThreats = newAlerts.length + acknowledgedAlerts.length;
  
  // Calculate threat level (weighted score based on alert severity)
  let threatScore = 0;
  
  newAlerts.forEach(alert => {
    switch (alert.severity) {
      case 'low': threatScore += 1; break;
      case 'medium': threatScore += 3; break;
      case 'high': threatScore += 10; break;
      case 'critical': threatScore += 25; break;
    }
  });
  
  acknowledgedAlerts.forEach(alert => {
    switch (alert.severity) {
      case 'low': threatScore += 0.5; break;
      case 'medium': threatScore += 1.5; break;
      case 'high': threatScore += 5; break;
      case 'critical': threatScore += 12.5; break;
    }
  });
  
  // Cap threat level at 100
  const threatLevel = Math.min(100, threatScore);
  
  // Calculate security score (inverse of threat level, with module health factored in)
  const moduleHealthFactor = activeModules.length / modules.length;
  const rawSecurityScore = 100 - threatLevel;
  const securityScore = Math.round(rawSecurityScore * moduleHealthFactor);
  
  // Determine overall status
  let status: 'secure' | 'warning' | 'critical' = 'secure';
  
  if (criticalAlerts.filter(a => a.status !== 'resolved').length > 0 || securityScore < 60) {
    status = 'critical';
  } else if (highAlerts.filter(a => a.status !== 'resolved').length > 0 || securityScore < 80) {
    status = 'warning';
  }
  
  // Get recent events (last 10)
  const recentEvents = securityEvents
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, 10)
    .map(event => ({
      id: event.id,
      timestamp: event.timestamp,
      type: event.type,
      message: event.message
    }));
  
  // Create status object
  const securityStatus: SecurityStatus = {
    status,
    lastUpdated: new Date().toISOString(),
    alertCounts: {
      total: securityAlerts.length,
      new: newAlerts.length,
      acknowledged: acknowledgedAlerts.length,
      resolved: resolvedAlerts.length,
      low: lowAlerts.length,
      medium: mediumAlerts.length,
      high: highAlerts.length,
      critical: criticalAlerts.length
    },
    threatLevel,
    activeThreats,
    securityScore,
    systemStatus: {
      modules: {
        total: modules.length,
        active: activeModules.length,
        inactive: inactiveModules.length,
        failed: failedModules.length
      },
      uptime: process.uptime()
    },
    recentEvents
  };
  
  // Cache the status
  cachedSecurityStatus = securityStatus;
  lastStatusUpdate = now;
  
  return securityStatus;
}

/**
 * Add a security alert
 * @param alert The alert to add
 * @returns The added alert
 */
export function addSecurityAlert(alert: Omit<SecurityAlert, 'id' | 'timestamp' | 'status'>): SecurityAlert {
  // Generate alert ID
  const id = `alert-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
  
  // Create the alert
  const securityAlert: SecurityAlert = {
    id,
    timestamp: new Date().toISOString(),
    status: 'new',
    ...alert
  };
  
  // Add to alerts
  securityAlerts.push(securityAlert);
  
  // Log the alert
  logger.security(`New security alert: ${securityAlert.message}`, {
    alertId: securityAlert.id,
    type: securityAlert.type,
    source: securityAlert.source,
    severity: securityAlert.severity,
    ip: securityAlert.ip,
    user: securityAlert.user
  });
  
  // Add to events
  addSecurityEvent({
    type: 'alert',
    message: `New ${securityAlert.severity} alert: ${securityAlert.message}`,
    alertId: securityAlert.id
  });
  
  // Invalidate status cache
  cachedSecurityStatus = null;
  
  return securityAlert;
}

/**
 * Add a security event
 * @param event The event to add
 * @returns The added event
 */
export function addSecurityEvent(event: any): any {
  // Generate event ID
  const id = `event-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
  
  // Create the event
  const securityEvent = {
    id,
    timestamp: new Date().toISOString(),
    ...event
  };
  
  // Add to events
  securityEvents.push(securityEvent);
  
  // Keep only the last 1000 events
  if (securityEvents.length > 1000) {
    securityEvents.shift();
  }
  
  // Invalidate status cache
  cachedSecurityStatus = null;
  
  return securityEvent;
}

/**
 * Acknowledge a security alert
 * @param alertId The alert ID
 * @param user The user acknowledging the alert
 * @returns True if the alert was acknowledged
 */
export function acknowledgeAlert(alertId: string, user: string): boolean {
  // Find the alert
  const alert = securityAlerts.find(a => a.id === alertId);
  
  if (!alert) {
    return false;
  }
  
  // Update the alert
  alert.status = 'acknowledged';
  alert.acknowledged = {
    by: user,
    at: new Date().toISOString()
  };
  
  // Log the acknowledgement
  logger.audit(user, `Acknowledged security alert ${alertId}`);
  
  // Add to events
  addSecurityEvent({
    type: 'alert_acknowledged',
    message: `Alert acknowledged by ${user}`,
    alertId
  });
  
  // Invalidate status cache
  cachedSecurityStatus = null;
  
  return true;
}

/**
 * Resolve a security alert
 * @param alertId The alert ID
 * @param user The user resolving the alert
 * @returns True if the alert was resolved
 */
export function resolveAlert(alertId: string, user: string): boolean {
  // Find the alert
  const alert = securityAlerts.find(a => a.id === alertId);
  
  if (!alert) {
    return false;
  }
  
  // Update the alert
  alert.status = 'resolved';
  alert.resolved = {
    by: user,
    at: new Date().toISOString()
  };
  
  // Log the resolution
  logger.audit(user, `Resolved security alert ${alertId}`);
  
  // Add to events
  addSecurityEvent({
    type: 'alert_resolved',
    message: `Alert resolved by ${user}`,
    alertId
  });
  
  // Invalidate status cache
  cachedSecurityStatus = null;
  
  return true;
}

/**
 * Get security alerts
 * @param options Filter options
 * @returns Filtered security alerts
 */
export function getSecurityAlerts(options: {
  limit?: number;
  offset?: number;
  severity?: string;
  status?: string;
  type?: string;
} = {}): SecurityAlert[] {
  // Apply filters
  let filtered = securityAlerts;
  
  if (options.severity) {
    filtered = filtered.filter(a => a.severity === options.severity);
  }
  
  if (options.status) {
    filtered = filtered.filter(a => a.status === options.status);
  }
  
  if (options.type) {
    filtered = filtered.filter(a => a.type === options.type);
  }
  
  // Sort by timestamp (newest first)
  filtered = filtered.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  
  // Apply pagination
  const limit = options.limit || filtered.length;
  const offset = options.offset || 0;
  
  return filtered.slice(offset, offset + limit);
}

/**
 * Get a security alert by ID
 * @param alertId The alert ID
 * @returns The alert or undefined if not found
 */
export function getSecurityAlertById(alertId: string): SecurityAlert | undefined {
  return securityAlerts.find(a => a.id === alertId);
}