/**
 * Sentinel 4.5 Security System - Dashboard Server
 * 
 * This module provides the server-side implementation of the security dashboard.
 */

import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { logger } from '../core/logger';
import { getConfig } from '../core/config-loader';
import { authenticateRequest } from '../middleware/auth';

/**
 * Setup the dashboard
 * @param app Express application
 * @param mountPath Path to mount the dashboard
 */
export function setupDashboard(app: express.Application, mountPath: string): void {
  logger.info(`Setting up security dashboard at ${mountPath}`);
  
  // Create router
  const dashboardRouter = express.Router();
  
  // Get configuration
  const config = getConfig();
  
  // Apply authentication if required
  if (config.integration.api.requireAuth) {
    dashboardRouter.use(authenticateRequest);
  }
  
  // Dashboard home
  dashboardRouter.get('/', (req: Request, res: Response) => {
    res.sendFile(path.join(__dirname, '../../public/dashboard/index.html'));
  });
  
  // API Data for dashboard
  dashboardRouter.get('/data', (req: Request, res: Response) => {
    // This endpoint would provide data for the dashboard
    // For now, we'll just return a simple structure
    res.json({
      timestamp: new Date().toISOString(),
      status: 'active',
      message: 'Sentinel 4.5 Security System is running'
    });
  });
  
  // Admin dashboard
  dashboardRouter.get('/admin', (req: Request, res: Response) => {
    // Check if user has admin role
    const userRoles = (req as any).user?.roles || [];
    const adminRoles = config.integration.api.adminRoles || ['admin', 'security_admin'];
    const isAdmin = userRoles.some((role: string) => adminRoles.includes(role));
    
    if (!isAdmin) {
      logger.security('Unauthorized access attempt to admin dashboard', {
        ip: req.ip,
        user: (req as any).user?.username || 'anonymous'
      });
      
      return res.status(403).send('Access denied');
    }
    
    res.sendFile(path.join(__dirname, '../../public/dashboard/admin.html'));
  });
  
  // Serve static assets for dashboard
  const publicDir = path.join(__dirname, '../../public/dashboard');
  if (fs.existsSync(publicDir)) {
    dashboardRouter.use('/assets', express.static(publicDir));
  } else {
    logger.warn(`Dashboard assets directory not found: ${publicDir}`);
    
    // Create a basic HTML response if assets are missing
    dashboardRouter.get('/', (req: Request, res: Response) => {
      const html = `
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Sentinel 4.5 Security Dashboard</title>
          <style>
            body {
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
              line-height: 1.6;
              color: #333;
              max-width: 800px;
              margin: 0 auto;
              padding: 20px;
            }
            h1 {
              color: #001f3f;
              border-bottom: 2px solid #001f3f;
              padding-bottom: 10px;
            }
            .status {
              background-color: #f0f0f0;
              padding: 20px;
              border-left: 4px solid #001f3f;
              margin: 20px 0;
            }
            .status.secure {
              border-left-color: #2ecc71;
            }
            .status.warning {
              border-left-color: #f39c12;
            }
            .status.critical {
              border-left-color: #e74c3c;
            }
            .card {
              border: 1px solid #ddd;
              border-radius: 4px;
              padding: 20px;
              margin: 20px 0;
              box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            .meta {
              color: #666;
              font-size: 0.9em;
            }
          </style>
        </head>
        <body>
          <h1>Sentinel 4.5 Security Dashboard</h1>
          
          <div class="status secure">
            <h2>System Status: Secure</h2>
            <p>No active threats detected.</p>
          </div>
          
          <div class="card">
            <h3>Security Modules</h3>
            <p>15 modules active, 0 inactive, 0 failed</p>
          </div>
          
          <div class="card">
            <h3>Recent Alerts</h3>
            <p>No alerts in the last 24 hours.</p>
          </div>
          
          <div class="card">
            <h3>System Metrics</h3>
            <p>Memory: 32%, CPU: 8%, Disk: 45%</p>
          </div>
          
          <div class="meta">
            <p>Sentinel 4.5 - Running on server: ${process.env.SERVER_ADDRESS || '188.245.209.124'}</p>
            <p>Last updated: ${new Date().toLocaleString()}</p>
          </div>
        </body>
        </html>
      `;
      
      res.send(html);
    });
  }
  
  // Mount the dashboard router
  app.use(mountPath, dashboardRouter);
  
  logger.info('Security dashboard setup complete');
}