/**
 * Sentinel 4.5 Security System - Health Checker
 * 
 * This module provides health checking functionality for the security system.
 */

import os from 'os';
import fs from 'fs';
import path from 'path';
import { logger } from '../core/logger';
import { getConfig } from '../core/config-loader';
import { getSecurityModules } from '../core/security-modules';

// Interface for system health
interface SystemHealth {
  status: 'healthy' | 'degraded' | 'unhealthy';
  timestamp: string;
  uptime: number;
  memory: {
    total: number;
    free: number;
    used: number;
    usedPercent: number;
  };
  cpu: {
    cores: number;
    load: number[];
    loadPercent: number;
  };
  disk: {
    total: number;
    free: number;
    used: number;
    usedPercent: number;
  };
  modules: {
    total: number;
    active: number;
    inactive: number;
    failed: number;
  };
  issues: string[];
}

// Cache for disk stats to avoid frequent disk access
const diskStatsCache = {
  stats: null as any,
  lastCheck: 0,
  cacheDuration: 60 * 1000, // 1 minute
};

/**
 * Check the system health
 * @returns System health information
 */
export function checkServerHealth(): SystemHealth {
  logger.debug('Checking system health');
  
  try {
    // Get memory info
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const memPercent = (usedMem / totalMem) * 100;
    
    // Get CPU info
    const cpuCores = os.cpus().length;
    const loadAvg = os.loadavg();
    const cpuLoadPercent = (loadAvg[0] / cpuCores) * 100;
    
    // Get disk info
    const diskInfo = getDiskInfo();
    
    // Get module status
    const modules = getSecurityModules();
    const activeModules = modules.filter(m => m.status === 'active');
    const inactiveModules = modules.filter(m => m.status === 'inactive');
    const failedModules = modules.filter(m => m.status === 'failed');
    
    // Check for issues
    const issues: string[] = [];
    
    // Check memory usage
    const memoryThreshold = getConfig().monitoring.resources.memoryThreshold || 85;
    if (memPercent > memoryThreshold) {
      issues.push(`Memory usage is high: ${memPercent.toFixed(1)}%`);
    }
    
    // Check CPU usage
    const cpuThreshold = getConfig().monitoring.resources.cpuThreshold || 90;
    if (cpuLoadPercent > cpuThreshold) {
      issues.push(`CPU usage is high: ${cpuLoadPercent.toFixed(1)}%`);
    }
    
    // Check disk usage
    const diskThreshold = getConfig().monitoring.resources.diskThreshold || 90;
    if (diskInfo.usedPercent > diskThreshold) {
      issues.push(`Disk usage is high: ${diskInfo.usedPercent.toFixed(1)}%`);
    }
    
    // Check modules
    if (failedModules.length > 0) {
      issues.push(`${failedModules.length} security modules failed: ${failedModules.map(m => m.id).join(', ')}`);
    }
    
    // Determine overall status
    let status: 'healthy' | 'degraded' | 'unhealthy' = 'healthy';
    
    if (issues.length > 0) {
      status = issues.length > 2 ? 'unhealthy' : 'degraded';
    }
    
    // Build health object
    const health: SystemHealth = {
      status,
      timestamp: new Date().toISOString(),
      uptime: os.uptime(),
      memory: {
        total: totalMem,
        free: freeMem,
        used: usedMem,
        usedPercent: memPercent,
      },
      cpu: {
        cores: cpuCores,
        load: loadAvg,
        loadPercent: cpuLoadPercent,
      },
      disk: diskInfo,
      modules: {
        total: modules.length,
        active: activeModules.length,
        inactive: inactiveModules.length,
        failed: failedModules.length,
      },
      issues,
    };
    
    // Log health status if issues are found
    if (issues.length > 0) {
      logger.warn('System health check found issues', { health });
    } else {
      logger.debug('System health check passed');
    }
    
    return health;
  } catch (error) {
    logger.error('Failed to check system health', { error });
    
    // Return unhealthy status
    return {
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      uptime: os.uptime(),
      memory: {
        total: 0,
        free: 0,
        used: 0,
        usedPercent: 0,
      },
      cpu: {
        cores: 0,
        load: [0, 0, 0],
        loadPercent: 0,
      },
      disk: {
        total: 0,
        free: 0,
        used: 0,
        usedPercent: 0,
      },
      modules: {
        total: 0,
        active: 0,
        inactive: 0,
        failed: 0,
      },
      issues: [
        'Failed to check system health: ' + (error instanceof Error ? error.message : String(error)),
      ],
    };
  }
}

/**
 * Get disk information
 * @returns Disk information
 */
function getDiskInfo(): { total: number; free: number; used: number; usedPercent: number } {
  // Use cached values if available
  const now = Date.now();
  if (diskStatsCache.stats && now - diskStatsCache.lastCheck < diskStatsCache.cacheDuration) {
    return diskStatsCache.stats;
  }
  
  try {
    // Set a default value in case of error
    const defaultDiskInfo = {
      total: 0,
      free: 0,
      used: 0,
      usedPercent: 0,
    };
    
    // Check available disk space - only works on Linux or OSX
    if (process.platform === 'win32') {
      return defaultDiskInfo;
    }
    
    // Use a different approach based on platform
    let diskInfo = defaultDiskInfo;
    
    // On Linux, try to read from /proc/mounts or use df
    if (process.platform === 'linux') {
      // Try to get disk usage for the current directory
      const logDir = getConfig().logging.directory || './logs';
      const df = require('child_process').execSync(`df -k ${logDir}`).toString().trim();
      
      // Parse df output
      const lines = df.split('\n');
      if (lines.length >= 2) {
        const parts = lines[1].split(/\s+/);
        if (parts.length >= 6) {
          const total = parseInt(parts[1]) * 1024;
          const used = parseInt(parts[2]) * 1024;
          const free = parseInt(parts[3]) * 1024;
          const usedPercent = (used / total) * 100;
          
          diskInfo = {
            total,
            free,
            used,
            usedPercent,
          };
        }
      }
    } else if (process.platform === 'darwin') { // OSX
      const df = require('child_process').execSync('df -k /').toString().trim();
      
      // Parse df output
      const lines = df.split('\n');
      if (lines.length >= 2) {
        const parts = lines[1].split(/\s+/);
        if (parts.length >= 9) {
          const total = parseInt(parts[3]) * 1024;
          const used = parseInt(parts[4]) * 1024;
          const free = parseInt(parts[5]) * 1024;
          const usedPercent = (used / total) * 100;
          
          diskInfo = {
            total,
            free,
            used,
            usedPercent,
          };
        }
      }
    }
    
    // Cache the results
    diskStatsCache.stats = diskInfo;
    diskStatsCache.lastCheck = now;
    
    return diskInfo;
  } catch (error) {
    logger.error('Failed to get disk info', { error });
    
    // Return default values
    return {
      total: 0,
      free: 0,
      used: 0,
      usedPercent: 0,
    };
  }
}