/**
 * Sentinel 4.5 Security System - System Metrics
 * 
 * This module provides system metrics monitoring for the security system.
 */

import os from 'os';
import { logger } from '../core/logger';
import { getConfig } from '../core/config-loader';
import { getSecurityModules } from '../core/security-modules';
import { getSecurityStatus } from '../core/security-status';

/**
 * System metrics interface
 */
export interface SystemMetrics {
  timestamp: string;
  server: {
    hostname: string;
    platform: string;
    uptime: number; // seconds
    startTime: string;
    nodeVersion: string;
  };
  resources: {
    cpu: {
      cores: number;
      load: number[]; // 1, 5, 15 minute averages
      usage: number; // percentage (0-100)
    };
    memory: {
      total: number; // bytes
      free: number; // bytes
      used: number; // bytes
      usage: number; // percentage (0-100)
    };
    disk: {
      total: number; // bytes
      free: number; // bytes
      used: number; // bytes
      usage: number; // percentage (0-100)
    };
  };
  security: {
    modulesTotal: number;
    modulesActive: number;
    alertsTotal: number;
    alertsNew: number;
    threatLevel: number; // 0-100
    securityScore: number; // 0-100
  };
  performance: {
    requestsTotal: number;
    requestsPerMinute: number;
    averageResponseTime: number; // milliseconds
    errorRate: number; // percentage (0-100)
  };
}

// Performance tracking (in a real implementation, this would use a proper metrics system)
const performanceMetrics = {
  requestsTotal: 0,
  requestsLastMinute: [] as number[],
  responseTimes: [] as number[],
  errors: 0
};

// Add request metric
export function trackRequest(responseTime: number, isError: boolean): void {
  performanceMetrics.requestsTotal++;
  performanceMetrics.requestsLastMinute.push(Date.now());
  performanceMetrics.responseTimes.push(responseTime);
  
  if (isError) {
    performanceMetrics.errors++;
  }
  
  // Keep only the last 1000 response times
  if (performanceMetrics.responseTimes.length > 1000) {
    performanceMetrics.responseTimes.shift();
  }
  
  // Keep only requests from the last minute
  const now = Date.now();
  const oneMinuteAgo = now - 60 * 1000;
  performanceMetrics.requestsLastMinute = performanceMetrics.requestsLastMinute.filter(
    time => time > oneMinuteAgo
  );
}

/**
 * Get system metrics
 * @returns System metrics
 */
export async function getSystemMetrics(): Promise<SystemMetrics> {
  logger.debug('Getting system metrics');
  
  try {
    // Get CPU cores and load
    const cpuCores = os.cpus().length;
    const loadAvg = os.loadavg();
    const cpuUsage = (loadAvg[0] / cpuCores) * 100; // Convert to percentage
    
    // Get memory usage
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const memUsage = (usedMem / totalMem) * 100; // Convert to percentage
    
    // Get disk usage
    const diskInfo = await getDiskInfo();
    
    // Get security status
    const securityStatus = getSecurityStatus();
    const securityModules = getSecurityModules();
    
    // Calculate performance metrics
    const requestsPerMinute = performanceMetrics.requestsLastMinute.length;
    
    // Calculate average response time
    const averageResponseTime = performanceMetrics.responseTimes.length > 0
      ? performanceMetrics.responseTimes.reduce((sum, time) => sum + time, 0) / performanceMetrics.responseTimes.length
      : 0;
    
    // Calculate error rate
    const errorRate = performanceMetrics.requestsTotal > 0
      ? (performanceMetrics.errors / performanceMetrics.requestsTotal) * 100
      : 0;
    
    // Build metrics object
    const metrics: SystemMetrics = {
      timestamp: new Date().toISOString(),
      server: {
        hostname: os.hostname(),
        platform: os.platform(),
        uptime: os.uptime(),
        startTime: new Date(Date.now() - os.uptime() * 1000).toISOString(),
        nodeVersion: process.version
      },
      resources: {
        cpu: {
          cores: cpuCores,
          load: loadAvg,
          usage: cpuUsage
        },
        memory: {
          total: totalMem,
          free: freeMem,
          used: usedMem,
          usage: memUsage
        },
        disk: {
          total: diskInfo.total,
          free: diskInfo.free,
          used: diskInfo.used,
          usage: diskInfo.usage
        }
      },
      security: {
        modulesTotal: securityModules.length,
        modulesActive: securityModules.filter(m => m.status === 'active').length,
        alertsTotal: securityStatus.alertCounts.total,
        alertsNew: securityStatus.alertCounts.new,
        threatLevel: securityStatus.threatLevel,
        securityScore: securityStatus.securityScore
      },
      performance: {
        requestsTotal: performanceMetrics.requestsTotal,
        requestsPerMinute,
        averageResponseTime,
        errorRate
      }
    };
    
    return metrics;
  } catch (error) {
    logger.error('Failed to get system metrics', { error });
    
    // Return minimal metrics in case of error
    return {
      timestamp: new Date().toISOString(),
      server: {
        hostname: os.hostname(),
        platform: os.platform(),
        uptime: os.uptime(),
        startTime: new Date(Date.now() - os.uptime() * 1000).toISOString(),
        nodeVersion: process.version
      },
      resources: {
        cpu: {
          cores: 0,
          load: [0, 0, 0],
          usage: 0
        },
        memory: {
          total: 0,
          free: 0,
          used: 0,
          usage: 0
        },
        disk: {
          total: 0,
          free: 0,
          used: 0,
          usage: 0
        }
      },
      security: {
        modulesTotal: 0,
        modulesActive: 0,
        alertsTotal: 0,
        alertsNew: 0,
        threatLevel: 0,
        securityScore: 0
      },
      performance: {
        requestsTotal: 0,
        requestsPerMinute: 0,
        averageResponseTime: 0,
        errorRate: 0
      }
    };
  }
}

/**
 * Get disk information
 * @returns Disk info
 */
async function getDiskInfo(): Promise<{ total: number; free: number; used: number; usage: number }> {
  try {
    // Default disk info
    const defaultDiskInfo = {
      total: 0,
      free: 0,
      used: 0,
      usage: 0
    };
    
    // In a real implementation, this would use a proper disk space library
    // For now, we'll use a simplified approach based on platform
    const platform = os.platform();
    
    // Use different approach based on platform
    if (platform === 'linux') {
      try {
        // Try to get disk usage for the root partition
        const { execSync } = require('child_process');
        const dfOutput = execSync('df -k /').toString();
        
        // Parse df output
        const lines = dfOutput.trim().split('\n');
        if (lines.length >= 2) {
          const parts = lines[1].split(/\s+/);
          if (parts.length >= 6) {
            const total = parseInt(parts[1]) * 1024;
            const used = parseInt(parts[2]) * 1024;
            const free = parseInt(parts[3]) * 1024;
            const usage = (used / total) * 100;
            
            return { total, free, used, usage };
          }
        }
      } catch (error) {
        logger.error('Failed to get disk info from df command', { error });
      }
    } else if (platform === 'darwin') { // macOS
      try {
        // Try to get disk usage for the root partition
        const { execSync } = require('child_process');
        const dfOutput = execSync('df -k /').toString();
        
        // Parse df output
        const lines = dfOutput.trim().split('\n');
        if (lines.length >= 2) {
          const parts = lines[1].split(/\s+/);
          if (parts.length >= 6) {
            const total = parseInt(parts[1]) * 1024;
            const used = parseInt(parts[2]) * 1024;
            const free = parseInt(parts[3]) * 1024;
            const usage = (used / total) * 100;
            
            return { total, free, used, usage };
          }
        }
      } catch (error) {
        logger.error('Failed to get disk info from df command', { error });
      }
    } else if (platform === 'win32') { // Windows
      try {
        // Try to get disk usage for the C drive
        const { execSync } = require('child_process');
        const wmic = execSync('wmic logicaldisk where "DeviceID=\'C:\'" get Size,FreeSpace').toString();
        
        // Parse wmic output
        const lines = wmic.trim().split('\n');
        if (lines.length >= 2) {
          const parts = lines[1].trim().split(/\s+/);
          if (parts.length >= 2) {
            const free = parseInt(parts[0]);
            const total = parseInt(parts[1]);
            const used = total - free;
            const usage = (used / total) * 100;
            
            return { total, free, used, usage };
          }
        }
      } catch (error) {
        logger.error('Failed to get disk info from wmic command', { error });
      }
    }
    
    // Fallback to default values
    return defaultDiskInfo;
  } catch (error) {
    logger.error('Failed to get disk info', { error });
    
    // Return default values
    return {
      total: 0,
      free: 0,
      used: 0,
      usage: 0
    };
  }
}