# Sentinel 4.5 Integration Guide for Server 188.245.209.124

This guide provides detailed instructions for integrating the Sentinel 4.5 security system with your existing school platforms on server 188.245.209.124.

## Server Information

- **Server IP:** 188.245.209.124
- **Sentinel Port:** 8080 (default, can be changed in configuration)
- **Dashboard URL:** https://188.245.209.124/security-dashboard
- **API Endpoint:** https://188.245.209.124/api/security

## Prerequisites

Before beginning the integration, ensure that:

1. You have SSH access to the server
2. Node.js 16+ is installed on the server
3. The deploy user has appropriate permissions
4. Nginx or another web server is configured for reverse proxy

## Integration Options

Sentinel 4.5 can be integrated with your school platforms in three ways:

1. **Full Integration:** Embed the Sentinel security system directly into your application
2. **API Integration:** Use the Sentinel API endpoints for security features
3. **Dashboard Only:** Only integrate the security dashboard for monitoring

## Installation

Follow these steps to install Sentinel on the server:

```bash
# SSH into the server
ssh deploy@188.245.209.124

# Create the deployment directory
mkdir -p /var/www/sentinel
mkdir -p /var/log/sentinel

# Give appropriate permissions
chmod 755 /var/www/sentinel
chmod 755 /var/log/sentinel

# Clone the Sentinel repository (if using Git)
# git clone https://your-repo-url.git /var/www/sentinel

# OR extract the provided tarball
tar -xzf sentinel-4.5.tar.gz -C /var/www/sentinel

# Navigate to the Sentinel directory
cd /var/www/sentinel

# Install dependencies
npm ci --production

# Configure environment variables
cp .env.production .env

# Edit environment variables with your specific settings
nano .env

# Build the application
npm run build

# Test the installation
node dist/index.js
```

## Nginx Configuration

Add this to your Nginx configuration to integrate Sentinel:

```nginx
# Sentinel Security System
location /api/security {
    proxy_pass http://localhost:8080/api/security;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_cache_bypass $http_upgrade;
}

location /security-dashboard {
    proxy_pass http://localhost:8080/security-dashboard;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_cache_bypass $http_upgrade;
}

location /sentinel-assets {
    proxy_pass http://localhost:8080/sentinel-assets;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_cache_bypass $http_upgrade;
    expires 7d;
    add_header Cache-Control "public, max-age=604800";
}
```

Reload Nginx after making changes:

```bash
sudo systemctl reload nginx
```

## Frontend Integration

### 1. Add Security Status Bar

Add this HTML snippet to your school platform's header or navigation:

```html
<!-- Sentinel Security Status Bar -->
<div class="sentinel-status-bar">
  <script src="https://188.245.209.124/sentinel-assets/js/status-bar.js"></script>
  <div id="sentinel-status-container"></div>
  <script>
    new SentinelStatusBar({
      container: '#sentinel-status-container',
      apiUrl: '/api/security',
      theme: 'dark', // or 'light'
      showDetails: true
    });
  </script>
</div>
```

### 2. Link to Security Dashboard

Add a link to the security dashboard in your admin navigation:

```html
<a href="/security-dashboard" class="nav-link">
  <span class="icon"><i class="fas fa-shield-alt"></i></span>
  <span>Security Dashboard</span>
</a>
```

### 3. API Integration for Enhanced Security

If you want to use Sentinel's security features in your application code:

#### Node.js Example

```javascript
// In your Express application
const express = require('express');
const axios = require('axios');
const app = express();

// Middleware to check security status
app.use(async (req, res, next) => {
  try {
    // Check with Sentinel if this request should be allowed
    const securityCheck = await axios.post('http://localhost:8080/api/security/check-request', {
      ip: req.ip,
      path: req.path,
      method: req.method,
      headers: req.headers,
      body: req.body
    });
    
    if (securityCheck.data.block) {
      return res.status(403).json({ error: 'Request blocked by security system' });
    }
    
    next();
  } catch (error) {
    // If Sentinel is unavailable, log and continue
    console.error('Security check failed:', error.message);
    next();
  }
});

// Your routes go here
app.get('/', (req, res) => {
  res.send('Hello World!');
});

app.listen(3000);
```

## Platform-Specific Integration

### The Lawyer Makers Integration

For the Lawyer Makers platform, add this to your main layout file:

```html
<!-- Sentinel Security Integration for Lawyer Makers -->
<script>
  (function() {
    // Sentinel security configuration
    window.sentinelConfig = {
      platform: 'lawyer-makers',
      apiUrl: '/api/security',
      statusBarSelector: '#security-status',
      enableProtection: true,
      reportViolations: true
    };
    
    // Load the Sentinel script
    var script = document.createElement('script');
    script.src = 'https://188.245.209.124/sentinel-assets/js/sentinel-client.js';
    script.async = true;
    document.head.appendChild(script);
  })();
</script>

<!-- Security Status Display -->
<div id="security-status" class="security-status-container"></div>
```

### Neurodivergent School Integration

For the Neurodivergent School platform, use the child-friendly security components:

```html
<!-- Sentinel Security Integration for Neurodivergent School -->
<script>
  (function() {
    // Sentinel security configuration with child-friendly interface
    window.sentinelConfig = {
      platform: 'neurodivergent-school',
      apiUrl: '/api/security',
      statusBarSelector: '#kid-friendly-security',
      theme: 'superhero',
      enableProtection: true,
      reportViolations: true,
      simplifiedUI: true
    };
    
    // Load the Sentinel script
    var script = document.createElement('script');
    script.src = 'https://188.245.209.124/sentinel-assets/js/sentinel-client.js';
    script.async = true;
    document.head.appendChild(script);
  })();
</script>

<!-- Kid-Friendly Security Status -->
<div id="kid-friendly-security" class="superhero-security-container"></div>
```

### Language School Integration

For the Language School platform:

```html
<!-- Sentinel Security Integration for Language School -->
<script>
  (function() {
    // Sentinel security configuration
    window.sentinelConfig = {
      platform: 'language-school',
      apiUrl: '/api/security',
      statusBarSelector: '#language-security-status',
      enableProtection: true,
      reportViolations: true
    };
    
    // Load the Sentinel script
    var script = document.createElement('script');
    script.src = 'https://188.245.209.124/sentinel-assets/js/sentinel-client.js';
    script.async = true;
    document.head.appendChild(script);
  })();
</script>

<!-- Security Status Display -->
<div id="language-security-status" class="security-status-container"></div>
```

## Service Management

Sentinel 4.5 is configured to run as a systemd service. Use these commands to manage it:

```bash
# Start the Sentinel service
sudo systemctl start sentinel

# Stop the Sentinel service
sudo systemctl stop sentinel

# Restart after configuration changes
sudo systemctl restart sentinel

# View logs
sudo journalctl -u sentinel -f

# Check status
sudo systemctl status sentinel
```

## Monitoring and Maintenance

Regular monitoring is essential:

1. Check the Sentinel dashboard regularly
2. Monitor system logs: `tail -f /var/log/sentinel/system.log`
3. Monitor security events: `tail -f /var/log/sentinel/security.log`
4. Set up automated email alerts for critical security events

## Troubleshooting

If you encounter issues:

1. Check the Sentinel logs in `/var/log/sentinel/`
2. Verify the service is running: `systemctl status sentinel`
3. Check for firewall issues: `sudo ufw status`
4. Verify Nginx configuration: `sudo nginx -t`
5. Test the API directly: `curl http://localhost:8080/api/security/status`

## Security Best Practices

1. Regularly update the Sentinel system
2. Keep the JWT_SECRET and COOKIE_SECRET secure
3. Configure proper CORS settings to prevent unauthorized access
4. Use HTTPS for all communications
5. Regularly check security alerts and audit logs

## Support and Updates

For support with Sentinel 4.5:

- Check the documentation in `/var/www/sentinel/docs`
- Contact the ShatziiOS team for assistance

---

This integration guide is specific to server 188.245.209.124. For other environments, configurations may need to be adjusted.