/**
 * Sentinel 4.5 Server Configuration for 188.245.209.124
 * 
 * This configuration file contains optimized settings for running
 * the Sentinel security system on the specified production server.
 */

module.exports = {
  // Server-specific configuration
  server: {
    host: "188.245.209.124",
    port: process.env.SENTINEL_PORT || 8080,
    behindProxy: true,
    trustedProxies: ["127.0.0.1", "localhost"],
    
    // API and dashboard paths
    apiPrefix: "/api/security",
    dashboardPath: "/security-dashboard",
    
    // Cross-Origin Resource Sharing settings
    cors: {
      origins: [
        "https://188.245.209.124",
        "http://188.245.209.124",
        "https://lawyer-makers.shatzios.edu",
        "https://neurodivergent-school.shatzios.edu",
        "https://language-school.shatzios.edu"
      ],
      credentials: true
    },
    
    // Rate limiting for API endpoints
    rateLimit: {
      windowMs: 15 * 60 * 1000, // 15 minutes
      max: 100, // limit each IP to 100 requests per windowMs
      standardHeaders: true,
      legacyHeaders: false,
    }
  },
  
  // Performance optimization settings
  performance: {
    // Node.js optimization
    nodejs: {
      maxOldSpaceSize: 2048, // 2GB memory limit for Node.js process
      gcInterval: 30 * 60 * 1000, // Run garbage collection every 30 minutes
    },
    
    // Database connection pooling
    database: {
      poolMin: 2,
      poolMax: 10,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 2000
    },
    
    // Caching strategy
    cache: {
      enabled: true,
      ttl: 5 * 60, // 5 minutes cache TTL
      checkPeriod: 60, // Check for expired items every 60 seconds
      maxItems: 1000, // Maximum items in memory cache
    },
    
    // HTTP response compression
    compression: {
      enabled: true,
      level: 6, // Compression level (0-9)
      threshold: 1024 // Minimum size in bytes to compress response
    }
  },
  
  // Security modules configuration - optimized for production
  modules: {
    // Authentication security - prevent brute force attacks
    authSecurity: {
      enabled: true,
      maxAttempts: 5,
      lockoutTime: 15 * 60, // 15 minutes
      ipWhitelist: ["127.0.0.1", "188.245.209.124"]
    },
    
    // Rate limiting to prevent DoS
    rateLimiting: {
      enabled: true,
      standardWindowMs: 60 * 1000, // 1 minute
      standardMax: 60, // 60 requests per minute for standard endpoints
      
      authWindowMs: 5 * 60 * 1000, // 5 minutes
      authMax: 20, // 20 auth requests per 5 minutes
      
      adminWindowMs: 15 * 60 * 1000, // 15 minutes
      adminMax: 100 // 100 admin requests per 15 minutes
    },
    
    // File upload protection
    fileUploadSecurity: {
      enabled: true,
      maxSize: 10 * 1024 * 1024, // 10MB
      scanUploads: true,
      allowedTypes: [
        "image/jpeg", "image/png", "image/gif", "image/webp",
        "application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "text/plain", "text/csv", "application/json"
      ]
    },
    
    // Honeypot system to detect attackers
    honeypot: {
      enabled: true,
      trapRoutes: [
        "/admin.php",
        "/wp-login.php",
        "/phpmyadmin",
        "/.env",
        "/config.json",
        "/administrator",
        "/console"
      ],
      delayResponse: true,
      trackIpAddresses: true
    },
    
    // Anomaly detection for unusual patterns
    anomalyDetection: {
      enabled: true,
      sensitivity: 0.7, // 0.0-1.0, higher is more sensitive
      baselineTrainingDays: 7, // Use 7 days of data for baseline
      minimumDataPoints: 100, // Minimum data points before alerting
      alertOnDeviation: 3.0 // Alert on 3 standard deviations
    },
    
    // IP blocking for malicious addresses
    ipBlocking: {
      enabled: true,
      blockTime: 24 * 60 * 60, // 24 hours
      maxViolationsBeforeBlock: 5,
      checkReputation: true,
      ipWhitelist: ["127.0.0.1", "188.245.209.124"]
    },
    
    // Other modules with optimized settings
    contentSecurity: { enabled: true },
    threatIntelligence: { enabled: true },
    databaseMonitor: { enabled: true },
    userBehavior: { enabled: true },
    correlationEngine: { enabled: true, maxEventsCorrelated: 1000 },
    secureSession: { enabled: true, maxConcurrentSessions: 3 },
    vulnerabilityScanner: { enabled: true, scanInterval: 24 * 60 * 60 }, // Daily
    apiKeyManager: { enabled: true },
    securityScoring: { enabled: true }
  },
  
  // Logging configuration - optimized for production
  logging: {
    level: "info", // In production, only log info and above
    format: "json", // JSON format for easier parsing
    directory: "/var/log/sentinel",
    maxFiles: 14, // Keep 14 days of logs
    maxSize: "50m", // 50MB max file size
    
    // Security event logging
    securityEvents: {
      logToFile: true,
      alertOnHigh: true,
      retentionDays: 90 // Keep security logs for 90 days
    },
    
    // Log rotation
    rotation: {
      enabled: true,
      frequency: "daily",
      maxFiles: 90,
      compress: true
    }
  },
  
  // System monitoring
  monitoring: {
    // Resource monitoring
    resources: {
      enabled: true,
      checkInterval: 60 * 1000, // Check every 60 seconds
      memoryThreshold: 85, // Alert when memory usage exceeds 85%
      cpuThreshold: 90, // Alert when CPU usage exceeds 90%
      diskThreshold: 90 // Alert when disk usage exceeds 90%
    },
    
    // Health checks
    healthCheck: {
      enabled: true,
      endpoint: "/health",
      interval: 5 * 60 * 1000, // Check every 5 minutes
      timeout: 5000 // 5 second timeout
    }
  },
  
  // Integration with the main application
  integration: {
    // Authentication integration
    authentication: {
      useParentAuth: true, // Use the parent application's authentication
      jwtSecret: process.env.JWT_SECRET || "change-this-in-production",
      cookieSecret: process.env.COOKIE_SECRET || "change-this-in-production"
    },
    
    // API integration
    api: {
      standalone: false, // False means integrated with main app
      requireAuth: true,
      adminRoles: ["admin", "security_admin"]
    },
    
    // Dashboard integration
    dashboard: {
      embedInParentApp: true,
      theme: "dark",
      autoRefresh: true,
      refreshInterval: 30 // 30 seconds
    }
  }
};