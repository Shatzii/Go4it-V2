# Sentinel 4.5 Security System

A comprehensive security solution designed for ShatziiOS educational platforms. This standalone version is optimized for deployment on dedicated security servers.

## Overview

Sentinel 4.5 is a modular security system that provides protection for web applications. It includes:

- Authentication security
- Rate limiting and DDoS protection
- Honeypot traps
- File upload security
- Anomaly detection
- IP blocking and tracking
- Content security
- User behavior analysis
- Event correlation
- Security dashboard

## Target Deployment Environment

This version is specifically optimized for the following server:

- Server IP: 188.245.209.124
- Configuration: 4 CPU, 16GB RAM, 160GB Storage
- OS: Linux (Ubuntu 20.04 LTS)

## Integration With School Platforms

Sentinel 4.5 integrates with the following ShatziiOS educational platforms:

1. **The Lawyer Makers** - Led by Mason Barrett
2. **K-6 Primary Neurodivergent School**
3. **7-12 Secondary Neurodivergent School**
4. **Language Learning School**

## System Requirements

- Node.js 16.x or higher
- NPM 8.x or higher
- 2GB RAM (minimum)
- 500MB disk space (minimum)

## Key Features

### 1. Real-time Security Monitoring

- Dashboard with live security status
- Alert system with severity levels
- Threat visualization

### 2. Intelligent Protection

- Machine learning-based anomaly detection
- Adaptive rate limiting
- Behavioral analysis

### 3. Comprehensive Logging

- Detailed security event logs
- Audit trails for administrative actions
- Log rotation and retention management

### 4. Integration Capabilities

- API for integration with parent platforms
- Webhook notifications
- Cross-platform security coordination

## Quick Start

### Installation

```bash
# Clone the repository
git clone https://github.com/ShatziiOS/sentinel-4.5.git

# Navigate to project directory
cd sentinel-4.5

# Install dependencies
npm install

# Build the project
npm run build
```

### Configuration

Copy the example environment file and configure it for your environment:

```bash
cp .env.example .env
```

Edit the `.env` file with your specific settings.

### Running in Development

```bash
npm run dev
```

### Deployment

For production deployment, use the deployment script:

```bash
npm run deploy:prod
```

This will deploy to the target server at 188.245.209.124.

## API Documentation

The security API is available at `/api/security` and includes endpoints for:

- System status checks
- Alert management
- Security module configuration
- Security scans
- Metrics retrieval

## Dashboard

The security dashboard is available at `/security-dashboard` and provides:

- Overall security status
- Active threats
- Module status
- System metrics
- Alert management

## Modular Architecture

Sentinel 4.5 is built with a modular architecture that allows for easy extension and customization:

```
src/
├── api/           # API endpoints
├── core/          # Core system modules
├── dashboard/     # Dashboard components
├── middleware/    # Express middleware
└── utils/         # Utility functions
```

## Integration Guide

For detailed integration instructions, see [SERVER-INTEGRATION-GUIDE.md](./SERVER-INTEGRATION-GUIDE.md).

## License

Copyright © ShatziiOS. All rights reserved.

## Support

For support, contact the ShatziiOS security team.