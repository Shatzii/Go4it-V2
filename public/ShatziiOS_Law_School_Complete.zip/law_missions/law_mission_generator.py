import json
import os
from datetime import datetime

def generate_law_mission(title, category, difficulty):
    mission = {
        "title": title,
        "category": category,
        "difficulty": difficulty,
        "xp_reward": 50 * difficulty,
        "instructions": f"Prepare your case and submit your written brief. Category: {category}",
        "created": datetime.now().isoformat()
    }

    os.makedirs("law_missions", exist_ok=True)
    filename = f"law_missions/{title.replace(' ', '_')}_{category}_{difficulty}.json"
    with open(filename, "w") as f:
        json.dump(mission, f, indent=4)

    return filename

if __name__ == "__main__":
    print("Law mission created:", generate_law_mission("Mock Trial: Galactic Trade War", "Interstellar Law", 3))