# Go4It Sports Production Deployment Instructions

This guide will help you deploy the Go4It Sports platform to your production server.

## Server Requirements

- Ubuntu 20.04 LTS or newer
- Node.js 20.x or newer
- PostgreSQL 14.x or newer
- Nginx 1.20.x or newer
- Let's Encrypt for SSL

## Deployment Steps

### 1. Prepare the Server

```bash
# Install required packages
sudo apt update
sudo apt install -y nginx postgresql postgresql-contrib certbot python3-certbot-nginx

# Install Node.js 20.x
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install PM2 for process management
sudo npm install -g pm2
```

### 2. Set up the PostgreSQL Database

```bash
# Create database user and database
sudo -u postgres psql -c "CREATE USER go4it WITH PASSWORD 'your_secure_password';"
sudo -u postgres psql -c "CREATE DATABASE go4it_sports OWNER go4it;"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE go4it_sports TO go4it;"
```

### 3. Deploy the Application

```bash
# Create application directory
sudo mkdir -p /var/www/go4itsports.org
sudo chown $USER:$USER /var/www/go4itsports.org

# Extract the deployment package
unzip go4it-deployment-*.zip -d /var/www/go4itsports.org/

# Install dependencies
cd /var/www/go4itsports.org
npm install --production

# Set up environment variables
cp .env.example .env
nano .env  # Edit with your actual values
```

### 4. Configure Nginx

```bash
# Copy Nginx configuration
sudo cp nginx.conf /etc/nginx/sites-available/go4itsports.org

# Create symbolic link
sudo ln -s /etc/nginx/sites-available/go4itsports.org /etc/nginx/sites-enabled/

# Test and reload Nginx
sudo nginx -t
sudo systemctl reload nginx
```

### 5. Set up SSL with Let's Encrypt

```bash
sudo certbot --nginx -d go4itsports.org -d www.go4itsports.org
```

### 6. Start the Application

```bash
# Using PM2 for process management
pm2 start server/production-server.js --name go4it-api
pm2 save
pm2 startup
```

## Maintenance

### Database Backups

Create a daily backup script:

```bash
sudo mkdir -p /var/backups/go4itsports

# Create backup script
cat > /etc/cron.daily/backup-go4itsports << 'EOF'
#!/bin/bash
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
BACKUP_DIR="/var/backups/go4itsports"
FILENAME="go4it_sports_$TIMESTAMP.sql"

# Create backup
sudo -u postgres pg_dump go4it_sports > "$BACKUP_DIR/$FILENAME"

# Compress backup
gzip "$BACKUP_DIR/$FILENAME"

# Remove backups older than 30 days
find "$BACKUP_DIR" -name "go4it_sports_*.sql.gz" -mtime +30 -delete
EOF

sudo chmod +x /etc/cron.daily/backup-go4itsports
```

### Log Rotation

```bash
sudo nano /etc/logrotate.d/go4itsports

# Add the following content
/var/www/go4itsports.org/logs/*.log {
  daily
  missingok
  rotate 14
  compress
  delaycompress
  notifempty
  create 0640 www-data www-data
}
```

## Troubleshooting

If you encounter issues:

1. Check the application logs: `tail -f /var/www/go4itsports.org/logs/app.log`
2. Check Nginx logs: `sudo tail -f /var/log/nginx/error.log`
3. Verify the database connection: `psql -U go4it -h localhost -d go4it_sports`
4. Restart the application: `pm2 restart go4it-api`

For additional support, contact: support@go4itsports.org
