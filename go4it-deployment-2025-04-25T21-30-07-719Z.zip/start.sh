#!/bin/bash
# Go4It Sports Production Startup Script

# Ensure we're in the script directory
cd "$(dirname "$0")"

# Load environment variables
if [ -f .env ]; then
  export $(grep -v '^#' .env | xargs)
fi

# Set production environment
export NODE_ENV=production

# Start the server
echo "Starting Go4It Sports API server..."
node server/production-server.js