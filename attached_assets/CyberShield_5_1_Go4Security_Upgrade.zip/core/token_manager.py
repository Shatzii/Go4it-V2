
def validate_token(token):
    return token == "valid_token_123"
