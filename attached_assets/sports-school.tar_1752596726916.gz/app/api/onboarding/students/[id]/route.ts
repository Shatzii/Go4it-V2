import { NextRequest, NextResponse } from 'next/server'

// Sample students data (same as in the main route)
const SAMPLE_STUDENTS = [
  {
    id: '1',
    name: 'Emma Rodriguez',
    grade: 'K',
    school: 'primary',
    learningStyle: 'visual',
    accommodations: ['none'],
    strengths: ['mathematics', 'fine_arts'],
    challenges: ['english_language_arts'],
    interests: ['drawing', 'puzzles', 'animals'],
    parentEmail: 'maria.rodriguez@email.com',
    emergencyContact: '555-0123',
    medicalNotes: 'No known allergies',
    technologyAccess: { hasDevice: true, hasInternet: true, deviceType: 'tablet' }
  },
  {
    id: '2',
    name: 'Marcus Johnson',
    grade: '3',
    school: 'primary',
    learningStyle: 'kinesthetic',
    accommodations: ['adhd'],
    strengths: ['science', 'physical_education'],
    challenges: ['mathematics'],
    interests: ['sports', 'experiments', 'building'],
    parentEmail: 'jennifer.johnson@email.com',
    emergencyContact: '555-0456',
    medicalNotes: 'ADHD - takes medication daily',
    technologyAccess: { hasDevice: true, hasInternet: true, deviceType: 'laptop' }
  },
  {
    id: '3',
    name: 'Sophia Chen',
    grade: '6',
    school: 'secondary',
    learningStyle: 'reading_writing',
    accommodations: ['dyslexia'],
    strengths: ['social_studies', 'fine_arts'],
    challenges: ['english_language_arts'],
    interests: ['history', 'writing', 'theater'],
    parentEmail: 'david.chen@email.com',
    emergencyContact: '555-0789',
    medicalNotes: 'Dyslexia - needs extra time for reading',
    technologyAccess: { hasDevice: true, hasInternet: true, deviceType: 'laptop' }
  },
  {
    id: '4',
    name: 'Aiden O\'Connor',
    grade: '9',
    school: 'secondary',
    learningStyle: 'multimodal',
    accommodations: ['anxiety'],
    strengths: ['mathematics', 'science'],
    challenges: ['social_studies'],
    interests: ['coding', 'robotics', 'music'],
    parentEmail: 'sarah.oconnor@email.com',
    emergencyContact: '555-0012',
    medicalNotes: 'Anxiety disorder - needs calm environment',
    technologyAccess: { hasDevice: true, hasInternet: true, deviceType: 'desktop' }
  },
  {
    id: '5',
    name: 'Zoe Williams',
    grade: '11',
    school: 'law',
    learningStyle: 'auditory',
    accommodations: ['none'],
    strengths: ['english_language_arts', 'social_studies'],
    challenges: ['mathematics'],
    interests: ['debate', 'law', 'public_speaking'],
    parentEmail: 'robert.williams@email.com',
    emergencyContact: '555-0345',
    medicalNotes: 'No medical concerns',
    technologyAccess: { hasDevice: true, hasInternet: true, deviceType: 'laptop' }
  },
  {
    id: '6',
    name: 'Isabella Martinez',
    grade: '1',
    school: 'primary',
    learningStyle: 'visual',
    accommodations: ['none'],
    strengths: ['fine_arts', 'english_language_arts'],
    challenges: ['mathematics'],
    interests: ['art', 'reading', 'music'],
    parentEmail: 'carlos.martinez@email.com',
    emergencyContact: '555-0678',
    medicalNotes: 'No medical concerns',
    technologyAccess: { hasDevice: true, hasInternet: true, deviceType: 'tablet' }
  },
  {
    id: '7',
    name: 'Ethan Thompson',
    grade: '2',
    school: 'primary',
    learningStyle: 'kinesthetic',
    accommodations: ['none'],
    strengths: ['physical_education', 'mathematics'],
    challenges: ['english_language_arts'],
    interests: ['sports', 'building', 'outdoors'],
    parentEmail: 'lisa.thompson@email.com',
    emergencyContact: '555-0901',
    medicalNotes: 'No known allergies',
    technologyAccess: { hasDevice: true, hasInternet: true, deviceType: 'laptop' }
  },
  {
    id: '8',
    name: 'Ava Patel',
    grade: '4',
    school: 'primary',
    learningStyle: 'reading_writing',
    accommodations: ['none'],
    strengths: ['english_language_arts', 'social_studies'],
    challenges: ['science'],
    interests: ['writing', 'history', 'languages'],
    parentEmail: 'raj.patel@email.com',
    emergencyContact: '555-0234',
    medicalNotes: 'No medical concerns',
    technologyAccess: { hasDevice: true, hasInternet: true, deviceType: 'desktop' }
  },
  {
    id: '9',
    name: 'Noah Brown',
    grade: '5',
    school: 'primary',
    learningStyle: 'multimodal',
    accommodations: ['none'],
    strengths: ['science', 'mathematics'],
    challenges: ['fine_arts'],
    interests: ['science', 'technology', 'gaming'],
    parentEmail: 'melissa.brown@email.com',
    emergencyContact: '555-0567',
    medicalNotes: 'No known allergies',
    technologyAccess: { hasDevice: true, hasInternet: true, deviceType: 'laptop' }
  },
  {
    id: '10',
    name: 'Mia Davis',
    grade: '7',
    school: 'secondary',
    learningStyle: 'auditory',
    accommodations: ['none'],
    strengths: ['english_language_arts', 'fine_arts'],
    challenges: ['mathematics'],
    interests: ['music', 'theater', 'languages'],
    parentEmail: 'james.davis@email.com',
    emergencyContact: '555-0890',
    medicalNotes: 'No medical concerns',
    technologyAccess: { hasDevice: true, hasInternet: true, deviceType: 'laptop' }
  },
  {
    id: '11',
    name: 'Liam Wilson',
    grade: '8',
    school: 'secondary',
    learningStyle: 'kinesthetic',
    accommodations: ['adhd'],
    strengths: ['physical_education', 'science'],
    challenges: ['english_language_arts'],
    interests: ['sports', 'experiments', 'robotics'],
    parentEmail: 'sarah.wilson@email.com',
    emergencyContact: '555-0123',
    medicalNotes: 'ADHD - needs movement breaks',
    technologyAccess: { hasDevice: true, hasInternet: true, deviceType: 'tablet' }
  },
  {
    id: '12',
    name: 'Olivia Garcia',
    grade: '10',
    school: 'secondary',
    learningStyle: 'visual',
    accommodations: ['dyslexia'],
    strengths: ['fine_arts', 'social_studies'],
    challenges: ['english_language_arts'],
    interests: ['art', 'history', 'photography'],
    parentEmail: 'miguel.garcia@email.com',
    emergencyContact: '555-0456',
    medicalNotes: 'Dyslexia - needs visual aids',
    technologyAccess: { hasDevice: true, hasInternet: true, deviceType: 'laptop' }
  },
  {
    id: '13',
    name: 'Alexander Lee',
    grade: '12',
    school: 'secondary',
    learningStyle: 'reading_writing',
    accommodations: ['none'],
    strengths: ['english_language_arts', 'mathematics'],
    challenges: ['physical_education'],
    interests: ['writing', 'debate', 'college prep'],
    parentEmail: 'jennifer.lee@email.com',
    emergencyContact: '555-0789',
    medicalNotes: 'No medical concerns',
    technologyAccess: { hasDevice: true, hasInternet: true, deviceType: 'desktop' }
  }
]

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const student = SAMPLE_STUDENTS.find(s => s.id === params.id)
    
    if (!student) {
      return NextResponse.json({ error: 'Student not found' }, { status: 404 })
    }
    
    return NextResponse.json(student)
  } catch (error) {
    console.error('Error fetching student:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}