import { useEffect, useState } from 'react';
import { supabase } from './supabaseClient';

function App() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      setUser(user);
    });
  }, []);

  return (
    <div>
      <h1>Welcome to Go4it AI</h1>
      {user ? <p>Hello, {user.email}</p> : <p>Please log in.</p>}
    </div>
  );
}

export default App;