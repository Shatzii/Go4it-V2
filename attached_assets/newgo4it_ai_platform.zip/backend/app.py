from flask import Flask, request, jsonify
import cv2
import mediapipe as mp
import os

app = Flask(__name__)
mp_pose = mp.solutions.pose

@app.route('/analyze', methods=['POST'])
def analyze_video():
    video = request.files['video']
    video_path = os.path.join('/tmp', video.filename)
    video.save(video_path)

    pose = mp_pose.Pose()
    cap = cv2.VideoCapture(video_path)
    total_frames = 0

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        result = pose.process(image_rgb)
        if result.pose_landmarks:
            total_frames += 1

    cap.release()
    os.remove(video_path)
    return jsonify({'score': total_frames, 'movement': 'Explosive'})

if __name__ == '__main__':
    app.run(debug=True)