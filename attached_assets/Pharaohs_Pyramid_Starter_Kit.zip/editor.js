require.config({ paths: { 'vs': 'https://unpkg.com/monaco-editor@0.44.0/min/vs' }});
require(['vs/editor/editor.main'], function() {
  window.editor = monaco.editor.create(document.getElementById('editor'), {
    value: '// Pharaoh's Sacred Editor\n// Begin your creations here...',
    language: 'javascript',
    theme: 'vs-dark'
  });
});