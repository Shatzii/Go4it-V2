var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc4) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc4 = __getOwnPropDesc(from, key)) || desc4.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// shared/schema.ts
import { pgTable, text, serial, integer, boolean, timestamp, json, real, date, jsonb, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
var measurementSystemSchema, users, athleteProfiles, coachProfiles, videos, videoAnalyses, userAgreements, sportRecommendations, apiKeys, ncaaEligibility, ncaaCoreCourses, gradeScales, ncaaSlidingScales, ncaaDocuments, ncaaRegistration, coachConnections, achievements, messages, blogPosts, siteImages, contentBlocks, featuredAthletes, skills, challenges, athleteChallenges, recoveryLogs, socialMediaScouts, mediaPartnershipScouts, mediaPartnerDiscoveries, cityInfluencerScouts, cityInfluencerDiscoveries, transferPortalMonitors, ncaaTeamRosters, transferPortalEntries, coachRecruitingBoards, athleteDiscoveries, socialMediaAudits, garCategories, garSubcategories, garAthleteRatings, garRatingHistory, athleteStarProfiles, fanClubFollowers, leaderboardEntries, workoutPlaylists, workoutExercises, filmComparisons, comparisonVideos, comparisonAnalyses, spotlightProfiles, playerProgress, xpTransactions, playerBadges, workoutVerifications, videoHighlights, highlightGeneratorConfigs2, workoutVerificationCheckpoints, weightRoomEquipment, playerEquipment, combineTourEvents, registrations, payments, insertUserSchema, insertUserAgreementSchema, insertUserWithMeasurementSchema, insertAthleteProfileSchema, insertCoachProfileSchema, insertVideoSchema, insertVideoWithFileSchema, insertVideoAnalysisSchema, insertSportRecommendationSchema, insertNcaaEligibilitySchema, insertNcaaCoreCourseSchema, insertGradeScaleSchema, insertNcaaSlidingScaleSchema, insertNcaaDocumentSchema, insertNcaaRegistrationSchema, insertCoachConnectionSchema, insertAchievementSchema, insertMessageSchema, insertSkillSchema, insertChallengeSchema, insertAthleteChallengeSchema, insertRecoveryLogSchema, insertFanClubFollowerSchema, insertLeaderboardEntrySchema, insertWorkoutPlaylistSchema, insertWorkoutExerciseSchema, insertBlogPostSchema, insertFeaturedAthleteSchema, insertSiteImageSchema, insertContentBlockSchema, insertFilmComparisonSchema, insertComparisonVideoSchema, insertComparisonAnalysisSchema, insertSpotlightProfileSchema, insertPlayerProgressSchema, insertXpTransactionSchema, insertPlayerBadgeSchema, insertWorkoutVerificationSchema, insertWorkoutVerificationCheckpointSchema, insertWeightRoomEquipmentSchema, insertPlayerEquipmentSchema, insertVideoHighlightSchema, insertHighlightGeneratorConfigSchema, insertCombineTourEventSchema, insertRegistrationSchema, insertPaymentSchema, insertApiKeySchema, insertAthleteStarProfileSchema, onboardingProgress, athleteJourneyMap, journeyMilestones, insertOnboardingProgressSchema, insertAthleteJourneyMapSchema, insertJourneyMilestoneSchema, musicArtists, musicTracks, musicPlaylists, playlistTracks, musicListeningHistory, musicUserPreferences, artistNilDeals, insertMusicArtistSchema, insertMusicTrackSchema, insertMusicPlaylistSchema, insertPlaylistTrackSchema, insertMusicListeningHistorySchema, insertMusicUserPreferencesSchema, insertArtistNilDealSchema, podcastShows, podcastHosts, podcastEpisodes, podcastGuests, podcastComments, podcastSubscriptions, podcastListeningHistory, podcastTopics, podcastEpisodeTopics, podcastCollaborationRequests, insertPodcastShowSchema, insertPodcastHostSchema, insertPodcastEpisodeSchema, insertPodcastGuestSchema, insertPodcastCommentSchema, insertPodcastSubscriptionSchema, insertPodcastListeningHistorySchema, insertPodcastTopicSchema, insertPodcastEpisodeTopicSchema, insertPodcastCollaborationRequestSchema;
var init_schema = __esm({
  "shared/schema.ts"() {
    "use strict";
    measurementSystemSchema = z.enum(["metric", "imperial"]);
    users = pgTable("users", {
      id: serial("id").primaryKey(),
      username: text("username").notNull().unique(),
      password: text("password").notNull(),
      email: text("email").notNull(),
      name: text("name").notNull(),
      role: text("role").notNull().default("athlete"),
      // athlete, coach, admin
      profileImage: text("profile_image"),
      bio: text("bio"),
      phoneNumber: text("phone_number"),
      createdAt: timestamp("created_at").defaultNow(),
      measurementSystem: text("measurement_system").default("metric")
      // 'metric' or 'imperial'
    });
    athleteProfiles = pgTable("athlete_profiles", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      height: integer("height"),
      // in cm
      weight: integer("weight"),
      // in kg
      age: integer("age"),
      school: text("school"),
      graduationYear: integer("graduation_year"),
      sportsInterest: text("sports_interest").array(),
      motionScore: integer("motion_score").default(0),
      // 0-100
      profileCompletionPercentage: integer("profile_completion_percentage").default(0)
      // 0-100
    });
    coachProfiles = pgTable("coach_profiles", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      institution: text("institution"),
      sports: text("sports").array(),
      level: text("level"),
      // college, high school, club
      experience: integer("experience"),
      // years
      achievements: text("achievements")
    });
    videos = pgTable("videos", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      title: text("title").notNull(),
      description: text("description"),
      filePath: text("file_path").notNull(),
      uploadDate: timestamp("upload_date").defaultNow(),
      analyzed: boolean("analyzed").default(false),
      sportType: text("sport_type"),
      thumbnailPath: text("thumbnail_path")
    });
    videoAnalyses = pgTable("video_analyses", {
      id: serial("id").primaryKey(),
      videoId: integer("video_id").notNull().references(() => videos.id),
      analysisDate: timestamp("analysis_date").defaultNow(),
      motionData: json("motion_data").notNull(),
      // Stores motion analysis data points
      overallScore: integer("overall_score").notNull(),
      // 0-100
      feedback: text("feedback").notNull(),
      improvementTips: text("improvement_tips").array(),
      keyFrameTimestamps: real("key_frame_timestamps").array(),
      // timestamps of key moments in the video
      garScores: json("gar_scores")
      // Detailed GAR scoring breakdown by category
    });
    userAgreements = pgTable("user_agreements", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      agreementType: text("agreement_type").notNull(),
      // nda, terms, privacy, etc.
      version: text("version").notNull(),
      // Version of the agreement
      acceptedAt: timestamp("accepted_at").defaultNow(),
      ipAddress: text("ip_address"),
      // IP address of the user when accepted
      userAgent: text("user_agent")
      // Browser/device info
    });
    sportRecommendations = pgTable("sport_recommendations", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      sport: text("sport").notNull(),
      matchPercentage: integer("match_percentage").notNull(),
      // 0-100
      positionRecommendation: text("position_recommendation"),
      potentialLevel: text("potential_level"),
      // e.g., NCAA Div I, Club, etc.
      reasonForMatch: text("reason_for_match"),
      recommendationDate: timestamp("recommendation_date").defaultNow()
    });
    apiKeys = pgTable("api_keys", {
      id: serial("id").primaryKey(),
      keyType: text("key_type").notNull().unique(),
      // openai, stripe, sendgrid, twilio, twitter, reddit_client_id, reddit_client_secret, etc.
      keyValue: text("key_value").notNull(),
      addedAt: timestamp("added_at").defaultNow(),
      lastUsed: timestamp("last_used"),
      isActive: boolean("is_active").default(true)
    });
    ncaaEligibility = pgTable("ncaa_eligibility", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      coreCoursesCompleted: integer("core_courses_completed").default(0),
      coreCoursesRequired: integer("core_courses_required").default(16),
      gpa: real("gpa"),
      gpaMeetsRequirement: boolean("gpa_meets_requirement").default(false),
      satScore: integer("sat_score"),
      actScore: integer("act_score"),
      testScoresMeetRequirement: boolean("test_scores_meet_requirement").default(false),
      minimumRequiredTestScore: integer("minimum_required_test_score"),
      isInternationalStudent: boolean("is_international_student").default(false),
      countryOfEducation: text("country_of_education"),
      diplomaType: text("diploma_type"),
      internationalGradeScale: text("international_grade_scale"),
      // A-F, 1-10, 1-20, etc.
      hasTranslatedDocuments: boolean("has_translated_documents").default(false),
      amateurismStatus: text("amateurism_status").default("incomplete"),
      // incomplete, pending, verified
      ncaaDivision: text("ncaa_division").default("division_i"),
      // division_i, division_ii
      overallEligibilityStatus: text("overall_eligibility_status").default("incomplete"),
      // incomplete, partial, complete
      academicRedshirt: boolean("academic_redshirt").default(false),
      qualificationPercentage: integer("qualification_percentage").default(0),
      // 0-100
      lastUpdated: timestamp("last_updated").defaultNow()
    });
    ncaaCoreCourses = pgTable("ncaa_core_courses", {
      id: serial("id").primaryKey(),
      eligibilityId: integer("eligibility_id").notNull().references(() => ncaaEligibility.id),
      courseName: text("course_name").notNull(),
      courseType: text("course_type").notNull(),
      // english, math, science, social_science, additional
      gradeEarned: text("grade_earned"),
      originalGrade: text("original_grade"),
      // For international students, original grade before translation
      translatedGrade: text("translated_grade"),
      // For international students, translated to US scale
      gradePoints: real("grade_points"),
      // Calculated grade points for GPA
      creditHours: real("credit_hours").notNull(),
      qualityPoints: real("quality_points"),
      // creditHours * gradePoints
      completed: boolean("completed").default(false),
      inProgress: boolean("in_progress").default(false),
      ncaaApproved: boolean("ncaa_approved").default(false),
      verificationStatus: text("verification_status").default("pending"),
      // pending, verified, rejected
      completionDate: date("completion_date"),
      yearTaken: integer("year_taken"),
      semesterTaken: text("semester_taken"),
      // fall, spring, summer
      school: text("school"),
      country: text("country"),
      isInternationalCourse: boolean("is_international_course").default(false),
      translationMethod: text("translation_method"),
      // How the grade was translated
      notes: text("notes")
    });
    gradeScales = pgTable("grade_scales", {
      id: serial("id").primaryKey(),
      country: text("country").notNull(),
      educationSystem: text("education_system").notNull(),
      // e.g., A-levels, IB, French Baccalaureate
      originalScale: json("original_scale").notNull(),
      // JSON with original grading scale
      usEquivalentScale: json("us_equivalent_scale").notNull(),
      // JSON with US equivalent
      conversionFormula: text("conversion_formula"),
      // Formula to convert grades if applicable
      notes: text("notes"),
      lastUpdated: timestamp("last_updated").defaultNow()
    });
    ncaaSlidingScales = pgTable("ncaa_sliding_scales", {
      id: serial("id").primaryKey(),
      effectiveDate: date("effective_date").notNull(),
      division: text("division").notNull(),
      // division_i, division_ii
      coreGpa: real("core_gpa").notNull(),
      minSatScore: integer("min_sat_score"),
      // Minimum SAT score for this GPA level
      minActScore: integer("min_act_score"),
      // Minimum ACT score for this GPA level
      fullQualifierStatus: boolean("full_qualifier_status").default(true),
      // Whether this combination qualifies for full eligibility
      academicRedshirtStatus: boolean("academic_redshirt_status").default(false),
      // Whether this combination qualifies for academic redshirt
      notes: text("notes"),
      isCurrentScale: boolean("is_current_scale").default(true)
    });
    ncaaDocuments = pgTable("ncaa_documents", {
      id: serial("id").primaryKey(),
      eligibilityId: integer("eligibility_id").notNull().references(() => ncaaEligibility.id),
      documentType: text("document_type").notNull(),
      // transcript, test_score, amateurism, medical, waiver
      filePath: text("file_path").notNull(),
      fileName: text("file_name").notNull(),
      uploadDate: timestamp("upload_date").defaultNow(),
      verificationStatus: text("verification_status").default("pending"),
      // pending, verified, rejected
      verificationNotes: text("verification_notes"),
      verifiedBy: integer("verified_by").references(() => users.id),
      verificationDate: timestamp("verification_date")
    });
    ncaaRegistration = pgTable("ncaa_registration", {
      id: serial("id").primaryKey(),
      eligibilityId: integer("eligibility_id").notNull().references(() => ncaaEligibility.id),
      ncaaId: text("ncaa_id"),
      registrationDate: timestamp("registration_date"),
      registrationStatus: text("registration_status").default("not_started"),
      // not_started, in_progress, completed
      academicStatus: text("academic_status"),
      // qualifier, partial_qualifier, non_qualifier, pending
      amateurismCertified: boolean("amateurism_certified").default(false),
      divisionLevel: text("division_level"),
      // division_i, division_ii
      finalCertificationDate: timestamp("final_certification_date")
    });
    coachConnections = pgTable("coach_connections", {
      id: serial("id").primaryKey(),
      coachId: integer("coach_id").notNull().references(() => users.id),
      athleteId: integer("athlete_id").notNull().references(() => users.id),
      connectionStatus: text("connection_status").notNull().default("pending"),
      // pending, accepted, rejected
      connectionDate: timestamp("connection_date").defaultNow(),
      notes: text("notes"),
      lastContact: timestamp("last_contact")
    });
    achievements = pgTable("achievements", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      title: text("title").notNull(),
      description: text("description").notNull(),
      achievementType: text("achievement_type").notNull(),
      // video, profile, ncaa, connection
      earnedDate: timestamp("earned_date").defaultNow(),
      iconType: text("icon_type")
      // For storing icon identifier
    });
    messages = pgTable("messages", {
      id: serial("id").primaryKey(),
      senderId: integer("sender_id").notNull().references(() => users.id),
      recipientId: integer("recipient_id").notNull().references(() => users.id),
      content: text("content").notNull(),
      createdAt: timestamp("sent_at").defaultNow(),
      isRead: boolean("read").default(false)
    });
    blogPosts = pgTable("blog_posts", {
      id: serial("id").primaryKey(),
      title: text("title").notNull(),
      content: text("content").notNull(),
      summary: text("summary").notNull(),
      coverImage: text("cover_image"),
      authorId: integer("author_id").references(() => users.id),
      category: text("category").notNull(),
      // nextup, analysis, combine, tips
      publishDate: timestamp("publish_date").defaultNow(),
      featured: boolean("featured").default(false),
      slug: text("slug").notNull().unique(),
      tags: text("tags").array()
    });
    siteImages = pgTable("site_images", {
      id: serial("id").primaryKey(),
      name: text("name").notNull(),
      path: text("path").notNull(),
      alt: text("alt").notNull(),
      location: text("location").notNull(),
      // "logo", "header", "background", "footer-logo", "banner", "icon"
      active: boolean("active").default(true),
      uploadDate: timestamp("upload_date").defaultNow()
    });
    contentBlocks = pgTable("content_blocks", {
      id: serial("id").primaryKey(),
      identifier: text("identifier").notNull().unique(),
      // unique key to identify this content block
      title: text("title").notNull(),
      content: text("content").notNull(),
      section: text("section").notNull(),
      // e.g., "home", "about", "services"
      order: integer("order").default(0),
      active: boolean("active").default(true),
      lastUpdated: timestamp("last_updated").defaultNow(),
      lastUpdatedBy: integer("last_updated_by").references(() => users.id),
      metadata: jsonb("metadata")
      // for storing additional structured data
    });
    featuredAthletes = pgTable("featured_athletes", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      coverImage: text("cover_image"),
      featuredVideo: text("featured_video").references(() => videos.id),
      highlightText: text("highlight_text").notNull(),
      sportPosition: text("sport_position"),
      starRating: integer("star_rating").notNull(),
      featuredStats: json("featured_stats"),
      featuredDate: timestamp("featured_date").defaultNow(),
      order: integer("order").default(0),
      active: boolean("active").default(true)
    });
    skills = pgTable("skills", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      skillName: text("skill_name").notNull(),
      skillCategory: text("skill_category").notNull(),
      // speed, strength, agility, technique, etc
      skillLevel: integer("skill_level").notNull().default(0),
      // 0-5 rating
      xpPoints: integer("xp_points").notNull().default(0),
      nextLevelXp: integer("next_level_xp").notNull().default(100),
      updatedAt: timestamp("updated_at").defaultNow()
    });
    challenges = pgTable("challenges", {
      id: serial("id").primaryKey(),
      title: text("title").notNull(),
      description: text("description").notNull(),
      difficulty: text("difficulty").notNull(),
      // easy, medium, hard
      xpReward: integer("xp_reward").notNull(),
      category: text("category").notNull(),
      // speed, strength, agility, etc
      createdAt: timestamp("created_at").defaultNow(),
      expiresAt: timestamp("expires_at"),
      creatorId: integer("creator_id").references(() => users.id)
      // null for system challenges
    });
    athleteChallenges = pgTable("athlete_challenges", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      challengeId: integer("challenge_id").notNull().references(() => challenges.id),
      status: text("status").notNull().default("accepted"),
      // accepted, completed, failed
      startedAt: timestamp("started_at").defaultNow(),
      completedAt: timestamp("completed_at"),
      proofUrl: text("proof_url")
      // video or photo proof of completion
    });
    recoveryLogs = pgTable("recovery_logs", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      logDate: date("log_date").notNull().defaultNow(),
      sleepHours: real("sleep_hours"),
      sorenessLevel: integer("soreness_level"),
      // 1-10
      energyLevel: integer("energy_level"),
      // 1-10
      hydrationLevel: integer("hydration_level"),
      // 1-10
      notes: text("notes"),
      overallRecoveryScore: integer("overall_recovery_score")
      // 0-100
    });
    socialMediaScouts = pgTable("social_media_scouts", {
      id: serial("id").primaryKey(),
      name: text("name").notNull(),
      description: text("description").notNull(),
      active: boolean("active").default(true),
      lastRunAt: timestamp("last_run_at"),
      sportFocus: text("sport_focus").array(),
      // basketball, football, soccer, etc.
      ageRangeMin: integer("age_range_min").default(12),
      ageRangeMax: integer("age_range_max").default(18),
      locationFocus: text("location_focus").array(),
      // States or regions to search
      keywordsToTrack: text("keywords_to_track").array(),
      platformsToSearch: text("platforms_to_search").array(),
      // instagram, twitter, tiktok, etc.
      createdAt: timestamp("created_at").defaultNow(),
      createdBy: integer("created_by").references(() => users.id),
      discoveryCount: integer("discovery_count").default(0)
      // How many athletes discovered
    });
    mediaPartnershipScouts = pgTable("media_partnership_scouts", {
      id: serial("id").primaryKey(),
      name: text("name").notNull(),
      description: text("description").notNull(),
      active: boolean("active").default(true),
      lastRunAt: timestamp("last_run_at"),
      sportFocus: text("sport_focus").array(),
      // Which sports to focus on
      mediaTypes: text("media_types").array(),
      // podcast, instagram, youtube, tiktok, newsletter, blog, etc.
      followerThreshold: integer("follower_threshold").default(1e4),
      // Minimum followers/subscribers
      locationFocus: text("location_focus").array(),
      // Geographic focus
      keywordsToTrack: text("keywords_to_track").array(),
      // Relevant keywords
      exclusionTerms: text("exclusion_terms").array(),
      // Terms to avoid
      createdAt: timestamp("created_at").defaultNow(),
      createdBy: integer("created_by").references(() => users.id),
      discoveryCount: integer("discovery_count").default(0)
    });
    mediaPartnerDiscoveries = pgTable("media_partner_discoveries", {
      id: serial("id").primaryKey(),
      scoutId: integer("scout_id").references(() => mediaPartnershipScouts.id),
      name: text("name").notNull(),
      // Name of the media outlet/podcast/page
      platform: text("platform").notNull(),
      // instagram, podcast, youtube, etc.
      url: text("url").notNull(),
      // Profile/channel URL
      contactName: text("contact_name"),
      // Name of primary contact
      contactEmail: text("contact_email"),
      contactPhone: text("contact_phone"),
      followerCount: integer("follower_count"),
      audienceType: text("audience_type"),
      // athletes, coaches, parents, fans, etc.
      averageEngagement: real("average_engagement"),
      // Percentage of followers who engage
      sports: text("sports").array(),
      // Sports they cover
      location: text("location"),
      // Geographic base
      recentTopics: text("recent_topics").array(),
      // Recent trending topics
      contentQuality: integer("content_quality").default(0),
      // AI-rated quality score (0-100)
      relevanceScore: integer("relevance_score").default(0),
      // AI-rated relevance to platform (0-100)
      partnershipPotential: integer("partnership_potential").default(0),
      // AI-rated potential (0-100)
      discoveredAt: timestamp("discovered_at").defaultNow(),
      lastCheckedAt: timestamp("last_checked_at").defaultNow(),
      status: text("status").default("new"),
      // new, contacted, negotiating, partnered, rejected
      assignedTo: integer("assigned_to").references(() => users.id),
      notes: text("notes"),
      partnershipTerms: json("partnership_terms"),
      // Details of any established partnership
      partnershipStartDate: timestamp("partnership_start_date"),
      partnershipEndDate: timestamp("partnership_end_date"),
      partnershipResults: json("partnership_results")
      // Metrics from the partnership
    });
    cityInfluencerScouts = pgTable("city_influencer_scouts", {
      id: serial("id").primaryKey(),
      name: text("name").notNull(),
      description: text("description").notNull(),
      active: boolean("active").default(true),
      lastRunAt: timestamp("last_run_at"),
      city: text("city").notNull(),
      // Target city
      state: text("state").notNull(),
      // State/province
      sportFocus: text("sport_focus").array(),
      // basketball, football, soccer, etc.
      platforms: text("platforms").array(),
      // instagram, tiktok, youtube, etc.
      minFollowers: integer("min_followers").default(5e3),
      maxInfluencers: integer("max_influencers").default(10),
      // Number of top influencers to identify
      createdAt: timestamp("created_at").defaultNow(),
      createdBy: integer("created_by").references(() => users.id),
      discoveryCount: integer("discovery_count").default(0),
      lastUpdated: timestamp("last_updated").defaultNow(),
      combineEventId: integer("combine_event_id")
      // Link to combine event if applicable
    });
    cityInfluencerDiscoveries = pgTable("city_influencer_discoveries", {
      id: serial("id").primaryKey(),
      scoutId: integer("scout_id").references(() => cityInfluencerScouts.id),
      name: text("name").notNull(),
      username: text("username").notNull(),
      platform: text("platform").notNull(),
      url: text("url").notNull(),
      bio: text("bio"),
      followerCount: integer("follower_count"),
      engagementRate: real("engagement_rate"),
      // Average engagement percentage
      audienceDemo: json("audience_demo"),
      // Demographics of audience
      sports: text("sports").array(),
      localityScore: integer("locality_score").default(0),
      // How connected to the local area (0-100)
      influenceRank: integer("influence_rank"),
      // Rank within the city (1-10)
      contactEmail: text("contact_email"),
      contactPhone: text("contact_phone"),
      discoveredAt: timestamp("discovered_at").defaultNow(),
      lastCheckedAt: timestamp("last_checked_at").defaultNow(),
      status: text("status").default("new"),
      // new, contacted, confirmed, declined
      assignedTo: integer("assigned_to").references(() => users.id),
      notes: text("notes"),
      combineRole: text("combine_role"),
      // Role at the Get Verified Combine
      compensation: json("compensation"),
      // Compensation details
      mediaDeliverables: text("media_deliverables").array(),
      // Content they'll create
      contractStatus: text("contract_status").default("none"),
      // none, pending, signed
      pastPerformance: json("past_performance")
      // Metrics from past partnerships
    });
    transferPortalMonitors = pgTable("transfer_portal_monitors", {
      id: serial("id").primaryKey(),
      name: text("name").notNull(),
      description: text("description").notNull(),
      active: boolean("active").default(true),
      sportType: text("sport_type").notNull(),
      // basketball, football, soccer, etc.
      divisions: text("divisions").array(),
      // NCAA D1, D2, D3, NAIA, JUCO, etc.
      conferences: text("conferences").array(),
      // SEC, Big Ten, ACC, etc.
      monitorType: text("monitor_type").notNull(),
      // roster-changes, player-portal-entries, commitment-flips
      updateFrequency: integer("update_frequency").default(360),
      // seconds between updates (default: 6 minutes)
      lastRunAt: timestamp("last_run_at"),
      alertThreshold: integer("alert_threshold").default(3),
      // Number of changes to trigger alert
      notifyCoaches: boolean("notify_coaches").default(true),
      positionGroups: text("position_groups").array(),
      // QB, RB, WR, etc. for football
      createdAt: timestamp("created_at").defaultNow(),
      createdBy: integer("created_by").references(() => users.id),
      transferCount: integer("transfer_count").default(0)
      // Number of transfers detected
    });
    ncaaTeamRosters = pgTable("ncaa_team_rosters", {
      id: serial("id").primaryKey(),
      school: text("school").notNull(),
      mascot: text("mascot"),
      conference: text("conference").notNull(),
      division: text("division").notNull(),
      // D1, D2, D3
      sport: text("sport").notNull(),
      season: text("season").notNull(),
      // 2024-2025
      rosterCount: integer("roster_count"),
      // Current player count
      scholarshipCount: integer("scholarship_count"),
      // Current scholarship count
      scholarshipLimit: integer("scholarship_limit"),
      // Max allowed scholarships
      rosterPositionCounts: json("roster_position_counts"),
      // Count by position
      rosterStatus: text("roster_status"),
      // normal, low, overstocked
      lastUpdated: timestamp("last_updated").defaultNow(),
      logoUrl: text("logo_url"),
      teamUrl: text("team_url"),
      coachingStaff: json("coaching_staff"),
      positionNeeds: json("position_needs"),
      // Current recruiting needs by position
      transfersIn: integer("transfers_in").default(0),
      // Count of incoming transfers
      transfersOut: integer("transfers_out").default(0),
      // Count of outgoing transfers
      recentRosterChanges: json("recent_roster_changes"),
      academicRequirements: json("academic_requirements"),
      // Min GPA, test scores, etc.
      priorityRecruitingAreas: text("priority_recruiting_areas").array()
      // States/regions
    });
    transferPortalEntries = pgTable("transfer_portal_entries", {
      id: serial("id").primaryKey(),
      playerName: text("player_name").notNull(),
      previousSchool: text("previous_school").notNull(),
      sport: text("sport").notNull(),
      position: text("position").notNull(),
      eligibilityRemaining: text("eligibility_remaining"),
      // "1 year", "2 years", etc.
      height: text("height"),
      weight: text("weight"),
      hometown: text("hometown"),
      highSchool: text("high_school"),
      starRating: integer("star_rating"),
      // Original recruiting stars (1-5)
      portalEntryDate: timestamp("portal_entry_date").notNull(),
      lastSeasonStats: json("last_season_stats"),
      careerStats: json("career_stats"),
      academicInfo: json("academic_info"),
      // GPA, major, graduation status
      injuryHistory: json("injury_history"),
      videoHighlights: text("video_highlights").array(),
      portalStatus: text("portal_status").default("active"),
      // active, committed, withdrawn
      committedTo: text("committed_to"),
      commitDate: timestamp("commit_date"),
      bestFitSchools: text("best_fit_schools").array(),
      // AI-generated recommendations
      fitReasons: json("fit_reasons"),
      // Reasons for recommended schools
      transferRating: integer("transfer_rating"),
      // AI-calculated impact rating (1-100)
      notes: text("notes"),
      socialMediaHandles: json("social_media_handles"),
      contactInfo: json("contact_info"),
      agentName: text("agent_name"),
      portalDeadline: timestamp("portal_deadline"),
      niLDeals: json("nil_deals"),
      // Previous NIL arrangements
      lastUpdated: timestamp("last_updated").defaultNow()
    });
    coachRecruitingBoards = pgTable("coach_recruiting_boards", {
      id: serial("id").primaryKey(),
      coachId: integer("coach_id").notNull().references(() => users.id),
      transferId: integer("transfer_id").notNull().references(() => transferPortalEntries.id),
      interestLevel: integer("interest_level").notNull().default(0),
      // 0-100
      notes: text("notes"),
      status: text("status").notNull().default("tracking"),
      // tracking, contacted, visiting, offered, committed
      priority: text("priority").default("medium"),
      // low, medium, high, top
      needsFit: integer("needs_fit").default(0),
      // 0-100 how well player fits team needs
      academicFit: integer("academic_fit").default(0),
      // 0-100 academic fit
      cultureFit: integer("culture_fit").default(0),
      // 0-100 culture fit
      talentFit: integer("talent_fit").default(0),
      // 0-100 talent evaluation
      overallFit: integer("overall_fit").default(0),
      // 0-100 combined fit score
      lastContactDate: timestamp("last_contact_date"),
      nextContactDate: timestamp("next_contact_date"),
      visitScheduled: timestamp("visit_scheduled"),
      offerDetails: json("offer_details"),
      competingSchools: text("competing_schools").array(),
      commitmentChance: integer("commitment_chance").default(0),
      // 0-100 AI prediction
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    });
    athleteDiscoveries = pgTable("athlete_discoveries", {
      id: serial("id").primaryKey(),
      scoutId: integer("scout_id").references(() => socialMediaScouts.id),
      fullName: text("full_name").notNull(),
      username: text("username").notNull(),
      platform: text("platform").notNull(),
      // instagram, twitter, tiktok, etc.
      profileUrl: text("profile_url").notNull(),
      email: text("email"),
      phone: text("phone"),
      estimatedAge: integer("estimated_age"),
      location: text("location"),
      schoolName: text("school_name"),
      graduationYear: integer("graduation_year"),
      sports: text("sports").array(),
      positions: text("positions").array(),
      bio: text("bio"),
      followerCount: integer("follower_count"),
      postCount: integer("post_count"),
      highlights: text("highlights").array(),
      // Key accomplishments mentioned
      discoveredAt: timestamp("discovered_at").defaultNow(),
      lastCheckedAt: timestamp("last_checked_at").defaultNow(),
      status: text("status").default("new"),
      // new, contacted, responded, converted, rejected
      assignedTo: integer("assigned_to").references(() => users.id),
      notes: text("notes"),
      potentialRating: integer("potential_rating"),
      // 1-5 initial assessment
      confidence: integer("confidence").default(70),
      // How confident is the AI in this match (0-100)
      mediaUrls: text("media_urls").array(),
      // URLs to key media found
      contactAttempts: integer("contact_attempts").default(0),
      convertedToUserId: integer("converted_to_user_id").references(() => users.id)
    });
    socialMediaAudits = pgTable("social_media_audits", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").references(() => users.id),
      auditDate: timestamp("audit_date").defaultNow(),
      overallScore: integer("overall_score").notNull(),
      // 0-100
      platformsAnalyzed: text("platforms_analyzed").array(),
      contentAnalysis: json("content_analysis"),
      // Analysis of posts, comments, etc.
      redFlagCount: integer("red_flag_count").default(0),
      redFlagItems: json("red_flag_items"),
      improvementSuggestions: text("improvement_suggestions").array(),
      positiveHighlights: json("positive_highlights"),
      recruitmentImpactScore: integer("recruitment_impact_score"),
      // How this affects recruiting (0-100)
      reportGeneratedBy: integer("report_generated_by").references(() => users.id),
      sharedWithUser: boolean("shared_with_user").default(false),
      userAcknowledged: boolean("user_acknowledged").default(false)
    });
    garCategories = pgTable("gar_categories", {
      id: serial("id").primaryKey(),
      name: text("name").notNull(),
      description: text("description").notNull(),
      sportType: text("sport_type").notNull(),
      // basketball, football, soccer, etc.
      positionType: text("position_type"),
      // specific position (quarterback, center, etc.)
      displayOrder: integer("display_order").default(0),
      icon: text("icon"),
      // Icon identifier
      color: text("color"),
      // Hex color for visualization
      createdAt: timestamp("created_at").defaultNow(),
      active: boolean("active").default(true)
    });
    garSubcategories = pgTable("gar_subcategories", {
      id: serial("id").primaryKey(),
      categoryId: integer("category_id").notNull().references(() => garCategories.id),
      name: text("name").notNull(),
      description: text("description").notNull(),
      displayOrder: integer("display_order").default(0),
      icon: text("icon"),
      color: text("color"),
      maxScore: integer("max_score").default(100),
      // Maximum possible score
      createdAt: timestamp("created_at").defaultNow(),
      active: boolean("active").default(true)
    });
    garAthleteRatings = pgTable("gar_athlete_ratings", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      videoAnalysisId: integer("video_analysis_id").notNull().references(() => videoAnalyses.id),
      categoryId: integer("category_id").notNull().references(() => garCategories.id),
      subcategoryId: integer("subcategory_id").references(() => garSubcategories.id),
      score: integer("score").notNull(),
      // 0-100
      percentileRank: integer("percentile_rank"),
      // Athlete's percentile compared to peers
      previousScore: integer("previous_score"),
      // For tracking improvement
      scoreDate: timestamp("score_date").defaultNow(),
      notes: text("notes"),
      confidence: integer("confidence").default(90)
      // AI confidence in the score (0-100)
    });
    garRatingHistory = pgTable("gar_rating_history", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      videoAnalysisId: integer("video_analysis_id").references(() => videoAnalyses.id),
      totalGarScore: integer("total_gar_score").notNull(),
      // Overall score
      categoryScores: json("category_scores").notNull(),
      // JSON with scores by category
      calculatedDate: timestamp("calculated_date").defaultNow(),
      starRating: integer("star_rating").notNull().default(0)
      // 1-5 star rating derived from GAR score
    });
    athleteStarProfiles = pgTable("athlete_star_profiles", {
      id: serial("id").primaryKey(),
      profileId: text("profile_id").notNull().unique(),
      // The original ID from the JSON file (e.g., foo_qua_5star_1)
      userId: integer("user_id").references(() => users.id),
      // If connected to a user account
      name: text("name").notNull(),
      starLevel: integer("star_level").notNull(),
      // 1-5 stars
      sport: text("sport").notNull(),
      position: text("position").notNull(),
      ageGroup: text("age_group"),
      metrics: jsonb("metrics").notNull(),
      // Height, weight, forty, vertical, GPA, etc.
      traits: jsonb("traits").notNull(),
      // Movement, mental, resilience traits
      filmExpectations: text("film_expectations").array(),
      trainingFocus: text("training_focus").array(),
      avatar: text("avatar").notNull(),
      // Path to headshot image
      rank: text("rank"),
      xpLevel: integer("xp_level").default(0),
      active: boolean("active").default(true),
      createdAt: timestamp("created_at").defaultNow()
    });
    fanClubFollowers = pgTable("fan_club_followers", {
      id: serial("id").primaryKey(),
      athleteId: integer("athlete_id").notNull().references(() => users.id),
      followerName: text("follower_name").notNull(),
      followerEmail: text("follower_email"),
      followerType: text("follower_type").notNull(),
      // fan, recruiter, friend, family
      followDate: timestamp("follow_date").defaultNow(),
      notes: text("notes")
    });
    leaderboardEntries = pgTable("leaderboard_entries", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      category: text("category").notNull(),
      // by sport or skill
      rankPosition: integer("rank_position").notNull(),
      score: integer("score").notNull(),
      city: text("city"),
      state: text("state"),
      updatedAt: timestamp("updated_at").defaultNow()
    });
    workoutPlaylists = pgTable("workout_playlists", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      title: text("title").notNull(),
      description: text("description"),
      workoutType: text("workout_type").notNull(),
      // strength, cardio, flexibility, sport-specific, recovery
      intensityLevel: text("intensity_level").notNull(),
      // low, medium, high
      duration: integer("duration").notNull(),
      // in minutes
      targets: text("targets").array(),
      // body parts or skills targeted
      createdAt: timestamp("created_at").defaultNow(),
      lastUsed: timestamp("last_used"),
      timesUsed: integer("times_used").default(0),
      isCustom: boolean("is_custom").default(true),
      isPublic: boolean("is_public").default(false)
    });
    workoutExercises = pgTable("workout_exercises", {
      id: serial("id").primaryKey(),
      playlistId: integer("playlist_id").notNull().references(() => workoutPlaylists.id),
      name: text("name").notNull(),
      description: text("description"),
      sets: integer("sets"),
      reps: integer("reps"),
      duration: integer("duration"),
      // in seconds, for timed exercises
      restPeriod: integer("rest_period"),
      // in seconds
      order: integer("order").notNull(),
      videoUrl: text("video_url"),
      imageUrl: text("image_url"),
      notes: text("notes"),
      equipmentNeeded: text("equipment_needed").array()
    });
    filmComparisons = pgTable("film_comparisons", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      title: text("title").notNull(),
      description: text("description"),
      createdAt: timestamp("created_at").defaultNow(),
      isPublic: boolean("is_public").default(false),
      comparisonType: text("comparison_type").notNull(),
      // self, pro, teammate
      status: text("status").notNull().default("draft"),
      // draft, completed, shared
      tags: text("tags").array()
    });
    comparisonVideos = pgTable("comparison_videos", {
      id: serial("id").primaryKey(),
      comparisonId: integer("comparison_id").notNull().references(() => filmComparisons.id),
      videoId: integer("video_id").references(() => videos.id),
      externalVideoUrl: text("external_video_url"),
      athleteName: text("athlete_name"),
      videoType: text("video_type").notNull(),
      // base, comparison
      order: integer("order").default(0),
      notes: text("notes"),
      keyPoints: text("key_points").array(),
      markups: json("markups")
      // Stores drawing data for the video
    });
    comparisonAnalyses = pgTable("comparison_analyses", {
      id: serial("id").primaryKey(),
      comparisonId: integer("comparison_id").notNull().references(() => filmComparisons.id),
      analysisDate: timestamp("analysis_date").defaultNow(),
      similarityScore: integer("similarity_score"),
      // 0-100
      differences: json("differences"),
      // Key differences in technique
      recommendations: text("recommendations").array(),
      aiGeneratedNotes: text("ai_generated_notes"),
      techniqueBreakdown: json("technique_breakdown"),
      // Football coach specific analyses
      playAssignments: json("play_assignments"),
      // Expected assignments for each player
      assignmentGrades: json("assignment_grades"),
      // How well each player executed their assignment (0-100)
      bustedCoverage: boolean("busted_coverage").default(false),
      bustedCoverageDetails: json("busted_coverage_details"),
      // Details about coverage breakdowns
      playerComparisons: json("player_comparisons"),
      // Size, speed, competition level comparisons
      performanceRating: json("performance_rating"),
      // True rating based on performance metrics
      recommendedExamples: json("recommended_examples"),
      // URLs to recommended technique examples
      defenseAnalysis: json("defense_analysis")
      // Analysis of defensive scheme and execution
    });
    spotlightProfiles = pgTable("spotlight_profiles", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      title: text("title").notNull(),
      summary: text("summary").notNull(),
      story: text("story").notNull(),
      coverImage: text("cover_image").notNull(),
      mediaGallery: text("media_gallery").array(),
      spotlightDate: timestamp("spotlight_date").defaultNow(),
      featured: boolean("featured").default(false),
      status: text("status").notNull().default("pending"),
      // pending, approved, archived
      approvedBy: integer("approved_by").references(() => users.id),
      views: integer("views").default(0),
      likes: integer("likes").default(0),
      isTrending: boolean("is_trending").default(false),
      category: text("category").notNull()
      // Rising Star, Comeback Story, etc.
    });
    playerProgress = pgTable("player_progress", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      currentLevel: integer("current_level").notNull().default(1),
      totalXp: integer("total_xp").notNull().default(0),
      levelXp: integer("level_xp").notNull().default(0),
      xpToNextLevel: integer("xp_to_next_level").notNull().default(100),
      rank: text("rank").notNull().default("Rookie"),
      lifetimeAchievements: integer("lifetime_achievements").default(0),
      streakDays: integer("streak_days").default(0),
      lastActive: timestamp("last_active").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    });
    xpTransactions = pgTable("xp_transactions", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      amount: integer("amount").notNull(),
      transactionType: text("transaction_type").notNull(),
      // workout, challenge, video, analysis, etc.
      sourceId: text("source_id"),
      // ID of the source that generated XP
      description: text("description").notNull(),
      createdAt: timestamp("created_at").defaultNow(),
      multiplier: real("multiplier").default(1)
    });
    playerBadges = pgTable("player_badges", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      badgeId: text("badge_id").notNull(),
      badgeName: text("badge_name").notNull(),
      description: text("description").notNull(),
      category: text("category").notNull(),
      // athletic, academic, leadership, etc.
      tier: text("tier").notNull().default("bronze"),
      // bronze, silver, gold, platinum
      isActive: boolean("is_active").default(true),
      iconPath: text("icon_path").notNull(),
      earnedAt: timestamp("earned_at").defaultNow(),
      progress: integer("progress").default(100)
      // Percentage of completion
    });
    workoutVerifications = pgTable("workout_verifications", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      workoutId: integer("workout_id").references(() => workoutPlaylists.id),
      title: text("title").notNull(),
      submissionDate: timestamp("submission_date").defaultNow(),
      verificationStatus: text("verification_status").notNull().default("pending"),
      // pending, approved, rejected
      verifiedBy: integer("verified_by").references(() => users.id),
      verificationDate: timestamp("verification_date"),
      verificationMethod: text("verification_method"),
      // coach, AI, photo, video
      proofType: text("proof_type"),
      // photo, video, coach-verified, location
      proofData: text("proof_data"),
      // URL or data for verification
      notes: text("notes"),
      xpEarned: integer("xp_earned").default(0),
      duration: integer("duration"),
      // in minutes
      recoveryImpact: integer("recovery_impact")
      // 1-10
    });
    videoHighlights = pgTable("video_highlights", {
      id: serial("id").primaryKey(),
      videoId: integer("video_id").notNull().references(() => videos.id),
      title: text("title").notNull(),
      description: text("description"),
      startTime: real("start_time").notNull(),
      // Start timestamp in seconds
      endTime: real("end_time").notNull(),
      // End timestamp in seconds
      highlightPath: text("highlight_path").notNull(),
      // Path to the generated highlight clip
      thumbnailPath: text("thumbnail_path"),
      // Path to the thumbnail image
      createdAt: timestamp("created_at").defaultNow(),
      createdBy: integer("created_by").notNull().references(() => users.id),
      aiGenerated: boolean("ai_generated").default(false),
      // Whether this was auto-generated by AI
      featured: boolean("featured").default(false),
      // Whether this is a featured highlight
      tags: text("tags").array(),
      // Tags for categorizing highlights
      homePageEligible: boolean("home_page_eligible").default(false),
      // Can be featured on homepage
      viewCount: integer("view_count").default(0),
      // Number of views
      likesCount: integer("likes_count").default(0),
      // Number of likes
      qualityScore: integer("quality_score").default(0),
      // AI-rated quality (0-100)
      primarySkill: text("primary_skill"),
      // Main skill showcased (dunking, passing, etc.)
      skillLevel: integer("skill_level").default(0),
      // 1-100 rating of skill shown
      gameContext: text("game_context"),
      // Context of the play (game-winning, etc.)
      aiAnalysisNotes: text("ai_analysis_notes")
      // AI notes about the highlight
    });
    highlightGeneratorConfigs2 = pgTable("highlight_generator_configs", {
      id: serial("id").primaryKey(),
      name: text("name").notNull(),
      description: text("description"),
      active: boolean("active").default(true),
      sportType: text("sport_type").notNull(),
      // basketball, football, etc.
      highlightTypes: text("highlight_types").array(),
      // dunks, 3-pointers, tackles, goals, etc.
      minDuration: integer("min_duration").default(8),
      // In seconds
      maxDuration: integer("max_duration").default(30),
      // In seconds
      maxHighlightsPerVideo: integer("max_highlights_per_video").default(3),
      qualityThreshold: integer("quality_threshold").default(70),
      // 0-100 minimum quality to feature
      detectableEvents: json("detectable_events"),
      // JSON with events to detect by sport
      createdBy: integer("created_by").references(() => users.id),
      createdAt: timestamp("created_at").defaultNow(),
      lastRun: timestamp("last_run"),
      useThumbnailFrame: text("use_thumbnail_frame").default("best"),
      // "start", "middle", "best"
      addTextOverlay: boolean("add_text_overlay").default(true),
      addMusicTrack: boolean("add_music_track").default(false),
      musicCategory: text("music_category").default("highEnergy")
      // Options for music style
    });
    workoutVerificationCheckpoints = pgTable("workout_verification_checkpoints", {
      id: serial("id").primaryKey(),
      verificationId: integer("verification_id").notNull().references(() => workoutVerifications.id),
      exerciseName: text("exercise_name").notNull(),
      isCompleted: boolean("is_completed").default(false),
      completedAmount: integer("completed_amount"),
      // reps or time
      targetAmount: integer("target_amount"),
      // target reps or time
      feedback: text("feedback"),
      mediaProof: text("media_proof"),
      // URL to proof media
      checkpointOrder: integer("checkpoint_order").notNull()
    });
    weightRoomEquipment = pgTable("weight_room_equipment", {
      id: serial("id").primaryKey(),
      name: text("name").notNull(),
      description: text("description"),
      equipmentType: text("equipment_type").notNull(),
      // strength, cardio, agility, plyometric, functional
      difficultyLevel: text("difficulty_level").notNull(),
      // beginner, intermediate, advanced
      targetMuscles: text("target_muscles").array(),
      baseXp: integer("base_xp").notNull(),
      iconPath: text("icon_path").notNull(),
      modelPath: text("model_path"),
      price: integer("price").notNull().default(0),
      unlockLevel: integer("unlock_level").notNull().default(1),
      isPremium: boolean("is_premium").default(false)
    });
    playerEquipment = pgTable("player_equipment", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      equipmentId: integer("equipment_id").notNull().references(() => weightRoomEquipment.id),
      acquiredDate: timestamp("acquired_date").defaultNow(),
      level: integer("level").notNull().default(1),
      timesUsed: integer("times_used").default(0),
      lastUsed: timestamp("last_used"),
      isFavorite: boolean("is_favorite").default(false),
      customName: text("custom_name"),
      usageStreak: integer("usage_streak").default(0)
    });
    combineTourEvents = pgTable(
      "combine_tour_events",
      {
        id: serial("id").primaryKey(),
        name: text("name").notNull(),
        description: text("description"),
        location: text("location").notNull(),
        address: text("address").notNull(),
        city: text("city").notNull(),
        state: text("state").notNull(),
        zipCode: text("zip_code").notNull(),
        startDate: timestamp("start_date").notNull(),
        endDate: timestamp("end_date").notNull(),
        registrationDeadline: timestamp("registration_deadline"),
        maximumAttendees: integer("maximum_attendees"),
        currentAttendees: integer("current_attendees").default(0),
        price: numeric("price").notNull(),
        slug: text("slug").notNull().unique(),
        status: text("status").default("draft"),
        // draft, published, cancelled, completed
        featuredImage: text("featured_image"),
        activeNetworkId: text("active_network_id"),
        registrationUrl: text("registration_url"),
        createdAt: timestamp("created_at").defaultNow(),
        updatedAt: timestamp("updated_at").defaultNow()
      }
    );
    registrations = pgTable(
      "registrations",
      {
        id: serial("id").primaryKey(),
        userId: integer("user_id").references(() => users.id),
        eventId: integer("event_id").references(() => combineTourEvents.id),
        status: text("status").default("pending"),
        // pending, confirmed, cancelled, waitlisted
        externalId: text("external_id"),
        // ID in Active Network
        registeredAt: timestamp("registered_at").defaultNow(),
        paymentStatus: text("payment_status").default("unpaid"),
        // unpaid, processing, paid, refunded
        notes: text("notes"),
        checkInTime: timestamp("check_in_time"),
        completedAt: timestamp("completed_at")
      }
    );
    payments = pgTable(
      "payments",
      {
        id: serial("id").primaryKey(),
        registrationId: integer("registration_id").references(() => registrations.id),
        amount: numeric("amount").notNull(),
        externalId: text("external_id"),
        // ID from Active Network
        status: text("status").notNull(),
        // pending, completed, failed, refunded
        processedAt: timestamp("processed_at").defaultNow(),
        refundedAt: timestamp("refunded_at")
      }
    );
    insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
    insertUserAgreementSchema = createInsertSchema(userAgreements).omit({ id: true, acceptedAt: true });
    insertUserWithMeasurementSchema = insertUserSchema.extend({
      measurementSystem: measurementSystemSchema.optional().default("metric")
    });
    insertAthleteProfileSchema = createInsertSchema(athleteProfiles).omit({ id: true });
    insertCoachProfileSchema = createInsertSchema(coachProfiles).omit({ id: true });
    insertVideoSchema = createInsertSchema(videos).omit({ id: true, uploadDate: true, analyzed: true });
    insertVideoWithFileSchema = insertVideoSchema.extend({
      filePath: z.string().min(1),
      // Accept any non-empty string
      sportType: z.string().optional().nullable(),
      thumbnailPath: z.string().optional().nullable(),
      description: z.string().optional().nullable()
    });
    insertVideoAnalysisSchema = createInsertSchema(videoAnalyses).omit({ id: true, analysisDate: true });
    insertSportRecommendationSchema = createInsertSchema(sportRecommendations).omit({ id: true, recommendationDate: true });
    insertNcaaEligibilitySchema = createInsertSchema(ncaaEligibility).omit({
      id: true,
      lastUpdated: true,
      qualificationPercentage: true
      // Calculated value, not user input
    });
    insertNcaaCoreCourseSchema = createInsertSchema(ncaaCoreCourses).omit({
      id: true,
      qualityPoints: true,
      // Calculated value
      gradePoints: true
      // Calculated value
    });
    insertGradeScaleSchema = createInsertSchema(gradeScales).omit({
      id: true,
      lastUpdated: true
    });
    insertNcaaSlidingScaleSchema = createInsertSchema(ncaaSlidingScales).omit({
      id: true
    });
    insertNcaaDocumentSchema = createInsertSchema(ncaaDocuments).omit({
      id: true,
      uploadDate: true,
      verificationDate: true
    });
    insertNcaaRegistrationSchema = createInsertSchema(ncaaRegistration).omit({
      id: true,
      finalCertificationDate: true
    });
    insertCoachConnectionSchema = createInsertSchema(coachConnections).omit({ id: true, connectionDate: true, lastContact: true });
    insertAchievementSchema = createInsertSchema(achievements).omit({ id: true, earnedDate: true });
    insertMessageSchema = createInsertSchema(messages).omit({ id: true, createdAt: true, isRead: true });
    insertSkillSchema = createInsertSchema(skills).omit({ id: true, updatedAt: true });
    insertChallengeSchema = createInsertSchema(challenges).omit({ id: true, createdAt: true });
    insertAthleteChallengeSchema = createInsertSchema(athleteChallenges).omit({ id: true, startedAt: true, completedAt: true });
    insertRecoveryLogSchema = createInsertSchema(recoveryLogs).omit({ id: true, logDate: true });
    insertFanClubFollowerSchema = createInsertSchema(fanClubFollowers).omit({ id: true, followDate: true });
    insertLeaderboardEntrySchema = createInsertSchema(leaderboardEntries).omit({ id: true, updatedAt: true });
    insertWorkoutPlaylistSchema = createInsertSchema(workoutPlaylists).omit({ id: true, createdAt: true, lastUsed: true, timesUsed: true });
    insertWorkoutExerciseSchema = createInsertSchema(workoutExercises).omit({ id: true });
    insertBlogPostSchema = createInsertSchema(blogPosts, {
      publishDate: z.date().optional()
    }).omit({ id: true });
    insertFeaturedAthleteSchema = createInsertSchema(featuredAthletes, {
      featuredDate: z.date().optional()
    }).omit({ id: true });
    insertSiteImageSchema = createInsertSchema(siteImages).omit({ id: true, uploadDate: true });
    insertContentBlockSchema = createInsertSchema(contentBlocks).omit({ id: true, lastUpdated: true, lastUpdatedBy: true });
    insertFilmComparisonSchema = createInsertSchema(filmComparisons).omit({ id: true, createdAt: true });
    insertComparisonVideoSchema = createInsertSchema(comparisonVideos).omit({ id: true });
    insertComparisonAnalysisSchema = createInsertSchema(comparisonAnalyses).omit({ id: true, analysisDate: true });
    insertSpotlightProfileSchema = createInsertSchema(spotlightProfiles, {
      spotlightDate: z.date().optional()
    }).omit({ id: true, views: true, likes: true });
    insertPlayerProgressSchema = createInsertSchema(playerProgress).omit({
      id: true,
      lastActive: true,
      updatedAt: true
    });
    insertXpTransactionSchema = createInsertSchema(xpTransactions).omit({ id: true, createdAt: true });
    insertPlayerBadgeSchema = createInsertSchema(playerBadges).omit({ id: true, earnedAt: true });
    insertWorkoutVerificationSchema = createInsertSchema(workoutVerifications).omit({
      id: true,
      submissionDate: true,
      verificationDate: true
    });
    insertWorkoutVerificationCheckpointSchema = createInsertSchema(workoutVerificationCheckpoints).omit({ id: true });
    insertWeightRoomEquipmentSchema = createInsertSchema(weightRoomEquipment).omit({ id: true });
    insertPlayerEquipmentSchema = createInsertSchema(playerEquipment).omit({
      id: true,
      acquiredDate: true,
      lastUsed: true
    });
    insertVideoHighlightSchema = createInsertSchema(videoHighlights).omit({
      id: true,
      createdAt: true
    });
    insertHighlightGeneratorConfigSchema = createInsertSchema(highlightGeneratorConfigs2).omit({
      id: true,
      createdAt: true,
      lastRun: true
    });
    insertCombineTourEventSchema = createInsertSchema(combineTourEvents).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      currentAttendees: true
    });
    insertRegistrationSchema = createInsertSchema(registrations).omit({
      id: true,
      registeredAt: true,
      checkInTime: true,
      completedAt: true
    });
    insertPaymentSchema = createInsertSchema(payments).omit({
      id: true,
      processedAt: true,
      refundedAt: true
    });
    insertApiKeySchema = createInsertSchema(apiKeys, {
      keyType: z.enum(["openai", "stripe", "sendgrid", "twilio", "google", "aws", "active", "twitter", "reddit_client_id", "reddit_client_secret"])
    }).omit({ id: true, addedAt: true, lastUsed: true });
    insertAthleteStarProfileSchema = createInsertSchema(athleteStarProfiles).omit({
      id: true,
      createdAt: true
    });
    onboardingProgress = pgTable("onboarding_progress", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id).unique(),
      isCompleted: boolean("is_completed").notNull().default(false),
      currentStep: integer("current_step").notNull().default(1),
      totalSteps: integer("total_steps").notNull().default(5),
      lastUpdated: timestamp("last_updated").notNull().defaultNow(),
      completedSections: text("completed_sections").array(),
      skippedSections: text("skipped_sections").array()
    });
    athleteJourneyMap = pgTable("athlete_journey_map", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id).unique(),
      currentPhase: text("current_phase").notNull(),
      startedAt: timestamp("started_at").notNull().defaultNow(),
      updatedAt: timestamp("updated_at").notNull().defaultNow(),
      timeline: jsonb("timeline").notNull(),
      goals: jsonb("goals").notNull(),
      milestones: jsonb("milestones").notNull()
    });
    journeyMilestones = pgTable("journey_milestones", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      journeyMapId: integer("journey_map_id").notNull().references(() => athleteJourneyMap.id),
      title: text("title").notNull(),
      description: text("description"),
      targetDate: timestamp("target_date"),
      isCompleted: boolean("is_completed").notNull().default(false),
      completedAt: timestamp("completed_at"),
      type: text("type").notNull(),
      // athletic, academic, personal
      priority: integer("priority").notNull().default(1)
    });
    insertOnboardingProgressSchema = createInsertSchema(onboardingProgress).omit({
      id: true,
      lastUpdated: true
    });
    insertAthleteJourneyMapSchema = createInsertSchema(athleteJourneyMap).omit({
      id: true,
      startedAt: true,
      updatedAt: true
    });
    insertJourneyMilestoneSchema = createInsertSchema(journeyMilestones).omit({
      id: true,
      completedAt: true
    });
    musicArtists = pgTable("music_artists", {
      id: serial("id").primaryKey(),
      name: text("name").notNull(),
      artistUsername: text("artist_username").notNull().unique(),
      email: text("email").notNull(),
      bio: text("bio"),
      profileImage: text("profile_image"),
      coverImage: text("cover_image"),
      socialLinks: jsonb("social_links"),
      genres: text("genres").array(),
      verifiedArtist: boolean("verified_artist").default(false),
      userId: integer("user_id").references(() => users.id),
      // Optional link to Go4It user account
      createdAt: timestamp("created_at").defaultNow(),
      active: boolean("active").default(true)
    });
    musicTracks = pgTable("music_tracks", {
      id: serial("id").primaryKey(),
      title: text("title").notNull(),
      artistId: integer("artist_id").notNull().references(() => musicArtists.id),
      filePath: text("file_path").notNull(),
      coverArt: text("cover_art"),
      duration: integer("duration").notNull(),
      // Duration in seconds
      uploadDate: timestamp("upload_date").defaultNow(),
      releaseDate: date("release_date"),
      genres: text("genres").array(),
      tags: text("tags").array(),
      isExplicit: boolean("is_explicit").default(false),
      isApproved: boolean("is_approved").default(false),
      featuredArtists: text("featured_artists").array(),
      description: text("description"),
      lyrics: text("lyrics"),
      plays: integer("plays").default(0),
      likes: integer("likes").default(0),
      bpm: integer("bpm"),
      // Beats per minute
      mood: text("mood").array(),
      // energetic, calm, etc.
      sportMatchCategories: text("sport_match_categories").array(),
      // e.g., "workout", "pregame", "cooldown", "focus"
      active: boolean("active").default(true)
    });
    musicPlaylists = pgTable("music_playlists", {
      id: serial("id").primaryKey(),
      name: text("name").notNull(),
      description: text("description"),
      creatorId: integer("creator_id").notNull().references(() => users.id),
      coverImage: text("cover_image"),
      isPublic: boolean("is_public").default(true),
      categories: text("categories").array(),
      // workout, pregame, etc.
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow(),
      likes: integer("likes").default(0),
      followers: integer("followers").default(0),
      sportAssociation: text("sport_association").array(),
      // basketball, football, etc.
      trainingPhase: text("training_phase").array(),
      // warmup, high-intensity, recovery, etc.
      active: boolean("active").default(true)
    });
    playlistTracks = pgTable("playlist_tracks", {
      id: serial("id").primaryKey(),
      playlistId: integer("playlist_id").notNull().references(() => musicPlaylists.id),
      trackId: integer("track_id").notNull().references(() => musicTracks.id),
      addedAt: timestamp("added_at").defaultNow(),
      position: integer("position").notNull()
    });
    musicListeningHistory = pgTable("music_listening_history", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id),
      trackId: integer("track_id").notNull().references(() => musicTracks.id),
      playedAt: timestamp("played_at").defaultNow(),
      playDuration: integer("play_duration"),
      // How long user listened in seconds
      completedPlay: boolean("completed_play").default(false),
      contextType: text("context_type"),
      // e.g., "playlist", "radio", "profile", "workout"
      contextId: integer("context_id")
      // ID of the context (playlist ID, workout ID)
    });
    musicUserPreferences = pgTable("music_user_preferences", {
      id: serial("id").primaryKey(),
      userId: integer("user_id").notNull().references(() => users.id).unique(),
      favoriteGenres: text("favorite_genres").array(),
      favoriteMoods: text("favorite_moods").array(),
      favoriteArtists: integer("favorite_artists").array(),
      // Array of artist IDs
      favoriteTracks: integer("favorite_tracks").array(),
      // Array of track IDs
      dislikedTracks: integer("disliked_tracks").array(),
      // Array of track IDs
      explicitContentAllowed: boolean("explicit_content_allowed").default(false),
      updatedAt: timestamp("updated_at").defaultNow()
    });
    artistNilDeals = pgTable("artist_nil_deals", {
      id: serial("id").primaryKey(),
      artistId: integer("artist_id").notNull().references(() => musicArtists.id),
      athleteId: integer("athlete_id").notNull().references(() => users.id),
      dealType: text("deal_type").notNull(),
      // promotion, exclusive, feature, etc.
      startDate: date("start_date").notNull(),
      endDate: date("end_date"),
      dealTerms: jsonb("deal_terms"),
      dealStatus: text("deal_status").notNull().default("pending"),
      // pending, active, completed, cancelled
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow(),
      active: boolean("active").default(true)
    });
    insertMusicArtistSchema = createInsertSchema(musicArtists).omit({
      id: true,
      createdAt: true
    });
    insertMusicTrackSchema = createInsertSchema(musicTracks).omit({
      id: true,
      uploadDate: true,
      plays: true,
      likes: true
    });
    insertMusicPlaylistSchema = createInsertSchema(musicPlaylists).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      likes: true,
      followers: true
    });
    insertPlaylistTrackSchema = createInsertSchema(playlistTracks).omit({
      id: true,
      addedAt: true
    });
    insertMusicListeningHistorySchema = createInsertSchema(musicListeningHistory).omit({
      id: true,
      playedAt: true
    });
    insertMusicUserPreferencesSchema = createInsertSchema(musicUserPreferences).omit({
      id: true,
      updatedAt: true
    });
    insertArtistNilDealSchema = createInsertSchema(artistNilDeals).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    podcastShows = pgTable("podcast_shows", {
      id: serial("id").primaryKey(),
      title: text("title").notNull(),
      description: text("description").notNull(),
      coverImage: text("cover_image"),
      creatorId: integer("creator_id").notNull().references(() => users.id),
      isGroupShow: boolean("is_group_show").default(false),
      categories: text("categories").array(),
      tags: text("tags").array(),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow(),
      isActive: boolean("is_active").default(true),
      isExplicit: boolean("is_explicit").default(false),
      rssFeedUrl: text("rss_feed_url"),
      websiteUrl: text("website_url"),
      sportCategories: text("sport_categories").array(),
      showFormat: text("show_format"),
      // interview, solo, panel, etc.
      episodeFrequency: text("episode_frequency"),
      // weekly, biweekly, monthly
      subscriberCount: integer("subscriber_count").default(0),
      totalListens: integer("total_listens").default(0),
      featuredPosition: integer("featured_position")
      // For editorial featuring on homepage
    });
    podcastHosts = pgTable("podcast_hosts", {
      id: serial("id").primaryKey(),
      showId: integer("show_id").notNull().references(() => podcastShows.id),
      userId: integer("user_id").notNull().references(() => users.id),
      role: text("role").default("host"),
      // host, co-host, guest host, producer
      bio: text("bio"),
      joinedAt: timestamp("joined_at").defaultNow(),
      leftAt: timestamp("left_at"),
      // If the host leaves the show
      isActive: boolean("is_active").default(true)
    });
    podcastEpisodes = pgTable("podcast_episodes", {
      id: serial("id").primaryKey(),
      showId: integer("show_id").notNull().references(() => podcastShows.id),
      title: text("title").notNull(),
      description: text("description").notNull(),
      audioFilePath: text("audio_file_path").notNull(),
      duration: integer("duration").notNull(),
      // Duration in seconds
      publishDate: timestamp("publish_date").defaultNow(),
      episodeNumber: integer("episode_number"),
      seasonNumber: integer("season_number").default(1),
      coverImage: text("cover_image"),
      isExplicit: boolean("is_explicit").default(false),
      listenCount: integer("listen_count").default(0),
      isPublished: boolean("is_published").default(true),
      showNotes: text("show_notes"),
      highlights: jsonb("highlights"),
      // Timestamps with descriptions for key moments
      transcriptPath: text("transcript_path"),
      isHighlightEpisode: boolean("is_highlight_episode").default(false)
    });
    podcastGuests = pgTable("podcast_guests", {
      id: serial("id").primaryKey(),
      episodeId: integer("episode_id").notNull().references(() => podcastEpisodes.id),
      guestName: text("guest_name").notNull(),
      userId: integer("user_id").references(() => users.id),
      // Optional - if guest is a Go4It user
      bio: text("bio"),
      title: text("title"),
      // e.g., "Head Coach", "NFL Analyst", "College Recruit"
      instagramHandle: text("instagram_handle"),
      twitterHandle: text("twitter_handle"),
      websiteUrl: text("website_url"),
      imageUrl: text("image_url"),
      topicDiscussed: text("topic_discussed"),
      appearanceStartTime: integer("appearance_start_time")
      // Timestamp in seconds when guest first speaks
    });
    podcastComments = pgTable("podcast_comments", {
      id: serial("id").primaryKey(),
      episodeId: integer("episode_id").notNull().references(() => podcastEpisodes.id),
      userId: integer("user_id").notNull().references(() => users.id),
      content: text("content").notNull(),
      timestamp: integer("timestamp"),
      // Timestamp in the episode this comment refers to
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow(),
      parentCommentId: integer("parent_comment_id").references(() => podcastComments.id),
      // For replies
      likes: integer("likes").default(0),
      isEdited: boolean("is_edited").default(false),
      isRemoved: boolean("is_removed").default(false)
    });
    podcastSubscriptions = pgTable("podcast_subscriptions", {
      id: serial("id").primaryKey(),
      showId: integer("show_id").notNull().references(() => podcastShows.id),
      userId: integer("user_id").notNull().references(() => users.id),
      subscribedAt: timestamp("subscribed_at").defaultNow(),
      notificationsEnabled: boolean("notifications_enabled").default(true)
    });
    podcastListeningHistory = pgTable("podcast_listening_history", {
      id: serial("id").primaryKey(),
      episodeId: integer("episode_id").notNull().references(() => podcastEpisodes.id),
      userId: integer("user_id").notNull().references(() => users.id),
      lastPosition: integer("last_position").default(0),
      // Last playback position in seconds
      completed: boolean("completed").default(false),
      // If user finished the episode
      listenDate: timestamp("listen_date").defaultNow(),
      device: text("device"),
      // Device used for listening
      listenDuration: integer("listen_duration")
      // How long they listened in seconds
    });
    podcastTopics = pgTable("podcast_topics", {
      id: serial("id").primaryKey(),
      name: text("name").notNull().unique(),
      description: text("description"),
      iconName: text("icon_name"),
      // For UI display
      category: text("category"),
      // Broader category this topic falls under
      popular: boolean("popular").default(false)
      // For trending topics
    });
    podcastEpisodeTopics = pgTable("podcast_episode_topics", {
      id: serial("id").primaryKey(),
      episodeId: integer("episode_id").notNull().references(() => podcastEpisodes.id),
      topicId: integer("topic_id").notNull().references(() => podcastTopics.id)
    });
    podcastCollaborationRequests = pgTable("podcast_collaboration_requests", {
      id: serial("id").primaryKey(),
      showId: integer("show_id").notNull().references(() => podcastShows.id),
      senderId: integer("sender_id").notNull().references(() => users.id),
      recipientId: integer("recipient_id").notNull().references(() => users.id),
      status: text("status").notNull().default("pending"),
      // pending, accepted, declined
      requestNote: text("request_note"),
      responseNote: text("response_note"),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow(),
      proposedDate: timestamp("proposed_date"),
      proposedTopic: text("proposed_topic")
    });
    insertPodcastShowSchema = createInsertSchema(podcastShows).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      subscriberCount: true,
      totalListens: true
    });
    insertPodcastHostSchema = createInsertSchema(podcastHosts).omit({
      id: true,
      joinedAt: true
    });
    insertPodcastEpisodeSchema = createInsertSchema(podcastEpisodes).omit({
      id: true,
      publishDate: true,
      listenCount: true
    });
    insertPodcastGuestSchema = createInsertSchema(podcastGuests).omit({
      id: true
    });
    insertPodcastCommentSchema = createInsertSchema(podcastComments).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      likes: true,
      isEdited: true,
      isRemoved: true
    });
    insertPodcastSubscriptionSchema = createInsertSchema(podcastSubscriptions).omit({
      id: true,
      subscribedAt: true
    });
    insertPodcastListeningHistorySchema = createInsertSchema(podcastListeningHistory).omit({
      id: true,
      listenDate: true
    });
    insertPodcastTopicSchema = createInsertSchema(podcastTopics).omit({
      id: true
    });
    insertPodcastEpisodeTopicSchema = createInsertSchema(podcastEpisodeTopics).omit({
      id: true
    });
    insertPodcastCollaborationRequestSchema = createInsertSchema(podcastCollaborationRequests).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
  }
});

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import themePlugin from "@replit/vite-plugin-shadcn-theme-json";
import path from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
import cartographer from "@replit/vite-plugin-cartographer";
var vite_config_default;
var init_vite_config = __esm({
  "vite.config.ts"() {
    "use strict";
    vite_config_default = defineConfig({
      plugins: [
        react(),
        runtimeErrorOverlay(),
        themePlugin(),
        ...process.env.NODE_ENV !== "production" && process.env.REPL_ID !== void 0 ? [cartographer()] : []
      ],
      resolve: {
        alias: {
          "@": path.resolve(import.meta.dirname, "client", "src"),
          "@shared": path.resolve(import.meta.dirname, "shared"),
          "@assets": path.resolve(import.meta.dirname, "attached_assets")
        }
      },
      root: path.resolve(import.meta.dirname, "client"),
      build: {
        outDir: path.resolve(import.meta.dirname, "dist/public"),
        emptyOutDir: true
      }
    });
  }
});

// server/vite.ts
import express from "express";
import fs from "fs";
import path2 from "path";
import { createServer as createViteServer, createLogger } from "vite";
import { nanoid } from "nanoid";
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions,
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path2.resolve(
        import.meta.dirname,
        "..",
        "client",
        "index.html"
      );
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path2.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express.static(distPath));
  app2.use("*", (_req, res) => {
    res.sendFile(path2.resolve(distPath, "index.html"));
  });
}
var viteLogger;
var init_vite = __esm({
  "server/vite.ts"() {
    "use strict";
    init_vite_config();
    viteLogger = createLogger();
  }
});

// server/db.ts
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
var DATABASE_URL, connection, db;
var init_db = __esm({
  "server/db.ts"() {
    "use strict";
    init_vite();
    DATABASE_URL = process.env.DATABASE_URL;
    if (!DATABASE_URL) {
      log("DATABASE_URL is not defined", "db");
      throw new Error("DATABASE_URL is not defined");
    }
    log(`Connecting to database: ${DATABASE_URL}`, "db");
    connection = postgres(DATABASE_URL);
    db = drizzle(connection);
    process.on("SIGINT", () => {
      connection.end();
    });
    process.on("SIGTERM", () => {
      connection.end();
    });
  }
});

// server/services/video-processor.ts
var video_processor_exports = {};
__export(video_processor_exports, {
  VideoProcessor: () => VideoProcessor
});
import fs2 from "fs";
import path3 from "path";
import { exec } from "child_process";
import { promisify } from "util";
import { v4 as uuidv4 } from "uuid";
var execAsync, VideoProcessor;
var init_video_processor = __esm({
  "server/services/video-processor.ts"() {
    "use strict";
    execAsync = promisify(exec);
    VideoProcessor = class {
      /**
       * Generate a thumbnail from a video file
       * @param videoPath Path to the source video file
       * @param options Thumbnail generation options
       * @returns Path to the generated thumbnail
       */
      static async generateThumbnail(videoPath, options = {}) {
        const thumbnailDir = path3.join(process.cwd(), "uploads", "thumbnails");
        if (!fs2.existsSync(thumbnailDir)) {
          fs2.mkdirSync(thumbnailDir, { recursive: true });
        }
        const thumbnailFilename = `${Date.now()}-${uuidv4()}.jpg`;
        const thumbnailPath = path3.join(thumbnailDir, thumbnailFilename);
        const time = options.time !== void 0 ? options.time : await this.getVideoDuration(videoPath) / 2;
        const width = options.width || 320;
        const ffmpegCommand = `ffmpeg -ss ${time} -i "${videoPath}" -vframes 1 -vf "scale=${width}:-1" -y "${thumbnailPath}"`;
        try {
          await execAsync(ffmpegCommand);
          return thumbnailPath;
        } catch (error) {
          console.error("Error generating thumbnail:", error);
          throw new Error(`Failed to generate thumbnail: ${error.message}`);
        }
      }
      /**
       * Create a highlight clip from a video
       * @param videoPath Path to the source video file
       * @param options Highlight clip options
       * @returns Object containing paths to the generated highlight and thumbnail
       */
      static async createHighlight(videoPath, options) {
        const highlightsDir = path3.join(process.cwd(), "uploads", "highlights");
        if (!fs2.existsSync(highlightsDir)) {
          fs2.mkdirSync(highlightsDir, { recursive: true });
        }
        const fileExt = path3.extname(videoPath);
        const highlightFilename = `highlight-${Date.now()}-${uuidv4()}${fileExt}`;
        const highlightPath = path3.join(highlightsDir, highlightFilename);
        if (options.startTime < 0 || options.endTime <= options.startTime || options.endTime > await this.getVideoDuration(videoPath)) {
          throw new Error("Invalid start or end time for highlight creation");
        }
        const quality = options.outputQuality || "fast";
        const duration = options.endTime - options.startTime;
        const ffmpegCommand = `ffmpeg -ss ${options.startTime} -i "${videoPath}" -t ${duration} -c:v libx264 -preset ${quality} -c:a aac -b:a 128k -y "${highlightPath}"`;
        try {
          await execAsync(ffmpegCommand);
          const thumbnailPath = await this.generateThumbnail(highlightPath, {
            time: duration / 2
          });
          return {
            highlightPath,
            thumbnailPath
          };
        } catch (error) {
          console.error("Error creating highlight clip:", error);
          throw new Error(`Failed to create highlight clip: ${error.message}`);
        }
      }
      /**
       * Get the duration of a video file in seconds
       * @param videoPath Path to the video file
       * @returns Duration in seconds
       */
      static async getVideoDuration(videoPath) {
        try {
          const { stdout } = await execAsync(
            `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${videoPath}"`
          );
          const duration = parseFloat(stdout.trim());
          return isNaN(duration) ? 0 : duration;
        } catch (error) {
          console.error("Error getting video duration:", error);
          throw new Error(`Failed to get video duration: ${error.message}`);
        }
      }
    };
  }
});

// server/auth.ts
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify as promisify2 } from "util";
async function hashPassword(password) {
  const salt = randomBytes(16).toString("hex");
  const buf = await scryptAsync(password, salt, 64);
  return `${buf.toString("hex")}.${salt}`;
}
async function comparePasswords(supplied, stored) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = await scryptAsync(supplied, salt, 64);
  return timingSafeEqual(hashedBuf, suppliedBuf);
}
function setupAuth(app2) {
  const sessionSettings = {
    secret: process.env.SESSION_SECRET || "go4it_sports_secret_key",
    resave: true,
    // Changed to true to ensure session is saved
    saveUninitialized: true,
    // Changed to true to create session for all requests
    store: storage.sessionStore,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      maxAge: 1e3 * 60 * 60 * 24 * 7,
      // 1 week
      httpOnly: true,
      path: "/"
    }
  };
  app2.set("trust proxy", 1);
  app2.use(session(sessionSettings));
  app2.use(passport.initialize());
  app2.use(passport.session());
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || !await comparePasswords(password, user.password)) {
          return done(null, false);
        } else {
          return done(null, user);
        }
      } catch (error) {
        return done(error);
      }
    })
  );
  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });
}
var scryptAsync;
var init_auth = __esm({
  "server/auth.ts"() {
    "use strict";
    init_storage();
    scryptAsync = promisify2(scrypt);
  }
});

// server/seed-athletes.ts
var seed_athletes_exports = {};
__export(seed_athletes_exports, {
  seedRealisticAthletes: () => seedRealisticAthletes
});
import fs3 from "fs";
import path4 from "path";
import { eq } from "drizzle-orm";
function copyImagesFromAssets() {
  const assetsDir = path4.join(process.cwd(), "attached_assets");
  try {
    if (!fs3.existsSync(assetsDir)) {
      console.log("attached_assets directory not found, skipping image copying");
      return;
    }
    const imagesToCopy = [
      { source: "IMG_1606.jpeg", dest: "athlete1.jpeg" },
      { source: "IMG_3113.jpeg", dest: "athlete2.jpeg" },
      { source: "IMG_6486.jpeg", dest: "athlete3.jpeg" }
    ];
    for (const image of imagesToCopy) {
      const sourcePath = path4.join(assetsDir, image.source);
      const destPath = path4.join(athleteImagesDir, image.dest);
      if (fs3.existsSync(sourcePath)) {
        fs3.copyFileSync(sourcePath, destPath);
        console.log(`Copied ${image.source} to ${destPath}`);
      } else {
        console.log(`Source image ${sourcePath} not found, skipping`);
      }
    }
  } catch (error) {
    console.error("Error copying images from assets:", error);
  }
}
async function seedRealisticAthletes() {
  try {
    copyImagesFromAssets();
    const existingAthletes = await db.select().from(featuredAthletes);
    if (existingAthletes.length >= 3) {
      console.log("Realistic athletes already seeded, skipping...");
      return;
    }
    await db.delete(featuredAthletes);
    const athleteUsers = [
      {
        username: "jmarcus23",
        password: await hashPassword("password123"),
        email: "jmarcus@student.edu",
        name: "Jamal Marcus",
        role: "athlete",
        profileImage: "/uploads/athletes/athlete1.jpeg",
        bio: `6'4" senior shooting guard with a powerful drive to the basket and improving 3-point shot. 3.8 GPA with interest in sports science.`,
        createdAt: /* @__PURE__ */ new Date()
      },
      {
        username: "taylor_swift12",
        password: await hashPassword("password123"),
        email: "tswift@student.edu",
        name: "Taylor Swift",
        role: "athlete",
        profileImage: "/uploads/athletes/athlete2.jpeg",
        bio: `5'11" junior volleyball outside hitter with exceptional vertical leap. National honor society member with 4.0 GPA.`,
        createdAt: /* @__PURE__ */ new Date()
      },
      {
        username: "dwest_runner",
        password: await hashPassword("password123"),
        email: "dwest@student.edu",
        name: "Darnell West",
        role: "athlete",
        profileImage: "/uploads/athletes/athlete3.jpeg",
        bio: "Track and field specialist focusing on 400m and long jump. Looking to earn a scholarship at a D1 program.",
        createdAt: /* @__PURE__ */ new Date()
      }
    ];
    for (const userData of athleteUsers) {
      const existingUser = await db.select().from(users).where(eq(users.username, userData.username));
      if (existingUser.length === 0) {
        await db.insert(users).values(userData);
        console.log(`Created athlete user: ${userData.name}`);
      }
    }
    const jamal = await db.select().from(users).where(eq(users.username, "jmarcus23")).then((rows) => rows[0]);
    const taylor = await db.select().from(users).where(eq(users.username, "taylor_swift12")).then((rows) => rows[0]);
    const darnell = await db.select().from(users).where(eq(users.username, "dwest_runner")).then((rows) => rows[0]);
    const featuredAthleteData = [
      {
        userId: jamal.id,
        highlightText: "Jamal Marcus is establishing himself as an elite college prospect with his combination of size, scoring ability, and academic excellence. His basketball IQ and work ethic have caught the attention of several D1 programs.",
        sportPosition: "Basketball Shooting Guard",
        starRating: 88,
        featuredStats: {
          points: 22.5,
          assists: 4.2,
          rebounds: 6.8,
          fieldGoalPct: 49,
          threePointPct: 38,
          achievements: ["First Team All-State", "District MVP", "3.8 GPA"]
        },
        featuredDate: /* @__PURE__ */ new Date(),
        featuredVideo: "5",
        coverImage: "/uploads/athletes/athlete1.jpeg",
        order: 1,
        active: true
      },
      {
        userId: taylor.id,
        highlightText: "Taylor Swift has demonstrated exceptional volleyball skills as an outside hitter, combining powerful attacks with precise ball placement. Her vertical leap and timing on blocks make her a formidable defensive player as well.",
        sportPosition: "Volleyball Outside Hitter",
        starRating: 91,
        featuredStats: {
          kills: 312,
          blocks: 87,
          aces: 45,
          digs: 220,
          hittingPct: 0.328,
          achievements: ["Tournament MVP", "All-Conference", "4.0 GPA"]
        },
        featuredDate: /* @__PURE__ */ new Date(),
        featuredVideo: "4",
        coverImage: "/uploads/athletes/athlete2.jpeg",
        order: 2,
        active: true
      },
      {
        userId: darnell.id,
        highlightText: "Darnell West has shown tremendous progress in both 400m sprint and long jump events. His combination of speed and explosive power gives him versatility across multiple track and field disciplines.",
        sportPosition: "Track Sprinter/Jumper",
        starRating: 84,
        featuredStats: {
          longJump: "6.8m",
          sprint400m: "49.2s",
          sprint200m: "21.8s",
          verticalLeap: "36 inches",
          achievements: ["Regional Champion 400m", "State Qualifier Long Jump", "Academic Honor Roll"]
        },
        featuredDate: /* @__PURE__ */ new Date(),
        featuredVideo: "3",
        coverImage: "/uploads/athletes/athlete3.jpeg",
        order: 3,
        active: true
      }
    ];
    for (const athleteData of featuredAthleteData) {
      await db.insert(featuredAthletes).values(athleteData);
      console.log(`Created featured athlete profile for: ${athleteData.sportPosition}`);
    }
    console.log("Successfully seeded realistic athlete profiles");
  } catch (error) {
    console.error("Error seeding realistic athletes:", error);
  }
}
var uploadDir, athleteImagesDir;
var init_seed_athletes = __esm({
  "server/seed-athletes.ts"() {
    "use strict";
    init_db();
    init_schema();
    init_auth();
    uploadDir = path4.join(process.cwd(), "uploads");
    athleteImagesDir = path4.join(uploadDir, "athletes");
    if (!fs3.existsSync(uploadDir)) {
      fs3.mkdirSync(uploadDir);
    }
    if (!fs3.existsSync(athleteImagesDir)) {
      fs3.mkdirSync(athleteImagesDir);
    }
  }
});

// server/database-storage.ts
import { eq as eq2, and, desc, asc, sql } from "drizzle-orm";
import session2 from "express-session";
import connectPg from "connect-pg-simple";
import { scrypt as scrypt2, randomBytes as randomBytes2, timingSafeEqual as timingSafeEqual2 } from "crypto";
import { promisify as promisify3 } from "util";
async function hashPassword2(password) {
  const salt = randomBytes2(16).toString("hex");
  const buf = await scryptAsync2(password, salt, 64);
  return `${buf.toString("hex")}.${salt}`;
}
var scryptAsync2, DatabaseStorage;
var init_database_storage = __esm({
  "server/database-storage.ts"() {
    "use strict";
    init_schema();
    init_db();
    scryptAsync2 = promisify3(scrypt2);
    DatabaseStorage = class {
      sessionStore;
      constructor() {
        const PostgresSessionStore = connectPg(session2);
        this.sessionStore = new PostgresSessionStore({
          conObject: {
            connectionString: process.env.DATABASE_URL,
            ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false
          },
          createTableIfMissing: true,
          tableName: "session",
          ttl: 60 * 60 * 24 * 7,
          // 1 week
          pruneSessionInterval: 60
          // 1 minute
        });
        this.seedInitialData();
      }
      // User operations
      async getUser(id) {
        const [user] = await db.select().from(users).where(eq2(users.id, id));
        return user;
      }
      async getUserByUsername(username) {
        const [user] = await db.select().from(users).where(eq2(sql`LOWER(${users.username})`, username.toLowerCase()));
        return user;
      }
      async getUserByEmail(email) {
        const [user] = await db.select().from(users).where(eq2(sql`LOWER(${users.email})`, email.toLowerCase()));
        return user;
      }
      async createUser(insertUser) {
        const [user] = await db.insert(users).values({
          ...insertUser,
          password: await hashPassword2(insertUser.password),
          createdAt: /* @__PURE__ */ new Date()
        }).returning();
        return user;
      }
      async updateUser(id, data) {
        let updateData = { ...data };
        if (data.password) {
          updateData = {
            ...data,
            password: await hashPassword2(data.password)
          };
        }
        const [user] = await db.update(users).set(updateData).where(eq2(users.id, id)).returning();
        return user;
      }
      // Athlete Profile operations
      async getAthleteProfile(userId) {
        const [profile] = await db.select().from(athleteProfiles).where(eq2(athleteProfiles.userId, userId));
        return profile;
      }
      async createAthleteProfile(profile) {
        const [athleteProfile] = await db.insert(athleteProfiles).values(profile).returning();
        return athleteProfile;
      }
      async updateAthleteProfile(userId, data) {
        const [profile] = await db.update(athleteProfiles).set(data).where(eq2(athleteProfiles.userId, userId)).returning();
        return profile;
      }
      // Coach Profile operations
      async getCoachProfile(userId) {
        const [profile] = await db.select().from(coachProfiles).where(eq2(coachProfiles.userId, userId));
        return profile;
      }
      async createCoachProfile(profile) {
        const [coachProfile] = await db.insert(coachProfiles).values(profile).returning();
        return coachProfile;
      }
      async updateCoachProfile(userId, data) {
        const [profile] = await db.update(coachProfiles).set(data).where(eq2(coachProfiles.userId, userId)).returning();
        return profile;
      }
      // Video operations
      async getVideo(id) {
        const [video] = await db.select().from(videos).where(eq2(videos.id, id));
        return video;
      }
      async getVideosByUser(userId) {
        return await db.select().from(videos).where(eq2(videos.userId, userId)).orderBy(desc(videos.uploadDate));
      }
      async createVideo(video) {
        const now = /* @__PURE__ */ new Date();
        const [newVideo] = await db.insert(videos).values({
          ...video,
          uploadDate: now,
          analyzed: false
        }).returning();
        return newVideo;
      }
      async updateVideo(id, data) {
        const [video] = await db.update(videos).set(data).where(eq2(videos.id, id)).returning();
        return video;
      }
      async deleteVideo(id) {
        const result = await db.delete(videos).where(eq2(videos.id, id));
        return result.count > 0;
      }
      // Video Analysis operations
      async getVideoAnalysis(id) {
        const [analysis] = await db.select().from(videoAnalyses).where(eq2(videoAnalyses.id, id));
        return analysis;
      }
      async getVideoAnalysisByVideoId(videoId) {
        const [analysis] = await db.select().from(videoAnalyses).where(eq2(videoAnalyses.videoId, videoId));
        return analysis;
      }
      async createVideoAnalysis(analysis) {
        const now = /* @__PURE__ */ new Date();
        await db.update(videos).set({ analyzed: true }).where(eq2(videos.id, analysis.videoId));
        const [videoAnalysis] = await db.insert(videoAnalyses).values({
          ...analysis,
          analysisDate: now
        }).returning();
        return videoAnalysis;
      }
      async saveVideoAnalysis(videoId, analysis) {
        const existingAnalysis = await this.getVideoAnalysisByVideoId(videoId);
        if (existingAnalysis) {
          const now = /* @__PURE__ */ new Date();
          const [updatedAnalysis] = await db.update(videoAnalyses).set({
            motionData: analysis.motionData,
            overallScore: analysis.overallScore,
            feedback: analysis.feedback,
            improvementTips: analysis.improvementTips,
            keyFrameTimestamps: analysis.keyFrameTimestamps,
            analysisDate: now
          }).where(eq2(videoAnalyses.id, existingAnalysis.id)).returning();
          return updatedAnalysis;
        } else {
          const newAnalysis = {
            videoId,
            motionData: analysis.motionData,
            overallScore: analysis.overallScore,
            feedback: analysis.feedback,
            improvementTips: analysis.improvementTips,
            keyFrameTimestamps: analysis.keyFrameTimestamps
          };
          return this.createVideoAnalysis(newAnalysis);
        }
      }
      // Sport Recommendation operations
      async getSportRecommendations(userId) {
        return await db.select().from(sportRecommendations).where(eq2(sportRecommendations.userId, userId)).orderBy(desc(sportRecommendations.recommendationDate));
      }
      async createSportRecommendation(recommendation) {
        const now = /* @__PURE__ */ new Date();
        const [sportRecommendation] = await db.insert(sportRecommendations).values({
          ...recommendation,
          recommendationDate: now
        }).returning();
        return sportRecommendation;
      }
      // NCAA Eligibility operations
      async getNcaaEligibility(userId) {
        const [eligibility] = await db.select().from(ncaaEligibility).where(eq2(ncaaEligibility.userId, userId));
        return eligibility;
      }
      async createNcaaEligibility(eligibility) {
        const now = /* @__PURE__ */ new Date();
        const [ncaaRecord] = await db.insert(ncaaEligibility).values({
          ...eligibility,
          lastUpdated: now
        }).returning();
        return ncaaRecord;
      }
      async updateNcaaEligibility(userId, data) {
        const now = /* @__PURE__ */ new Date();
        const [eligibility] = await db.update(ncaaEligibility).set({
          ...data,
          lastUpdated: now
        }).where(eq2(ncaaEligibility.userId, userId)).returning();
        return eligibility;
      }
      // Coach Connection operations
      async getCoachConnections(userId, role) {
        if (role === "coach") {
          return await db.select().from(coachConnections).where(eq2(coachConnections.coachId, userId)).orderBy(desc(coachConnections.lastContact));
        } else {
          return await db.select().from(coachConnections).where(eq2(coachConnections.athleteId, userId)).orderBy(desc(coachConnections.lastContact));
        }
      }
      async createCoachConnection(connection2) {
        const now = /* @__PURE__ */ new Date();
        const [coachConnection] = await db.insert(coachConnections).values({
          ...connection2,
          connectionDate: now,
          lastContact: now
        }).returning();
        return coachConnection;
      }
      async updateCoachConnection(id, data) {
        const [connection2] = await db.update(coachConnections).set(data).where(eq2(coachConnections.id, id)).returning();
        return connection2;
      }
      // Achievement operations
      async getAchievements(userId) {
        return await db.select().from(achievements).where(eq2(achievements.userId, userId)).orderBy(desc(achievements.earnedDate));
      }
      async createAchievement(achievement) {
        const now = /* @__PURE__ */ new Date();
        const [newAchievement] = await db.insert(achievements).values({
          ...achievement,
          earnedDate: now
        }).returning();
        return newAchievement;
      }
      // Message operations
      async getMessages(userId) {
        return await db.select().from(messages).where(
          sql`${messages.senderId} = ${userId} OR ${messages.recipientId} = ${userId}`
        ).orderBy(desc(messages.createdAt));
      }
      async createMessage(message) {
        const now = /* @__PURE__ */ new Date();
        const [newMessage] = await db.insert(messages).values({
          senderId: message.senderId,
          recipientId: message.recipientId,
          content: message.content,
          createdAt: now,
          isRead: false
        }).returning();
        return newMessage;
      }
      async markMessageAsRead(id) {
        const [message] = await db.update(messages).set({ isRead: true }).where(eq2(messages.id, id)).returning();
        return message;
      }
      // Admin operations
      async getAllUsers() {
        return await db.select().from(users).orderBy(asc(users.name));
      }
      async getAllAthletes() {
        return await db.select().from(users).where(eq2(users.role, "athlete")).orderBy(asc(users.name));
      }
      async getAllCoaches() {
        return await db.select().from(users).where(eq2(users.role, "coach")).orderBy(asc(users.name));
      }
      async getAllVideos() {
        return await db.select().from(videos).orderBy(desc(videos.uploadDate));
      }
      async getSystemStats() {
        const [{ count: totalUsers }] = await db.select({ count: sql`COUNT(*)`.mapWith(Number) }).from(users);
        const [{ count: totalVideos }] = await db.select({ count: sql`COUNT(*)`.mapWith(Number) }).from(videos);
        const [{ count: totalAnalyses }] = await db.select({ count: sql`COUNT(*)`.mapWith(Number) }).from(videoAnalyses);
        const [{ count: totalCoachConnections }] = await db.select({ count: sql`COUNT(*)`.mapWith(Number) }).from(coachConnections);
        return {
          totalUsers,
          totalVideos,
          totalAnalyses,
          totalCoachConnections
        };
      }
      // Skill Tree operations
      async getUserSkills(userId) {
        return await db.select().from(skills).where(eq2(skills.userId, userId)).orderBy(asc(skills.skillCategory), asc(skills.skillName));
      }
      async getUserSkillsByCategory(userId, category) {
        return await db.select().from(skills).where(
          and(
            eq2(skills.userId, userId),
            eq2(skills.skillCategory, category)
          )
        ).orderBy(asc(skills.skillName));
      }
      async getSkill(id) {
        const [skill] = await db.select().from(skills).where(eq2(skills.id, id));
        return skill;
      }
      async createSkill(skill) {
        const now = /* @__PURE__ */ new Date();
        const [newSkill] = await db.insert(skills).values({
          ...skill,
          updatedAt: now
        }).returning();
        return newSkill;
      }
      async updateSkill(id, data) {
        const now = /* @__PURE__ */ new Date();
        const [skill] = await db.update(skills).set({
          ...data,
          updatedAt: now
        }).where(eq2(skills.id, id)).returning();
        return skill;
      }
      // Challenges operations
      async getChallenges() {
        return await db.select().from(challenges).orderBy(desc(challenges.createdAt));
      }
      async getChallengesByCategory(category) {
        return await db.select().from(challenges).where(eq2(challenges.category, category)).orderBy(desc(challenges.createdAt));
      }
      async getChallenge(id) {
        const [challenge] = await db.select().from(challenges).where(eq2(challenges.id, id));
        return challenge;
      }
      async createChallenge(challenge) {
        const now = /* @__PURE__ */ new Date();
        const [newChallenge] = await db.insert(challenges).values({
          ...challenge,
          createdAt: now
        }).returning();
        return newChallenge;
      }
      async getAthleteChallenges(userId) {
        return await db.select().from(athleteChallenges).where(eq2(athleteChallenges.userId, userId)).orderBy(desc(athleteChallenges.startedAt));
      }
      async getAthleteChallenge(id) {
        const [athleteChallenge] = await db.select().from(athleteChallenges).where(eq2(athleteChallenges.id, id));
        return athleteChallenge;
      }
      async createAthleteChallenge(athleteChallenge) {
        const [newAthleteChallenge] = await db.insert(athleteChallenges).values(athleteChallenge).returning();
        return newAthleteChallenge;
      }
      async updateAthleteChallenge(id, data) {
        const [athleteChallenge] = await db.update(athleteChallenges).set(data).where(eq2(athleteChallenges.id, id)).returning();
        return athleteChallenge;
      }
      // Additional helper methods
      async getCompletedChallengesByUser(userId) {
        return await db.select().from(athleteChallenges).where(
          and(
            eq2(athleteChallenges.userId, userId),
            eq2(athleteChallenges.status, "completed")
          )
        ).orderBy(desc(athleteChallenges.completedAt));
      }
      async getAthleteChallengeByUserAndChallenge(userId, challengeId) {
        const [athleteChallenge] = await db.select().from(athleteChallenges).where(
          and(
            eq2(athleteChallenges.userId, userId),
            eq2(athleteChallenges.challengeId, challengeId)
          )
        );
        return athleteChallenge;
      }
      // Recovery Tracker operations
      async getRecoveryLogs(userId) {
        return await db.select().from(recoveryLogs).where(eq2(recoveryLogs.userId, userId)).orderBy(desc(recoveryLogs.logDate));
      }
      async getLatestRecoveryLog(userId) {
        const logs = await this.getRecoveryLogs(userId);
        return logs.length > 0 ? logs[0] : void 0;
      }
      async createRecoveryLog(log2) {
        const [newLog] = await db.insert(recoveryLogs).values(log2).returning();
        return newLog;
      }
      // Additional helper methods
      async getRecoveryLog(id) {
        const [log2] = await db.select().from(recoveryLogs).where(eq2(recoveryLogs.id, id));
        return log2;
      }
      // Fan Club operations
      async getFanClubFollowers(athleteId) {
        return await db.select().from(fanClubFollowers).where(eq2(fanClubFollowers.athleteId, athleteId)).orderBy(desc(fanClubFollowers.followDate));
      }
      async getFanClubStats(athleteId) {
        const followers = await this.getFanClubFollowers(athleteId);
        return {
          totalFollowers: followers.length,
          fans: followers.filter((f) => f.followerType === "fan").length,
          recruiters: followers.filter((f) => f.followerType === "recruiter").length,
          family: followers.filter((f) => f.followerType === "family").length,
          friends: followers.filter((f) => f.followerType === "friend").length
        };
      }
      async createFanClubFollower(follower) {
        const [newFollower] = await db.insert(fanClubFollowers).values(follower).returning();
        return newFollower;
      }
      // Additional helper methods
      async getFanClubFollower(id) {
        const [follower] = await db.select().from(fanClubFollowers).where(eq2(fanClubFollowers.id, id));
        return follower;
      }
      // Leaderboard operations
      async getLeaderboardEntries(category) {
        return await db.select().from(leaderboardEntries).where(eq2(leaderboardEntries.category, category)).orderBy(asc(leaderboardEntries.rankPosition));
      }
      async getUserLeaderboardEntry(userId, category) {
        const [entry] = await db.select().from(leaderboardEntries).where(
          and(
            eq2(leaderboardEntries.userId, userId),
            eq2(leaderboardEntries.category, category)
          )
        );
        return entry;
      }
      async createLeaderboardEntry(entry) {
        const [newEntry] = await db.insert(leaderboardEntries).values(entry).returning();
        await this.recalculateLeaderboardRanks(entry.category);
        return newEntry;
      }
      async updateLeaderboardEntry(id, data) {
        const [entry] = await db.update(leaderboardEntries).set(data).where(eq2(leaderboardEntries.id, id)).returning();
        if (entry && data.score !== void 0) {
          await this.recalculateLeaderboardRanks(entry.category);
        }
        return entry;
      }
      async recalculateLeaderboardRanks(category) {
        const entries = await db.select().from(leaderboardEntries).where(eq2(leaderboardEntries.category, category)).orderBy(desc(leaderboardEntries.score));
        for (let i = 0; i < entries.length; i++) {
          await db.update(leaderboardEntries).set({ rankPosition: i + 1 }).where(eq2(leaderboardEntries.id, entries[i].id));
        }
      }
      // Additional helper methods
      async getLeaderboardEntry(id) {
        const [entry] = await db.select().from(leaderboardEntries).where(eq2(leaderboardEntries.id, id));
        return entry;
      }
      async getLeaderboardEntriesByUser(userId) {
        return await db.select().from(leaderboardEntries).where(eq2(leaderboardEntries.userId, userId)).orderBy(asc(leaderboardEntries.category));
      }
      // Player Story Mode - Achievements operations
      async getAchievementsByUser(userId) {
        return await db.select().from(achievements).where(eq2(achievements.userId, userId)).orderBy(desc(achievements.earnedDate));
      }
      // Blog operations
      async getBlogPosts(limit = 20, offset = 0) {
        return await db.select().from(blogPosts).orderBy(desc(blogPosts.publishDate)).limit(limit).offset(offset);
      }
      async getFeaturedBlogPosts(limit = 5) {
        return await db.select().from(blogPosts).where(eq2(blogPosts.featured, true)).orderBy(desc(blogPosts.publishDate)).limit(limit);
      }
      async getBlogPostsByCategory(category, limit = 10) {
        return await db.select().from(blogPosts).where(eq2(blogPosts.category, category)).orderBy(desc(blogPosts.publishDate)).limit(limit);
      }
      async getBlogPostBySlug(slug) {
        const [post] = await db.select().from(blogPosts).where(eq2(blogPosts.slug, slug));
        return post;
      }
      async getBlogPost(id) {
        const [post] = await db.select().from(blogPosts).where(eq2(blogPosts.id, id));
        return post;
      }
      async createBlogPost(post) {
        const now = /* @__PURE__ */ new Date();
        const [newPost] = await db.insert(blogPosts).values({
          ...post,
          publishDate: now
        }).returning();
        return newPost;
      }
      async updateBlogPost(id, data) {
        const [post] = await db.update(blogPosts).set(data).where(eq2(blogPosts.id, id)).returning();
        return post;
      }
      async deleteBlogPost(id) {
        const result = await db.delete(blogPosts).where(eq2(blogPosts.id, id));
        return result.count > 0;
      }
      // Content Blocks operations
      async getContentBlocks(section) {
        if (section) {
          return await db.select().from(contentBlocks).where(eq2(contentBlocks.section, section)).orderBy(asc(contentBlocks.order));
        }
        return await db.select().from(contentBlocks).orderBy(asc(contentBlocks.section), asc(contentBlocks.order));
      }
      async getContentBlocksByIdentifier(identifier) {
        const [block] = await db.select().from(contentBlocks).where(eq2(contentBlocks.identifier, identifier));
        return block;
      }
      async getContentBlock(id) {
        const [block] = await db.select().from(contentBlocks).where(eq2(contentBlocks.id, id));
        return block;
      }
      async createContentBlock(block) {
        const now = /* @__PURE__ */ new Date();
        const [newBlock] = await db.insert(contentBlocks).values({
          ...block,
          lastUpdated: now
        }).returning();
        return newBlock;
      }
      async updateContentBlock(id, data) {
        const now = /* @__PURE__ */ new Date();
        const [updatedBlock] = await db.update(contentBlocks).set({
          ...data,
          lastUpdated: now
        }).where(eq2(contentBlocks.id, id)).returning();
        return updatedBlock;
      }
      async deleteContentBlock(id) {
        const result = await db.delete(contentBlocks).where(eq2(contentBlocks.id, id));
        return result.count > 0;
      }
      // Featured Athletes operations
      async getFeaturedAthletes(limit = 4) {
        try {
          return await db.select().from(featuredAthletes).where(eq2(featuredAthletes.active, true)).orderBy(desc(featuredAthletes.featuredDate)).limit(limit);
        } catch (error) {
          console.error("Error in getFeaturedAthletes:", error);
          return [];
        }
      }
      async getFeaturedAthlete(id) {
        const [athlete] = await db.select().from(featuredAthletes).where(eq2(featuredAthletes.id, id));
        return athlete;
      }
      async getFeaturedAthleteByUserId(userId) {
        const [athlete] = await db.select().from(featuredAthletes).where(eq2(featuredAthletes.userId, userId));
        return athlete;
      }
      async createFeaturedAthlete(athlete) {
        const now = /* @__PURE__ */ new Date();
        const [newAthlete] = await db.insert(featuredAthletes).values({
          ...athlete,
          featuredDate: now
        }).returning();
        return newAthlete;
      }
      async updateFeaturedAthlete(id, data) {
        const [athlete] = await db.update(featuredAthletes).set(data).where(eq2(featuredAthletes.id, id)).returning();
        return athlete;
      }
      async deactivateFeaturedAthlete(id) {
        const result = await db.update(featuredAthletes).set({ active: false }).where(eq2(featuredAthletes.id, id));
        return result.count > 0;
      }
      // Workout Playlist operations
      async getWorkoutPlaylists(userId) {
        return await db.select().from(workoutPlaylists).where(eq2(workoutPlaylists.userId, userId)).orderBy(desc(workoutPlaylists.lastUsed));
      }
      async getWorkoutPlaylist(id) {
        const [playlist] = await db.select().from(workoutPlaylists).where(eq2(workoutPlaylists.id, id));
        return playlist;
      }
      async createWorkoutPlaylist(playlist) {
        const now = /* @__PURE__ */ new Date();
        const [newPlaylist] = await db.insert(workoutPlaylists).values({
          ...playlist,
          createdAt: now,
          lastUsed: now,
          timesUsed: 0
        }).returning();
        return newPlaylist;
      }
      async updateWorkoutPlaylist(id, data) {
        const [playlist] = await db.update(workoutPlaylists).set(data).where(eq2(workoutPlaylists.id, id)).returning();
        return playlist;
      }
      async deleteWorkoutPlaylist(id) {
        await db.delete(workoutExercises).where(eq2(workoutExercises.playlistId, id));
        const result = await db.delete(workoutPlaylists).where(eq2(workoutPlaylists.id, id));
        return result.count > 0;
      }
      async incrementPlaylistUsage(id) {
        const [playlist] = await db.select().from(workoutPlaylists).where(eq2(workoutPlaylists.id, id));
        if (!playlist) return void 0;
        const now = /* @__PURE__ */ new Date();
        const [updatedPlaylist] = await db.update(workoutPlaylists).set({
          lastUsed: now,
          timesUsed: (playlist.timesUsed || 0) + 1
        }).where(eq2(workoutPlaylists.id, id)).returning();
        return updatedPlaylist;
      }
      async getWorkoutExercises(playlistId) {
        return await db.select().from(workoutExercises).where(eq2(workoutExercises.playlistId, playlistId)).orderBy(asc(workoutExercises.order));
      }
      async createWorkoutExercise(exercise) {
        const [newExercise] = await db.insert(workoutExercises).values(exercise).returning();
        return newExercise;
      }
      async updateWorkoutExercise(id, data) {
        const [exercise] = await db.update(workoutExercises).set(data).where(eq2(workoutExercises.id, id)).returning();
        return exercise;
      }
      async deleteWorkoutExercise(id) {
        const result = await db.delete(workoutExercises).where(eq2(workoutExercises.id, id));
        return result.count > 0;
      }
      async getPublicWorkoutPlaylists(workoutType, intensityLevel) {
        let query = db.select().from(workoutPlaylists).where(eq2(workoutPlaylists.isPublic, true));
        if (workoutType) {
          query = query.where(eq2(workoutPlaylists.workoutType, workoutType));
        }
        if (intensityLevel) {
          query = query.where(eq2(workoutPlaylists.intensityLevel, intensityLevel));
        }
        return await query.orderBy(desc(workoutPlaylists.timesUsed));
      }
      async getAthleteProfileByUserId(userId) {
        return this.getAthleteProfile(userId);
      }
      async generateAIWorkoutPlaylist(userId, preferences) {
        const now = /* @__PURE__ */ new Date();
        const [playlist] = await db.insert(workoutPlaylists).values({
          userId,
          title: `AI Generated ${preferences.workoutType} Workout (${preferences.intensityLevel})`,
          description: `A ${preferences.intensityLevel} ${preferences.workoutType} workout targeting ${preferences.targets.join(", ")}`,
          workoutType: preferences.workoutType,
          intensityLevel: preferences.intensityLevel,
          duration: preferences.duration,
          targets: preferences.targets,
          isPublic: false,
          createdAt: now,
          lastUsed: now,
          timesUsed: 0
        }).returning();
        const exercises = [];
        if (preferences.workoutType === "Strength") {
          if (preferences.targets.includes("Upper Body")) {
            exercises.push({
              playlistId: playlist.id,
              name: "Push-ups",
              description: "Standard push-ups with proper form",
              duration: 60,
              sets: 3,
              reps: 15,
              restPeriod: 30,
              order: 1
            });
            exercises.push({
              playlistId: playlist.id,
              name: "Pull-ups",
              description: "Pull-ups with proper form",
              duration: 60,
              sets: 3,
              reps: 10,
              restPeriod: 45,
              order: 2
            });
          }
          if (preferences.targets.includes("Lower Body")) {
            exercises.push({
              playlistId: playlist.id,
              name: "Squats",
              description: "Bodyweight squats with proper form",
              duration: 60,
              sets: 3,
              reps: 20,
              restPeriod: 30,
              order: 3
            });
            exercises.push({
              playlistId: playlist.id,
              name: "Lunges",
              description: "Alternating lunges with proper form",
              duration: 60,
              sets: 3,
              reps: 12,
              restPeriod: 30,
              order: 4
            });
          }
        } else if (preferences.workoutType === "Cardio") {
          exercises.push({
            playlistId: playlist.id,
            name: "Jumping Jacks",
            description: "Standard jumping jacks at a moderate pace",
            duration: 60,
            sets: 3,
            order: 1
          });
          exercises.push({
            playlistId: playlist.id,
            name: "Mountain Climbers",
            description: "Mountain climbers at a quick pace",
            duration: 45,
            sets: 3,
            order: 2
          });
        } else if (preferences.workoutType === "Flexibility") {
          exercises.push({
            playlistId: playlist.id,
            name: "Standing Hamstring Stretch",
            description: "Gentle hamstring stretch while standing",
            duration: 30,
            sets: 2,
            order: 1
          });
          exercises.push({
            playlistId: playlist.id,
            name: "Hip Flexor Stretch",
            description: "Gentle hip flexor stretch in lunge position",
            duration: 30,
            sets: 2,
            order: 2
          });
        }
        for (const exercise of exercises) {
          await db.insert(workoutExercises).values(exercise);
        }
        return playlist;
      }
      // Film Comparison operations
      async getFilmComparisons(userId) {
        return await db.select().from(filmComparisons).where(eq2(filmComparisons.userId, userId)).orderBy(desc(filmComparisons.createdAt));
      }
      async getFilmComparison(id) {
        const [comparison] = await db.select().from(filmComparisons).where(eq2(filmComparisons.id, id));
        return comparison;
      }
      async createFilmComparison(comparison) {
        const now = /* @__PURE__ */ new Date();
        const [newComparison] = await db.insert(filmComparisons).values({
          ...comparison,
          createdAt: now
        }).returning();
        return newComparison;
      }
      async updateFilmComparison(id, data) {
        const [comparison] = await db.update(filmComparisons).set(data).where(eq2(filmComparisons.id, id)).returning();
        return comparison;
      }
      async deleteFilmComparison(id) {
        await db.delete(comparisonVideos).where(eq2(comparisonVideos.comparisonId, id));
        await db.delete(comparisonAnalyses).where(eq2(comparisonAnalyses.comparisonId, id));
        const result = await db.delete(filmComparisons).where(eq2(filmComparisons.id, id));
        return result.count > 0;
      }
      async getComparisonVideos(comparisonId) {
        return await db.select().from(comparisonVideos).where(eq2(comparisonVideos.comparisonId, comparisonId)).orderBy(asc(comparisonVideos.order));
      }
      async getComparisonVideo(id) {
        const [video] = await db.select().from(comparisonVideos).where(eq2(comparisonVideos.id, id));
        return video;
      }
      async createComparisonVideo(video) {
        const [newVideo] = await db.insert(comparisonVideos).values(video).returning();
        return newVideo;
      }
      async updateComparisonVideo(id, data) {
        const [video] = await db.update(comparisonVideos).set(data).where(eq2(comparisonVideos.id, id)).returning();
        return video;
      }
      async deleteComparisonVideo(id) {
        const result = await db.delete(comparisonVideos).where(eq2(comparisonVideos.id, id));
        return result.count > 0;
      }
      async getComparisonAnalysis(comparisonId) {
        const [analysis] = await db.select().from(comparisonAnalyses).where(eq2(comparisonAnalyses.comparisonId, comparisonId));
        return analysis;
      }
      async createComparisonAnalysis(analysis) {
        const [newAnalysis] = await db.insert(comparisonAnalyses).values(analysis).returning();
        return newAnalysis;
      }
      async updateComparisonAnalysis(id, data) {
        const [analysis] = await db.update(comparisonAnalyses).set(data).where(eq2(comparisonAnalyses.id, id)).returning();
        return analysis;
      }
      // MyPlayer XP System methods
      async getPlayerProgress(userId) {
        const [progress] = await db.select().from(playerProgress).where(eq2(playerProgress.userId, userId));
        return progress;
      }
      async createPlayerProgress(data) {
        const [progress] = await db.insert(playerProgress).values({
          ...data,
          lastActive: /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        }).returning();
        return progress;
      }
      async updatePlayerProgress(userId, data) {
        const [updatedProgress] = await db.update(playerProgress).set({
          ...data,
          updatedAt: /* @__PURE__ */ new Date()
        }).where(eq2(playerProgress.userId, userId)).returning();
        return updatedProgress;
      }
      async getXpTransactions(userId) {
        return await db.select().from(xpTransactions).where(eq2(xpTransactions.userId, userId)).orderBy(desc(xpTransactions.createdAt));
      }
      async addXpToPlayer(userId, amount, type, description, sourceId) {
        return await db.transaction(async (tx) => {
          const [transaction] = await tx.insert(xpTransactions).values({
            userId,
            amount,
            transactionType: type,
            description,
            createdAt: /* @__PURE__ */ new Date()
          }).returning();
          const [progress] = await tx.select().from(playerProgress).where(eq2(playerProgress.userId, userId));
          let leveledUp = false;
          let newProgress;
          if (!progress) {
            const [createdProgress] = await tx.insert(playerProgress).values({
              userId,
              currentLevel: 1,
              totalXp: amount,
              levelXp: amount,
              xpToNextLevel: 100,
              streakDays: 0,
              lastActive: /* @__PURE__ */ new Date(),
              updatedAt: /* @__PURE__ */ new Date()
            }).returning();
            newProgress = createdProgress;
          } else {
            const newTotalXp = progress.totalXp + amount;
            const newLevelXp = progress.levelXp + amount;
            let newCurrentLevel = progress.currentLevel;
            let newLevelXpValue = newLevelXp;
            let newXpToNextLevel = progress.xpToNextLevel;
            if (newLevelXp >= progress.xpToNextLevel) {
              newCurrentLevel += 1;
              newLevelXpValue = newLevelXp - progress.xpToNextLevel;
              newXpToNextLevel = Math.floor(progress.xpToNextLevel * 1.1);
              leveledUp = true;
            }
            const [updatedProgress] = await tx.update(playerProgress).set({
              totalXp: newTotalXp,
              levelXp: newLevelXpValue,
              currentLevel: newCurrentLevel,
              xpToNextLevel: newXpToNextLevel,
              lastActive: /* @__PURE__ */ new Date(),
              updatedAt: /* @__PURE__ */ new Date()
            }).where(eq2(playerProgress.userId, userId)).returning();
            newProgress = updatedProgress;
          }
          return {
            progress: newProgress,
            transaction,
            leveledUp
          };
        });
      }
      async getPlayerBadges(userId) {
        return await db.select().from(playerBadges).where(eq2(playerBadges.userId, userId)).orderBy(asc(playerBadges.category), asc(playerBadges.badgeName));
      }
      async getPlayerBadgesByCategory(userId, category) {
        return await db.select().from(playerBadges).where(
          and(
            eq2(playerBadges.userId, userId),
            eq2(playerBadges.category, category)
          )
        ).orderBy(asc(playerBadges.badgeName));
      }
      async createPlayerBadge(badge) {
        const [newBadge] = await db.insert(playerBadges).values({
          ...badge,
          earnedAt: /* @__PURE__ */ new Date()
        }).returning();
        return newBadge;
      }
      async updatePlayerBadge(id, data) {
        const [updatedBadge] = await db.update(playerBadges).set(data).where(eq2(playerBadges.id, id)).returning();
        return updatedBadge;
      }
      // Weight Room Equipment operations
      async getWeightRoomEquipment(category) {
        try {
          let query = db.select().from(weightRoomEquipment);
          if (category) {
            query = query.where(eq2(weightRoomEquipment.category, category));
          }
          return await query;
        } catch (error) {
          console.error("Error in getWeightRoomEquipment", error);
          return [];
        }
      }
      async getWeightRoomEquipmentById(id) {
        try {
          const [result] = await db.select().from(weightRoomEquipment).where(eq2(weightRoomEquipment.id, id)).limit(1);
          return result;
        } catch (error) {
          console.error(`Error in getWeightRoomEquipmentById for ID ${id}:`, error);
          return void 0;
        }
      }
      async createWeightRoomEquipment(equipment) {
        try {
          const [result] = await db.insert(weightRoomEquipment).values(equipment).returning();
          return result;
        } catch (error) {
          console.error("Error in createWeightRoomEquipment:", error);
          throw new Error("Failed to create weight room equipment");
        }
      }
      async updateWeightRoomEquipment(id, data) {
        try {
          const [result] = await db.update(weightRoomEquipment).set(data).where(eq2(weightRoomEquipment.id, id)).returning();
          return result;
        } catch (error) {
          console.error(`Error in updateWeightRoomEquipment for ID ${id}:`, error);
          return void 0;
        }
      }
      // Player Equipment operations
      async getPlayerEquipment(userId) {
        try {
          return await db.select().from(playerEquipment).where(eq2(playerEquipment.userId, userId));
        } catch (error) {
          console.error(`Error in getPlayerEquipment for user ${userId}:`, error);
          return [];
        }
      }
      async getPlayerEquipmentById(id) {
        try {
          const [result] = await db.select().from(playerEquipment).where(eq2(playerEquipment.id, id)).limit(1);
          return result;
        } catch (error) {
          console.error(`Error in getPlayerEquipmentById for ID ${id}:`, error);
          return void 0;
        }
      }
      async createPlayerEquipment(equipment) {
        try {
          const [result] = await db.insert(playerEquipment).values(equipment).returning();
          return result;
        } catch (error) {
          console.error("Error in createPlayerEquipment:", error);
          throw new Error("Failed to create player equipment");
        }
      }
      async updatePlayerEquipment(id, data) {
        try {
          const [result] = await db.update(playerEquipment).set(data).where(eq2(playerEquipment.id, id)).returning();
          return result;
        } catch (error) {
          console.error(`Error in updatePlayerEquipment for ID ${id}:`, error);
          return void 0;
        }
      }
      async incrementEquipmentUsage(id) {
        try {
          const equipment = await this.getPlayerEquipmentById(id);
          if (!equipment) {
            return void 0;
          }
          const timesUsed = (equipment.timesUsed || 0) + 1;
          const [result] = await db.update(playerEquipment).set({ timesUsed, lastUsed: /* @__PURE__ */ new Date() }).where(eq2(playerEquipment.id, id)).returning();
          return result;
        } catch (error) {
          console.error(`Error in incrementEquipmentUsage for ID ${id}:`, error);
          return void 0;
        }
      }
      // Video Highlight operations
      async getVideoHighlights(videoId) {
        try {
          return await db.select().from(videoHighlights).where(eq2(videoHighlights.videoId, videoId)).orderBy(desc(videoHighlights.createdAt));
        } catch (error) {
          console.error(`Error in getVideoHighlights for video ${videoId}:`, error);
          return [];
        }
      }
      async getVideoHighlight(id) {
        try {
          const [highlight] = await db.select().from(videoHighlights).where(eq2(videoHighlights.id, id));
          return highlight;
        } catch (error) {
          console.error(`Error in getVideoHighlight for ID ${id}:`, error);
          return void 0;
        }
      }
      async createVideoHighlight(highlight) {
        try {
          const now = /* @__PURE__ */ new Date();
          const [newHighlight] = await db.insert(videoHighlights).values({
            ...highlight,
            createdAt: now
          }).returning();
          return newHighlight;
        } catch (error) {
          console.error(`Error in createVideoHighlight:`, error);
          throw error;
        }
      }
      async updateVideoHighlight(id, data) {
        try {
          const [highlight] = await db.update(videoHighlights).set(data).where(eq2(videoHighlights.id, id)).returning();
          return highlight;
        } catch (error) {
          console.error(`Error in updateVideoHighlight for ID ${id}:`, error);
          return void 0;
        }
      }
      async deleteVideoHighlight(id) {
        try {
          const result = await db.delete(videoHighlights).where(eq2(videoHighlights.id, id));
          return result.count > 0;
        } catch (error) {
          console.error(`Error in deleteVideoHighlight for ID ${id}:`, error);
          return false;
        }
      }
      async getFeaturedVideoHighlights(limit = 10) {
        try {
          return await db.select().from(videoHighlights).where(eq2(videoHighlights.featured, true)).orderBy(desc(videoHighlights.createdAt)).limit(limit);
        } catch (error) {
          console.error(`Error in getFeaturedVideoHighlights:`, error);
          return [];
        }
      }
      async generateVideoHighlight(videoId, options) {
        try {
          const video = await this.getVideo(videoId);
          if (!video) {
            throw new Error("Video not found");
          }
          const { VideoProcessor: VideoProcessor2 } = await Promise.resolve().then(() => (init_video_processor(), video_processor_exports));
          const { highlightPath, thumbnailPath } = await VideoProcessor2.createHighlight(
            video.filePath,
            {
              startTime: options.startTime,
              endTime: options.endTime
            }
          );
          const now = /* @__PURE__ */ new Date();
          const [highlight] = await db.insert(videoHighlights).values({
            videoId,
            title: options.title,
            description: options.description || null,
            startTime: options.startTime,
            endTime: options.endTime,
            highlightPath,
            // Path to the generated highlight video
            thumbnailPath,
            // Path to the generated thumbnail
            createdAt: now,
            createdBy: options.userId,
            aiGenerated: options.aiGenerated || false,
            featured: false
          }).returning();
          return highlight;
        } catch (error) {
          console.error(`Error in generateVideoHighlight for video ${videoId}:`, error);
          throw error;
        }
      }
      // Highlight Generator Config operations
      async getHighlightGeneratorConfigs() {
        try {
          return await db.select().from(highlightGeneratorConfigs);
        } catch (error) {
          console.error("Error in getHighlightGeneratorConfigs:", error);
          throw error;
        }
      }
      async getHighlightGeneratorConfigsBySport(sportType) {
        try {
          return await db.select().from(highlightGeneratorConfigs).where(eq2(highlightGeneratorConfigs.sportType, sportType));
        } catch (error) {
          console.error(`Error in getHighlightGeneratorConfigsBySport for sport ${sportType}:`, error);
          throw error;
        }
      }
      async getHighlightGeneratorConfig(id) {
        try {
          const [config] = await db.select().from(highlightGeneratorConfigs).where(eq2(highlightGeneratorConfigs.id, id));
          return config;
        } catch (error) {
          console.error(`Error in getHighlightGeneratorConfig with id ${id}:`, error);
          throw error;
        }
      }
      async createHighlightGeneratorConfig(config) {
        try {
          const [newConfig] = await db.insert(highlightGeneratorConfigs).values(config).returning();
          return newConfig;
        } catch (error) {
          console.error("Error in createHighlightGeneratorConfig:", error);
          throw error;
        }
      }
      async updateHighlightGeneratorConfig(id, data) {
        try {
          const [updatedConfig] = await db.update(highlightGeneratorConfigs).set(data).where(eq2(highlightGeneratorConfigs.id, id)).returning();
          return updatedConfig;
        } catch (error) {
          console.error(`Error in updateHighlightGeneratorConfig with id ${id}:`, error);
          throw error;
        }
      }
      async deleteHighlightGeneratorConfig(id) {
        try {
          const result = await db.delete(highlightGeneratorConfigs).where(eq2(highlightGeneratorConfigs.id, id));
          return result.count > 0;
        } catch (error) {
          console.error(`Error in deleteHighlightGeneratorConfig with id ${id}:`, error);
          throw error;
        }
      }
      async getActiveHighlightGeneratorConfigs() {
        try {
          return await db.select().from(highlightGeneratorConfigs).where(eq2(highlightGeneratorConfigs.active, true));
        } catch (error) {
          console.error("Error in getActiveHighlightGeneratorConfigs:", error);
          throw error;
        }
      }
      // Workout Verification operations
      async getWorkoutVerifications(userId) {
        try {
          return await db.select().from(workoutVerifications).where(eq2(workoutVerifications.userId, userId));
        } catch (error) {
          console.error(`Error in getWorkoutVerifications for user ${userId}:`, error);
          return [];
        }
      }
      async getPendingWorkoutVerifications() {
        try {
          return await db.select().from(workoutVerifications).where(eq2(workoutVerifications.verificationStatus, "pending")).orderBy(desc(workoutVerifications.submissionDate));
        } catch (error) {
          console.error("Error in getPendingWorkoutVerifications:", error);
          return [];
        }
      }
      async getWorkoutVerification(id) {
        try {
          const [result] = await db.select().from(workoutVerifications).where(eq2(workoutVerifications.id, id)).limit(1);
          return result;
        } catch (error) {
          console.error(`Error in getWorkoutVerification for ID ${id}:`, error);
          return void 0;
        }
      }
      async createWorkoutVerification(verification) {
        try {
          const [result] = await db.insert(workoutVerifications).values(verification).returning();
          return result;
        } catch (error) {
          console.error("Error in createWorkoutVerification:", error);
          throw new Error("Failed to create workout verification");
        }
      }
      async updateWorkoutVerification(id, data) {
        try {
          const [result] = await db.update(workoutVerifications).set(data).where(eq2(workoutVerifications.id, id)).returning();
          return result;
        } catch (error) {
          console.error(`Error in updateWorkoutVerification for ID ${id}:`, error);
          return void 0;
        }
      }
      async getWorkoutVerificationCheckpoints(verificationId) {
        try {
          return await db.select().from(workoutVerificationCheckpoints).where(eq2(workoutVerificationCheckpoints.verificationId, verificationId)).orderBy(workoutVerificationCheckpoints.checkpointOrder);
        } catch (error) {
          console.error(`Error in getWorkoutVerificationCheckpoints for verification ${verificationId}:`, error);
          return [];
        }
      }
      async createWorkoutVerificationCheckpoint(checkpoint) {
        try {
          const [result] = await db.insert(workoutVerificationCheckpoints).values(checkpoint).returning();
          return result;
        } catch (error) {
          console.error("Error in createWorkoutVerificationCheckpoint:", error);
          throw new Error("Failed to create workout verification checkpoint");
        }
      }
      async updateWorkoutVerificationCheckpoint(id, data) {
        try {
          const [result] = await db.update(workoutVerificationCheckpoints).set(data).where(eq2(workoutVerificationCheckpoints.id, id)).returning();
          return result;
        } catch (error) {
          console.error(`Error in updateWorkoutVerificationCheckpoint for ID ${id}:`, error);
          return void 0;
        }
      }
      async verifyWorkout(id, verifierId, status, xpEarned, feedback) {
        try {
          const [result] = await db.update(workoutVerifications).set({
            verificationStatus: status,
            verifiedBy: verifierId,
            verificationDate: /* @__PURE__ */ new Date(),
            notes: feedback,
            xpEarned
          }).where(eq2(workoutVerifications.id, id)).returning();
          if (status === "approved" && result) {
            await this.addXpToPlayer(
              result.userId,
              xpEarned,
              "workout",
              `Workout verification: ${result.title}`,
              result.id.toString()
            );
          }
          return result;
        } catch (error) {
          console.error(`Error in verifyWorkout for ID ${id}:`, error);
          return void 0;
        }
      }
      // Method to seed initial data
      async seedInitialData() {
        const existingUsers = await db.select().from(users);
        if (existingUsers.length > 0) {
          console.log("Basic data already seeded, checking for realistic athletes...");
          const { seedRealisticAthletes: seedRealisticAthletes2 } = await Promise.resolve().then(() => (init_seed_athletes(), seed_athletes_exports));
          await seedRealisticAthletes2();
          return;
        }
        const [athleteUser] = await db.insert(users).values({
          username: "alexjohnson",
          password: await hashPassword2("password123"),
          email: "alex@example.com",
          name: "Alex Johnson",
          role: "athlete",
          profileImage: "https://images.unsplash.com/photo-1628157588553-5eeea00af15c?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80",
          bio: "High school student athlete looking to compete at the college level.",
          createdAt: /* @__PURE__ */ new Date()
        }).returning();
        const [coachUser1] = await db.insert(users).values({
          username: "coachwilliams",
          password: await hashPassword2("coachpass123"),
          email: "williams@stateuniversity.edu",
          name: "Coach Williams",
          role: "coach",
          profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80",
          bio: "Basketball coach at State University with 15 years of experience.",
          createdAt: /* @__PURE__ */ new Date()
        }).returning();
        const [coachUser2] = await db.insert(users).values({
          username: "coachmartinez",
          password: await hashPassword2("coachpass456"),
          email: "martinez@centralcollege.edu",
          name: "Coach Martinez",
          role: "coach",
          profileImage: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80",
          bio: "Track and Field coach at Central College specializing in sprints and jumps.",
          createdAt: /* @__PURE__ */ new Date()
        }).returning();
        const [adminUser] = await db.insert(users).values({
          username: "admin",
          password: await hashPassword2("adminpass123"),
          email: "admin@goforit.com",
          name: "Admin User",
          role: "admin",
          createdAt: /* @__PURE__ */ new Date()
        }).returning();
        const [newAdmin] = await db.insert(users).values({
          username: "superadmin",
          password: await hashPassword2("superadmin123"),
          email: "superadmin@goforit.com",
          name: "Super Admin",
          role: "admin",
          createdAt: /* @__PURE__ */ new Date()
        }).returning();
        const [athleteProfile] = await db.insert(athleteProfiles).values({
          userId: athleteUser.id,
          height: 188,
          // 6'2" in cm
          weight: 82,
          // 180 lbs in kg
          age: 17,
          school: "Washington High School",
          graduationYear: 2024,
          sportsInterest: ["basketball", "volleyball", "track"],
          academicInterest: ["computer science", "engineering"],
          gpa: 3.7
        }).returning();
        const [coachProfile1] = await db.insert(coachProfiles).values({
          userId: coachUser1.id,
          institution: "State University",
          sport: "basketball",
          position: "Head Coach",
          experience: 15,
          achievements: ["2x State Champions", "Coach of the Year 2022"],
          lookingFor: "Point guards with strong leadership and shooting ability."
        }).returning();
        const [coachProfile2] = await db.insert(coachProfiles).values({
          userId: coachUser2.id,
          institution: "Central College",
          sport: "track",
          position: "Assistant Coach",
          experience: 8,
          achievements: ["National Champions 2023", "Developed 3 Olympic athletes"],
          lookingFor: "Sprinters and long jumpers with potential for development."
        }).returning();
        const [sampleVideo] = await db.insert(videos).values({
          userId: athleteUser.id,
          title: "Basketball Jump Shot Form",
          description: "My current jump shot form - looking for feedback.",
          filePath: "/uploads/sample-jumpshot.mp4",
          thumbnailPath: "/uploads/sample-jumpshot-thumb.jpg",
          sport: "basketball",
          uploadDate: /* @__PURE__ */ new Date(),
          analyzed: true,
          duration: 8.5,
          // seconds
          fileSize: 2.4
          // MB
        }).returning();
        const [sampleAnalysis] = await db.insert(videoAnalyses).values({
          videoId: sampleVideo.id,
          overallScore: 7.5,
          feedback: "Your jump shot shows good potential. Your elbow alignment is excellent, but you need to work on your follow-through and balance.",
          improvementTips: [
            "Hold your follow-through longer after release",
            "Focus on landing in the same spot you jumped from",
            "Try to maintain more consistent arc on the ball"
          ],
          analysisData: {
            elbowAlignment: 9.2,
            releasePoint: 7.8,
            followThrough: 6.5,
            balance: 6.9,
            keypoints: [
              { x: 0.45, y: 0.38, confidence: 0.87, name: "right_elbow" },
              { x: 0.47, y: 0.26, confidence: 0.92, name: "right_wrist" },
              { x: 0.49, y: 0.18, confidence: 0.85, name: "right_hand" }
            ]
          },
          keyFrameTimestamps: [1.2, 3.7, 4.5],
          analysisDate: new Date(Date.now() - 48 * 60 * 60 * 1e3)
          // 2 days ago
        }).returning();
        const [basketballRecommendation] = await db.insert(sportRecommendations).values({
          userId: athleteUser.id,
          sport: "basketball",
          matchPercentage: 85,
          positionRecommendation: "Shooting Guard",
          potentialLevel: "College Division I",
          reasonForMatch: "Your height, coordination, and shooting form indicate strong potential as a shooting guard. Your analysis shows excellent shooting mechanics that could be developed further.",
          recommendationDate: new Date(Date.now() - 40 * 60 * 60 * 1e3)
          // 40 hours ago
        }).returning();
        const [volleyballRecommendation] = await db.insert(sportRecommendations).values({
          userId: athleteUser.id,
          sport: "volleyball",
          matchPercentage: 72,
          positionRecommendation: "Outside Hitter",
          potentialLevel: "College Division II",
          reasonForMatch: "Your height and jumping ability suggest good potential for volleyball. Your coordination and timing would transfer well to spiking and blocking.",
          recommendationDate: new Date(Date.now() - 39 * 60 * 60 * 1e3)
          // 39 hours ago
        }).returning();
        const [trackRecommendation] = await db.insert(sportRecommendations).values({
          userId: athleteUser.id,
          sport: "track",
          matchPercentage: 68,
          positionRecommendation: "Long Jump",
          potentialLevel: "College Division II",
          reasonForMatch: "Your explosive jumping ability and coordination indicate potential in long jump. With focused training, you could develop the technique required for success.",
          recommendationDate: new Date(Date.now() - 38 * 60 * 60 * 1e3)
          // 38 hours ago
        }).returning();
        const [ncaaEligibility2] = await db.insert(ncaaEligibility2).values({
          userId: athleteUser.id,
          academicStatus: "On Track",
          coreCourses: [
            { name: "English I", grade: "A", credits: 1, completed: true },
            { name: "Algebra II", grade: "B+", credits: 1, completed: true },
            { name: "Chemistry", grade: "B", credits: 1, completed: true },
            { name: "World History", grade: "A-", credits: 1, completed: true },
            { name: "English II", grade: "In Progress", credits: 1, completed: false }
          ],
          satScore: 1180,
          actScore: 26,
          eligibilityCenter: {
            registered: true,
            registrationDate: new Date(Date.now() - 60 * 24 * 60 * 60 * 1e3),
            // 60 days ago
            status: "Initial Review Complete",
            academicCertification: "Pending Final Transcripts"
          },
          amateurStatus: true,
          notes: "Need to submit final transcripts after graduation.",
          lastUpdated: new Date(Date.now() - 10 * 24 * 60 * 60 * 1e3)
          // 10 days ago
        }).returning();
        const [connection1] = await db.insert(coachConnections).values({
          athleteId: athleteUser.id,
          coachId: coachUser1.id,
          status: "in_contact",
          notes: "Initial contact made after Coach Williams saw my shooting video. Discussing potential campus visit.",
          connectionDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1e3),
          // 15 days ago
          lastContact: new Date(Date.now() - 3 * 24 * 60 * 60 * 1e3),
          // 3 days ago
          recruitmentStage: "interested"
        }).returning();
        const [connection2] = await db.insert(coachConnections).values({
          athleteId: athleteUser.id,
          coachId: coachUser2.id,
          status: "watching",
          notes: "Coach Martinez expressed interest in my long jump potential after seeing track recommendation.",
          connectionDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1e3),
          // 7 days ago
          lastContact: new Date(Date.now() - 7 * 24 * 60 * 60 * 1e3),
          // 7 days ago
          recruitmentStage: "prospect"
        }).returning();
        const [achievement1] = await db.insert(achievements).values({
          userId: athleteUser.id,
          title: "First Video Analysis",
          description: "Completed your first video analysis",
          type: "platform",
          iconPath: "/icons/video-analysis.svg",
          earnedDate: new Date(Date.now() - 48 * 60 * 60 * 1e3)
          // 2 days ago
        }).returning();
        const [achievement2] = await db.insert(achievements).values({
          userId: athleteUser.id,
          title: "Sport Matched",
          description: "Received your first sport match recommendation",
          type: "platform",
          iconPath: "/icons/sport-match.svg",
          earnedDate: new Date(Date.now() - 40 * 60 * 60 * 1e3)
          // 40 hours ago
        }).returning();
        const [achievement3] = await db.insert(achievements).values({
          userId: athleteUser.id,
          title: "Coach Connection",
          description: "Connected with your first college coach",
          type: "platform",
          iconPath: "/icons/coach-connection.svg",
          earnedDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1e3)
          // 15 days ago
        }).returning();
        const [achievement4] = await db.insert(achievements).values({
          userId: athleteUser.id,
          title: "District Champion",
          description: "Won the district championship in basketball",
          type: "sports",
          iconPath: "/icons/trophy.svg",
          earnedDate: new Date(Date.now() - 90 * 24 * 60 * 60 * 1e3)
          // 90 days ago
        }).returning();
        const now = /* @__PURE__ */ new Date();
        const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1e3);
        const twoWeeksAgo = new Date(Date.now() - 14 * 24 * 60 * 60 * 1e3);
        const [strengthPlaylist] = await db.insert(workoutPlaylists).values({
          userId: athleteUser.id,
          title: "Upper Body Strength",
          description: "A comprehensive upper body workout focusing on arms, chest, and shoulders",
          workoutType: "strength",
          intensityLevel: "medium",
          duration: 45,
          targets: ["arms", "chest", "shoulders"],
          createdAt: twoWeeksAgo,
          lastUsed: oneWeekAgo,
          timesUsed: 5,
          isCustom: true,
          isPublic: false
        }).returning();
        await db.insert(workoutExercises).values({
          playlistId: strengthPlaylist.id,
          name: "Push-ups",
          description: "Standard push-ups with proper form",
          sets: 3,
          reps: 15,
          restPeriod: 60,
          order: 1,
          notes: "Keep core tight and maintain straight back"
        });
        await db.insert(workoutExercises).values({
          playlistId: strengthPlaylist.id,
          name: "Dumbbell Curls",
          description: "Alternating dumbbell curls",
          sets: 3,
          reps: 12,
          restPeriod: 45,
          order: 2,
          notes: "Use controlled movements"
        });
        await db.insert(workoutExercises).values({
          playlistId: strengthPlaylist.id,
          name: "Shoulder Press",
          description: "Dumbbell shoulder presses",
          sets: 3,
          reps: 10,
          restPeriod: 60,
          order: 3,
          equipmentNeeded: ["dumbbells"]
        });
        const [cardioPlaylist] = await db.insert(workoutPlaylists).values({
          userId: coachUser1.id,
          title: "Basketball Conditioning",
          description: "High-intensity cardio workout for basketball players",
          workoutType: "cardio",
          intensityLevel: "high",
          duration: 30,
          targets: ["stamina", "agility", "speed"],
          createdAt: twoWeeksAgo,
          lastUsed: now,
          timesUsed: 12,
          isCustom: true,
          isPublic: true
        }).returning();
        await db.insert(workoutExercises).values({
          playlistId: cardioPlaylist.id,
          name: "Suicides",
          description: "Court length sprints with increasing distances",
          duration: 300,
          // 5 minutes
          order: 1,
          equipmentNeeded: ["basketball court"]
        });
        await db.insert(workoutExercises).values({
          playlistId: cardioPlaylist.id,
          name: "Jump Rope",
          description: "High-intensity jump rope intervals",
          duration: 180,
          // 3 minutes
          order: 2,
          equipmentNeeded: ["jump rope"]
        });
        await db.insert(workoutExercises).values({
          playlistId: cardioPlaylist.id,
          name: "Defensive Slides",
          description: "Side-to-side defensive movement drills",
          duration: 240,
          // 4 minutes
          order: 3
        });
        const [flexibilityPlaylist] = await db.insert(workoutPlaylists).values({
          userId: athleteUser.id,
          title: "Post-Game Recovery",
          description: "Gentle stretching routine for recovery after games",
          workoutType: "flexibility",
          intensityLevel: "low",
          duration: 20,
          targets: ["recovery", "flexibility"],
          createdAt: oneWeekAgo,
          lastUsed: now,
          timesUsed: 3,
          isCustom: true,
          isPublic: false
        }).returning();
        await db.insert(workoutExercises).values({
          playlistId: flexibilityPlaylist.id,
          name: "Hamstring Stretch",
          description: "Seated hamstring stretch",
          duration: 60,
          // 1 minute
          sets: 2,
          order: 1
        });
        await db.insert(workoutExercises).values({
          playlistId: flexibilityPlaylist.id,
          name: "Quad Stretch",
          description: "Standing quad stretch with support",
          duration: 60,
          // 1 minute
          sets: 2,
          order: 2
        });
        await db.insert(workoutExercises).values({
          playlistId: flexibilityPlaylist.id,
          name: "Shoulder Stretch",
          description: "Cross-body shoulder stretch",
          duration: 60,
          // 1 minute
          sets: 2,
          order: 3
        });
        await db.insert(contentBlocks).values({
          identifier: "what-makes-us-different-ai-analysis",
          title: "AI Motion Analysis",
          content: "Our cutting-edge AI technology analyzes your motion mechanics with professional-grade accuracy, providing detailed feedback on your form, technique, and movement patterns.",
          section: "what-makes-us-different",
          order: 1,
          active: true,
          metadata: {
            iconName: "cpu",
            backgroundColor: "bg-blue-100"
          }
        });
        await db.insert(contentBlocks).values({
          identifier: "what-makes-us-different-verified-combines",
          title: "Verified Combines",
          content: "Participate in certified athletic combines where your performance metrics are verified by professionals, giving college scouts reliable data they can trust.",
          section: "what-makes-us-different",
          order: 2,
          active: true,
          metadata: {
            iconName: "badge-check",
            backgroundColor: "bg-green-100"
          }
        });
        await db.insert(contentBlocks).values({
          identifier: "what-makes-us-different-scout-connection",
          title: "Direct Scout Connection",
          content: "Get noticed by college scouts through our verified platform that connects talented athletes directly with college recruiting programs across the country.",
          section: "what-makes-us-different",
          order: 3,
          active: true,
          metadata: {
            iconName: "users",
            backgroundColor: "bg-yellow-100"
          }
        });
        await db.insert(contentBlocks).values({
          identifier: "what-makes-us-different-personalized-development",
          title: "Personalized Development",
          content: "Receive tailored training programs and development paths based on your specific needs, goals, and athletic profile, helping you reach your full potential.",
          section: "what-makes-us-different",
          order: 4,
          active: true,
          metadata: {
            iconName: "trending-up",
            backgroundColor: "bg-purple-100"
          }
        });
      }
      // API Key operations
      async getApiKey(keyType) {
        const [apiKey] = await db.select().from(apiKeys).where(eq2(apiKeys.keyType, keyType));
        return apiKey;
      }
      async getAllApiKeys() {
        return await db.select().from(apiKeys).orderBy(asc(apiKeys.keyType));
      }
      async getAllActiveApiKeys() {
        return await db.select().from(apiKeys).where(eq2(apiKeys.isActive, true)).orderBy(asc(apiKeys.keyType));
      }
      async getApiKeyStatus() {
        const keys = await this.getAllApiKeys();
        const keyTypes = ["openai", "stripe", "sendgrid", "twilio", "google", "aws", "active"];
        const result = {};
        for (const keyType of keyTypes) {
          result[keyType] = keys.some((key) => key.keyType === keyType && key.isActive);
        }
        return result;
      }
      async saveApiKey(key) {
        const now = /* @__PURE__ */ new Date();
        const existingKey = await this.getApiKey(key.keyType);
        if (existingKey) {
          const [updatedKey] = await db.update(apiKeys).set({
            keyValue: key.keyValue,
            isActive: key.isActive,
            lastUsed: now
          }).where(eq2(apiKeys.keyType, key.keyType)).returning();
          if (key.keyType === "openai" && process.env) {
            process.env.OPENAI_API_KEY = key.keyValue;
          }
          return updatedKey;
        } else {
          const [newApiKey] = await db.insert(apiKeys).values({
            keyType: key.keyType,
            keyValue: key.keyValue,
            addedAt: now,
            isActive: key.isActive ?? true
          }).returning();
          if (key.keyType === "openai" && process.env) {
            process.env.OPENAI_API_KEY = key.keyValue;
          }
          return newApiKey;
        }
      }
      async updateApiKey(keyType, data) {
        if (data.keyValue && keyType === "openai" && process.env) {
          process.env.OPENAI_API_KEY = data.keyValue;
        }
        const [updatedKey] = await db.update(apiKeys).set(data).where(eq2(apiKeys.keyType, keyType)).returning();
        return updatedKey;
      }
      async deleteApiKey(keyType) {
        const result = await db.delete(apiKeys).where(eq2(apiKeys.keyType, keyType));
        return result.count > 0;
      }
      // Athlete Star Profile operations
      async getAthleteStarProfiles(filters) {
        let query = db.select().from(athleteStarProfiles);
        if (filters) {
          if (filters.sport) {
            query = query.where(eq2(athleteStarProfiles.sport, filters.sport));
          }
          if (filters.position) {
            query = query.where(eq2(athleteStarProfiles.position, filters.position));
          }
          if (filters.starLevel) {
            query = query.where(eq2(athleteStarProfiles.starLevel, filters.starLevel));
          }
        }
        return await query.orderBy(desc(athleteStarProfiles.createdAt));
      }
      async getAthleteStarProfile(id) {
        const [profile] = await db.select().from(athleteStarProfiles).where(eq2(athleteStarProfiles.id, id));
        return profile;
      }
      async createAthleteStarProfile(profile) {
        const now = /* @__PURE__ */ new Date();
        const [newProfile] = await db.insert(athleteStarProfiles).values({
          ...profile,
          createdAt: now,
          updatedAt: now
        }).returning();
        return newProfile;
      }
      // Onboarding Progress operations
      async getOnboardingProgress(userId) {
        const [progress] = await db.select().from(onboardingProgress).where(eq2(onboardingProgress.userId, userId));
        return progress;
      }
      async createOnboardingProgress(progress) {
        const now = /* @__PURE__ */ new Date();
        const [newProgress] = await db.insert(onboardingProgress).values({
          ...progress,
          lastUpdated: now
        }).returning();
        return newProgress;
      }
      async updateOnboardingProgress(userId, data) {
        const now = /* @__PURE__ */ new Date();
        const [updatedProgress] = await db.update(onboardingProgress).set({
          ...data,
          lastUpdated: now
        }).where(eq2(onboardingProgress.userId, userId)).returning();
        return updatedProgress;
      }
      // Athlete Journey Map operations
      async getAthleteJourneyMap(userId) {
        const [journeyMap] = await db.select().from(athleteJourneyMap).where(eq2(athleteJourneyMap.userId, userId));
        return journeyMap;
      }
      async createAthleteJourneyMap(journeyMap) {
        const now = /* @__PURE__ */ new Date();
        const [newJourneyMap] = await db.insert(athleteJourneyMap).values({
          ...journeyMap,
          startedAt: now,
          updatedAt: now
        }).returning();
        return newJourneyMap;
      }
      async updateAthleteJourneyMap(userId, data) {
        const now = /* @__PURE__ */ new Date();
        const [updatedJourneyMap] = await db.update(athleteJourneyMap).set({
          ...data,
          updatedAt: now
        }).where(eq2(athleteJourneyMap.userId, userId)).returning();
        return updatedJourneyMap;
      }
      // Journey Milestone operations
      async getJourneyMilestones(journeyMapId) {
        return await db.select().from(journeyMilestones).where(eq2(journeyMilestones.journeyMapId, journeyMapId)).orderBy(asc(journeyMilestones.priority));
      }
      async getJourneyMilestone(id) {
        const [milestone] = await db.select().from(journeyMilestones).where(eq2(journeyMilestones.id, id));
        return milestone;
      }
      async createJourneyMilestone(milestone) {
        const [newMilestone] = await db.insert(journeyMilestones).values(milestone).returning();
        return newMilestone;
      }
      async updateJourneyMilestone(id, data) {
        const [updatedMilestone] = await db.update(journeyMilestones).set(data).where(eq2(journeyMilestones.id, id)).returning();
        return updatedMilestone;
      }
      async deleteJourneyMilestone(id) {
        const result = await db.delete(journeyMilestones).where(eq2(journeyMilestones.id, id));
        return result.count > 0;
      }
    };
  }
});

// server/storage.ts
var storage_exports = {};
__export(storage_exports, {
  MemStorage: () => MemStorage,
  storage: () => storage
});
import session3 from "express-session";
import createMemoryStore from "memorystore";
var MemStorage, storage;
var init_storage = __esm({
  "server/storage.ts"() {
    "use strict";
    init_database_storage();
    MemStorage = class {
      sessionStore;
      users;
      athleteProfiles;
      athleteStarProfiles;
      coachProfiles;
      videos;
      videoAnalyses;
      sportRecommendations;
      ncaaEligibility;
      userAgreements;
      // NCAA related components
      ncaaCoreCourses;
      gradeScales;
      ncaaSlidingScales;
      ncaaDocuments;
      ncaaRegistration;
      coachConnections;
      achievements;
      messages;
      // Story mode components
      skills;
      challenges;
      athleteChallenges;
      recoveryLogs;
      fanClubFollowers;
      leaderboardEntries;
      // Content components
      blogPosts;
      contentBlocks;
      featuredAthletes;
      // Workout playlist components
      workoutPlaylists;
      workoutExercises;
      // Film comparison components
      filmComparisons;
      comparisonVideos;
      comparisonAnalyses;
      // Spotlight profile components
      spotlightProfiles;
      // MyPlayer XP system components
      playerProgress;
      xpTransactions;
      playerBadges;
      // Workout verification components
      workoutVerifications;
      workoutVerificationCheckpoints;
      // Weight room equipment components
      weightRoomEquipment;
      playerEquipment;
      apiKeys;
      currentUserId;
      currentAthleteProfileId;
      currentCoachProfileId;
      currentVideoId;
      currentVideoAnalysisId;
      currentSportRecommendationId;
      currentNcaaEligibilityId;
      // NCAA related IDs
      currentNcaaCoreCourseId;
      currentGradeScaleId;
      currentNcaaSlidingScaleId;
      currentNcaaDocumentId;
      currentNcaaRegistrationId;
      currentCoachConnectionId;
      currentAchievementId;
      currentMessageId;
      currentSkillId;
      currentChallengeId;
      currentAthleteChallengeId;
      currentRecoveryLogId;
      currentFanClubFollowerId;
      currentLeaderboardEntryId;
      currentBlogPostId;
      currentContentBlockId;
      currentFeaturedAthleteId;
      currentWorkoutPlaylistId;
      currentWorkoutExerciseId;
      // Film comparison IDs
      currentFilmComparisonId;
      currentComparisonVideoId;
      currentComparisonAnalysisId;
      // Spotlight profile IDs
      currentSpotlightProfileId;
      // MyPlayer XP system IDs
      currentPlayerProgressId;
      currentXpTransactionId;
      currentPlayerBadgeId;
      // Workout verification IDs
      currentWorkoutVerificationId;
      currentWorkoutVerificationCheckpointId;
      // Weight room equipment IDs
      currentWeightRoomEquipmentId;
      currentPlayerEquipmentId;
      currentAthleteStarProfileId;
      onboardingProgress;
      currentOnboardingProgressId;
      athleteJourneyMap;
      currentAthleteJourneyMapId;
      journeyMilestones;
      currentJourneyMilestoneId;
      currentUserAgreementId;
      constructor() {
        const MemoryStore = createMemoryStore(session3);
        this.sessionStore = new MemoryStore({
          checkPeriod: 864e5
          // Prune expired entries every 24h
        });
        this.users = /* @__PURE__ */ new Map();
        this.athleteProfiles = /* @__PURE__ */ new Map();
        this.athleteStarProfiles = /* @__PURE__ */ new Map();
        this.coachProfiles = /* @__PURE__ */ new Map();
        this.videos = /* @__PURE__ */ new Map();
        this.videoAnalyses = /* @__PURE__ */ new Map();
        this.sportRecommendations = /* @__PURE__ */ new Map();
        this.ncaaEligibility = /* @__PURE__ */ new Map();
        this.userAgreements = /* @__PURE__ */ new Map();
        this.ncaaCoreCourses = /* @__PURE__ */ new Map();
        this.gradeScales = /* @__PURE__ */ new Map();
        this.ncaaSlidingScales = /* @__PURE__ */ new Map();
        this.ncaaDocuments = /* @__PURE__ */ new Map();
        this.ncaaRegistration = /* @__PURE__ */ new Map();
        this.coachConnections = /* @__PURE__ */ new Map();
        this.achievements = /* @__PURE__ */ new Map();
        this.messages = /* @__PURE__ */ new Map();
        this.skills = /* @__PURE__ */ new Map();
        this.challenges = /* @__PURE__ */ new Map();
        this.athleteChallenges = /* @__PURE__ */ new Map();
        this.recoveryLogs = /* @__PURE__ */ new Map();
        this.fanClubFollowers = /* @__PURE__ */ new Map();
        this.leaderboardEntries = /* @__PURE__ */ new Map();
        this.blogPosts = /* @__PURE__ */ new Map();
        this.contentBlocks = /* @__PURE__ */ new Map();
        this.featuredAthletes = /* @__PURE__ */ new Map();
        this.workoutPlaylists = /* @__PURE__ */ new Map();
        this.workoutExercises = /* @__PURE__ */ new Map();
        this.filmComparisons = /* @__PURE__ */ new Map();
        this.comparisonVideos = /* @__PURE__ */ new Map();
        this.comparisonAnalyses = /* @__PURE__ */ new Map();
        this.spotlightProfiles = /* @__PURE__ */ new Map();
        this.playerProgress = /* @__PURE__ */ new Map();
        this.xpTransactions = /* @__PURE__ */ new Map();
        this.playerBadges = /* @__PURE__ */ new Map();
        this.workoutVerifications = /* @__PURE__ */ new Map();
        this.workoutVerificationCheckpoints = /* @__PURE__ */ new Map();
        this.weightRoomEquipment = /* @__PURE__ */ new Map();
        this.playerEquipment = /* @__PURE__ */ new Map();
        this.apiKeys = /* @__PURE__ */ new Map();
        this.onboardingProgress = /* @__PURE__ */ new Map();
        this.athleteJourneyMap = /* @__PURE__ */ new Map();
        this.journeyMilestones = /* @__PURE__ */ new Map();
        this.currentUserId = 1;
        this.currentAthleteProfileId = 1;
        this.currentCoachProfileId = 1;
        this.currentVideoId = 1;
        this.currentVideoAnalysisId = 1;
        this.currentSportRecommendationId = 1;
        this.currentNcaaEligibilityId = 1;
        this.currentNcaaCoreCourseId = 1;
        this.currentGradeScaleId = 1;
        this.currentNcaaSlidingScaleId = 1;
        this.currentNcaaDocumentId = 1;
        this.currentNcaaRegistrationId = 1;
        this.currentCoachConnectionId = 1;
        this.currentAchievementId = 1;
        this.currentMessageId = 1;
        this.currentSkillId = 1;
        this.currentChallengeId = 1;
        this.currentAthleteChallengeId = 1;
        this.currentRecoveryLogId = 1;
        this.currentFanClubFollowerId = 1;
        this.currentLeaderboardEntryId = 1;
        this.currentBlogPostId = 1;
        this.currentContentBlockId = 1;
        this.currentFeaturedAthleteId = 1;
        this.currentWorkoutPlaylistId = 1;
        this.currentWorkoutExerciseId = 1;
        this.currentFilmComparisonId = 1;
        this.currentComparisonVideoId = 1;
        this.currentComparisonAnalysisId = 1;
        this.currentSpotlightProfileId = 1;
        this.currentPlayerProgressId = 1;
        this.currentXpTransactionId = 1;
        this.currentPlayerBadgeId = 1;
        this.currentWorkoutVerificationId = 1;
        this.currentWorkoutVerificationCheckpointId = 1;
        this.currentWeightRoomEquipmentId = 1;
        this.currentPlayerEquipmentId = 1;
        this.currentAthleteStarProfileId = 1;
        this.currentOnboardingProgressId = 1;
        this.currentAthleteJourneyMapId = 1;
        this.currentJourneyMilestoneId = 1;
        this.currentUserAgreementId = 1;
        this.seedInitialData();
      }
      // User operations
      async getUser(id) {
        return this.users.get(id);
      }
      async getUserByUsername(username) {
        return Array.from(this.users.values()).find(
          (user) => user.username.toLowerCase() === username.toLowerCase()
        );
      }
      async getUserByEmail(email) {
        return Array.from(this.users.values()).find(
          (user) => user.email.toLowerCase() === email.toLowerCase()
        );
      }
      async createUser(insertUser) {
        const id = this.currentUserId++;
        const now = /* @__PURE__ */ new Date();
        const user = { ...insertUser, id, createdAt: now };
        this.users.set(id, user);
        return user;
      }
      async updateUser(id, data) {
        const user = this.users.get(id);
        if (!user) return void 0;
        const updatedUser = { ...user, ...data };
        this.users.set(id, updatedUser);
        return updatedUser;
      }
      // Athlete Profile operations
      async getAthleteProfile(userId) {
        return Array.from(this.athleteProfiles.values()).find(
          (profile) => profile.userId === userId
        );
      }
      async createAthleteProfile(profile) {
        const id = this.currentAthleteProfileId++;
        const athleteProfile = { ...profile, id };
        this.athleteProfiles.set(id, athleteProfile);
        return athleteProfile;
      }
      async updateAthleteProfile(userId, data) {
        const profile = Array.from(this.athleteProfiles.values()).find(
          (profile2) => profile2.userId === userId
        );
        if (!profile) return void 0;
        const updatedProfile = { ...profile, ...data };
        this.athleteProfiles.set(profile.id, updatedProfile);
        return updatedProfile;
      }
      // Coach Profile operations
      async getCoachProfile(userId) {
        return Array.from(this.coachProfiles.values()).find(
          (profile) => profile.userId === userId
        );
      }
      async createCoachProfile(profile) {
        const id = this.currentCoachProfileId++;
        const coachProfile = { ...profile, id };
        this.coachProfiles.set(id, coachProfile);
        return coachProfile;
      }
      async updateCoachProfile(userId, data) {
        const profile = Array.from(this.coachProfiles.values()).find(
          (profile2) => profile2.userId === userId
        );
        if (!profile) return void 0;
        const updatedProfile = { ...profile, ...data };
        this.coachProfiles.set(profile.id, updatedProfile);
        return updatedProfile;
      }
      // Video operations
      async getVideo(id) {
        return this.videos.get(id);
      }
      async getVideosByUser(userId) {
        return Array.from(this.videos.values()).filter(
          (video) => video.userId === userId
        );
      }
      async createVideo(video) {
        const id = this.currentVideoId++;
        const now = /* @__PURE__ */ new Date();
        const newVideo = {
          ...video,
          id,
          uploadDate: now,
          analyzed: false
        };
        this.videos.set(id, newVideo);
        return newVideo;
      }
      async updateVideo(id, data) {
        const video = this.videos.get(id);
        if (!video) return void 0;
        const updatedVideo = { ...video, ...data };
        this.videos.set(id, updatedVideo);
        return updatedVideo;
      }
      async deleteVideo(id) {
        return this.videos.delete(id);
      }
      // Video Analysis operations
      async getVideoAnalysis(id) {
        return this.videoAnalyses.get(id);
      }
      async getVideoAnalysisByVideoId(videoId) {
        return Array.from(this.videoAnalyses.values()).find(
          (analysis) => analysis.videoId === videoId
        );
      }
      async createVideoAnalysis(analysis) {
        const id = this.currentVideoAnalysisId++;
        const now = /* @__PURE__ */ new Date();
        const videoAnalysis = { ...analysis, id, analysisDate: now };
        this.videoAnalyses.set(id, videoAnalysis);
        const video = this.videos.get(analysis.videoId);
        if (video) {
          this.videos.set(analysis.videoId, { ...video, analyzed: true });
        }
        return videoAnalysis;
      }
      async saveVideoAnalysis(videoId, analysis) {
        const existingAnalysis = await this.getVideoAnalysisByVideoId(videoId);
        if (existingAnalysis) {
          const updatedAnalysis = {
            ...existingAnalysis,
            motionData: analysis.motionData,
            overallScore: analysis.overallScore,
            feedback: analysis.feedback,
            improvementTips: analysis.improvementTips,
            keyFrameTimestamps: analysis.keyFrameTimestamps,
            analysisDate: /* @__PURE__ */ new Date()
          };
          this.videoAnalyses.set(existingAnalysis.id, updatedAnalysis);
          return updatedAnalysis;
        } else {
          const newAnalysis = {
            videoId,
            motionData: analysis.motionData,
            overallScore: analysis.overallScore,
            feedback: analysis.feedback,
            improvementTips: analysis.improvementTips,
            keyFrameTimestamps: analysis.keyFrameTimestamps
          };
          return this.createVideoAnalysis(newAnalysis);
        }
      }
      // Sport Recommendation operations
      async getSportRecommendations(userId) {
        return Array.from(this.sportRecommendations.values()).filter(
          (recommendation) => recommendation.userId === userId
        );
      }
      async createSportRecommendation(recommendation) {
        const id = this.currentSportRecommendationId++;
        const now = /* @__PURE__ */ new Date();
        const sportRecommendation = {
          ...recommendation,
          id,
          recommendationDate: now
        };
        this.sportRecommendations.set(id, sportRecommendation);
        return sportRecommendation;
      }
      // NCAA Eligibility operations
      async getNcaaEligibility(userId) {
        return Array.from(this.ncaaEligibility.values()).find(
          (eligibility) => eligibility.userId === userId
        );
      }
      async createNcaaEligibility(eligibility) {
        const id = this.currentNcaaEligibilityId++;
        const now = /* @__PURE__ */ new Date();
        const ncaaEligibility2 = {
          ...eligibility,
          id,
          lastUpdated: now
        };
        this.ncaaEligibility.set(id, ncaaEligibility2);
        return ncaaEligibility2;
      }
      async updateNcaaEligibility(userId, data) {
        const eligibility = Array.from(this.ncaaEligibility.values()).find(
          (eligibility2) => eligibility2.userId === userId
        );
        if (!eligibility) return void 0;
        const now = /* @__PURE__ */ new Date();
        const updatedEligibility = {
          ...eligibility,
          ...data,
          lastUpdated: now
        };
        this.ncaaEligibility.set(eligibility.id, updatedEligibility);
        return updatedEligibility;
      }
      // NCAA Core Course Operations
      async getNcaaCoreCourses(userId) {
        return Array.from(this.ncaaCoreCourses.values()).filter(
          (course) => course.userId === userId
        );
      }
      async getNcaaCoreCourse(id) {
        return this.ncaaCoreCourses.get(id);
      }
      async createNcaaCoreCourse(course) {
        const id = this.currentNcaaCoreCourseId++;
        const ncaaCoreCourse = { ...course, id };
        this.ncaaCoreCourses.set(id, ncaaCoreCourse);
        return ncaaCoreCourse;
      }
      async updateNcaaCoreCourse(id, data) {
        const course = this.ncaaCoreCourses.get(id);
        if (!course) return void 0;
        const updatedCourse = { ...course, ...data };
        this.ncaaCoreCourses.set(id, updatedCourse);
        return updatedCourse;
      }
      async deleteNcaaCoreCourse(id) {
        return this.ncaaCoreCourses.delete(id);
      }
      // Grade Scale Operations
      async getGradeScales() {
        return Array.from(this.gradeScales.values());
      }
      async getGradeScale(id) {
        return this.gradeScales.get(id);
      }
      async getGradeScaleByCountry(country) {
        return Array.from(this.gradeScales.values()).find(
          (scale) => scale.country.toLowerCase() === country.toLowerCase()
        );
      }
      async createGradeScale(scale) {
        const id = this.currentGradeScaleId++;
        const gradeScale = { ...scale, id };
        this.gradeScales.set(id, gradeScale);
        return gradeScale;
      }
      async updateGradeScale(id, data) {
        const scale = this.gradeScales.get(id);
        if (!scale) return void 0;
        const updatedScale = { ...scale, ...data };
        this.gradeScales.set(id, updatedScale);
        return updatedScale;
      }
      async deleteGradeScale(id) {
        return this.gradeScales.delete(id);
      }
      // NCAA Sliding Scale Operations
      async getNcaaSlidingScales() {
        return Array.from(this.ncaaSlidingScales.values());
      }
      async getNcaaSlidingScale(id) {
        return this.ncaaSlidingScales.get(id);
      }
      async getNcaaSlidingScaleByDivision(division) {
        return Array.from(this.ncaaSlidingScales.values()).filter(
          (scale) => scale.division === division
        );
      }
      async createNcaaSlidingScale(scale) {
        const id = this.currentNcaaSlidingScaleId++;
        const slidingScale = { ...scale, id };
        this.ncaaSlidingScales.set(id, slidingScale);
        return slidingScale;
      }
      async updateNcaaSlidingScale(id, data) {
        const scale = this.ncaaSlidingScales.get(id);
        if (!scale) return void 0;
        const updatedScale = { ...scale, ...data };
        this.ncaaSlidingScales.set(id, updatedScale);
        return updatedScale;
      }
      async deleteNcaaSlidingScale(id) {
        return this.ncaaSlidingScales.delete(id);
      }
      async getNcaaSlidingScalesByCoreGpa(coreGpa, division) {
        const divisionScales = await this.getNcaaSlidingScaleByDivision(Number(division));
        return divisionScales.filter((scale) => scale.coreGpa === coreGpa);
      }
      // NCAA Document Operations
      async getNcaaDocuments(userId) {
        return Array.from(this.ncaaDocuments.values()).filter(
          (doc) => doc.userId === userId
        );
      }
      async getNcaaDocument(id) {
        return this.ncaaDocuments.get(id);
      }
      async createNcaaDocument(document) {
        const id = this.currentNcaaDocumentId++;
        const uploadedDate = /* @__PURE__ */ new Date();
        const ncaaDocument = {
          ...document,
          id,
          uploadedDate,
          verifiedDate: null
        };
        this.ncaaDocuments.set(id, ncaaDocument);
        return ncaaDocument;
      }
      async updateNcaaDocument(id, data) {
        const document = this.ncaaDocuments.get(id);
        if (!document) return void 0;
        const updatedDocument = { ...document, ...data };
        this.ncaaDocuments.set(id, updatedDocument);
        return updatedDocument;
      }
      async verifyNcaaDocument(id, verifierId) {
        const document = this.ncaaDocuments.get(id);
        if (!document) return void 0;
        const verifiedDate = /* @__PURE__ */ new Date();
        const updatedDocument = {
          ...document,
          verified: true,
          verifierId,
          verifiedDate
        };
        this.ncaaDocuments.set(id, updatedDocument);
        return updatedDocument;
      }
      async deleteNcaaDocument(id) {
        return this.ncaaDocuments.delete(id);
      }
      // NCAA Registration Operations
      async getNcaaRegistrations(userId) {
        return Array.from(this.ncaaRegistrations.values()).filter(
          (reg) => reg.userId === userId
        );
      }
      async getNcaaRegistration(id) {
        return this.ncaaRegistrations.get(id);
      }
      async getNcaaRegistrationByUserId(userId) {
        const registrations2 = await this.getNcaaRegistrations(userId);
        return registrations2.length > 0 ? registrations2[0] : void 0;
      }
      async createNcaaRegistration(registration) {
        const id = this.currentNcaaRegistrationId++;
        const startedDate = /* @__PURE__ */ new Date();
        const ncaaRegistration2 = {
          ...registration,
          id,
          startedDate,
          completedDate: null,
          status: registration.status || "in_progress"
        };
        this.ncaaRegistrations.set(id, ncaaRegistration2);
        return ncaaRegistration2;
      }
      async updateNcaaRegistration(id, data) {
        const registration = this.ncaaRegistrations.get(id);
        if (!registration) return void 0;
        const updatedRegistration = { ...registration, ...data };
        this.ncaaRegistrations.set(id, updatedRegistration);
        return updatedRegistration;
      }
      async completeNcaaRegistration(id) {
        const registration = this.ncaaRegistrations.get(id);
        if (!registration) return void 0;
        const completedDate = /* @__PURE__ */ new Date();
        const updatedRegistration = {
          ...registration,
          completedDate,
          status: "completed"
        };
        this.ncaaRegistrations.set(id, updatedRegistration);
        return updatedRegistration;
      }
      async deleteNcaaRegistration(id) {
        return this.ncaaRegistrations.delete(id);
      }
      // User Agreement operations
      async getUserAgreement(userId) {
        return Array.from(this.userAgreements.values()).find(
          (agreement) => agreement.userId === userId
        );
      }
      async createUserAgreement(agreement) {
        const id = this.currentUserAgreementId++;
        const now = /* @__PURE__ */ new Date();
        const userAgreement = {
          ...agreement,
          id,
          acceptedAt: now
        };
        this.userAgreements.set(id, userAgreement);
        return userAgreement;
      }
      // NCAA Eligibility Checking Helpers
      async checkEligibilityStatus(userId) {
        const eligibility = await this.getNcaaEligibility(userId);
        if (!eligibility) {
          return {
            isEligible: false,
            meetsGpaRequirement: false,
            meetsTestScoreRequirement: false,
            meetsCourseRequirement: false,
            qualificationPercentage: 0,
            message: "No eligibility record found. Please start the NCAA eligibility process."
          };
        }
        const meetsGpaRequirement = eligibility.gpaMeetsRequirement ?? false;
        const meetsTestScoreRequirement = eligibility.testScoreMeetsRequirement ?? false;
        const meetsCourseRequirement = (eligibility.coreCoursesCompleted ?? 0) >= (eligibility.coreCoursesRequired ?? 16);
        let qualificationPercentage = 0;
        let countedItems = 0;
        if (meetsGpaRequirement) qualificationPercentage += 33.33;
        if (eligibility.gpa !== null) countedItems++;
        if (meetsTestScoreRequirement) qualificationPercentage += 33.33;
        if (eligibility.satScore !== null || eligibility.actScore !== null) countedItems++;
        if (meetsCourseRequirement) qualificationPercentage += 33.34;
        if (eligibility.coreCoursesCompleted !== null) countedItems++;
        if (countedItems > 0) {
          qualificationPercentage = qualificationPercentage * 3 / countedItems;
        }
        qualificationPercentage = Math.min(100, Math.round(qualificationPercentage));
        const isEligible = meetsGpaRequirement && meetsTestScoreRequirement && meetsCourseRequirement;
        let message = "";
        if (isEligible) {
          message = "Congratulations! You meet all NCAA eligibility requirements.";
        } else if (qualificationPercentage > 66) {
          message = "You're almost there! Complete the remaining requirements to become eligible.";
        } else if (qualificationPercentage > 33) {
          message = "You're making progress. Continue working on your eligibility requirements.";
        } else {
          message = "You have several requirements to meet for NCAA eligibility.";
        }
        return {
          isEligible,
          meetsGpaRequirement,
          meetsTestScoreRequirement,
          meetsCourseRequirement,
          qualificationPercentage,
          message
        };
      }
      // Coach Connection operations
      async getCoachConnections(userId, role) {
        if (role === "coach") {
          return Array.from(this.coachConnections.values()).filter(
            (connection2) => connection2.coachId === userId
          );
        } else {
          return Array.from(this.coachConnections.values()).filter(
            (connection2) => connection2.athleteId === userId
          );
        }
      }
      async createCoachConnection(connection2) {
        const id = this.currentCoachConnectionId++;
        const now = /* @__PURE__ */ new Date();
        const coachConnection = {
          ...connection2,
          id,
          connectionDate: now,
          lastContact: now
        };
        this.coachConnections.set(id, coachConnection);
        return coachConnection;
      }
      async updateCoachConnection(id, data) {
        const connection2 = this.coachConnections.get(id);
        if (!connection2) return void 0;
        const updatedConnection = { ...connection2, ...data };
        this.coachConnections.set(id, updatedConnection);
        return updatedConnection;
      }
      // Achievement operations
      async getAchievements(userId) {
        return Array.from(this.achievements.values()).filter(
          (achievement) => achievement.userId === userId
        );
      }
      async createAchievement(achievement) {
        const id = this.currentAchievementId++;
        const now = /* @__PURE__ */ new Date();
        const newAchievement = {
          ...achievement,
          id,
          earnedDate: now
        };
        this.achievements.set(id, newAchievement);
        return newAchievement;
      }
      // Message operations
      async getMessages(userId) {
        return Array.from(this.messages.values()).filter(
          (message) => message.senderId === userId || message.recipientId === userId
        );
      }
      async createMessage(message) {
        const id = this.currentMessageId++;
        const now = /* @__PURE__ */ new Date();
        const newMessage = {
          ...message,
          id,
          createdAt: now,
          isRead: false
        };
        this.messages.set(id, newMessage);
        return newMessage;
      }
      async markMessageAsRead(id) {
        const message = this.messages.get(id);
        if (!message) return void 0;
        const updatedMessage = { ...message, isRead: true };
        this.messages.set(id, updatedMessage);
        return updatedMessage;
      }
      // Admin operations
      async getAllUsers() {
        return Array.from(this.users.values());
      }
      async getAllAthletes() {
        return Array.from(this.users.values()).filter(
          (user) => user.role === "athlete"
        );
      }
      async getAllCoaches() {
        return Array.from(this.users.values()).filter(
          (user) => user.role === "coach"
        );
      }
      async getAllVideos() {
        return Array.from(this.videos.values());
      }
      async getSystemStats() {
        return {
          totalUsers: this.users.size,
          totalVideos: this.videos.size,
          totalAnalyses: this.videoAnalyses.size,
          totalCoachConnections: this.coachConnections.size
        };
      }
      // Skill Tree operations
      async getUserSkills(userId) {
        return Array.from(this.skills.values()).filter(
          (skill) => skill.userId === userId
        );
      }
      async getUserSkillsByCategory(userId, category) {
        return Array.from(this.skills.values()).filter(
          (skill) => skill.userId === userId && skill.skillCategory === category
        );
      }
      async getSkill(id) {
        return this.skills.get(id);
      }
      async createSkill(skill) {
        const id = this.currentSkillId++;
        const now = /* @__PURE__ */ new Date();
        const newSkill = {
          ...skill,
          id,
          updatedAt: now
        };
        this.skills.set(id, newSkill);
        return newSkill;
      }
      async updateSkill(id, data) {
        const skill = this.skills.get(id);
        if (!skill) return void 0;
        const now = /* @__PURE__ */ new Date();
        const updatedSkill = {
          ...skill,
          ...data,
          updatedAt: now
        };
        this.skills.set(id, updatedSkill);
        return updatedSkill;
      }
      // Challenges operations
      async getChallenges() {
        return Array.from(this.challenges.values());
      }
      async getChallengesByCategory(category) {
        return Array.from(this.challenges.values()).filter(
          (challenge) => challenge.category === category
        );
      }
      async getChallenge(id) {
        return this.challenges.get(id);
      }
      async createChallenge(challenge) {
        const id = this.currentChallengeId++;
        const now = /* @__PURE__ */ new Date();
        const newChallenge = {
          ...challenge,
          id,
          createdAt: now
        };
        this.challenges.set(id, newChallenge);
        return newChallenge;
      }
      async getAthleteChallenges(userId) {
        return Array.from(this.athleteChallenges.values()).filter(
          (athleteChallenge) => athleteChallenge.userId === userId
        );
      }
      async getAthleteChallenge(id) {
        return this.athleteChallenges.get(id);
      }
      async createAthleteChallenge(athleteChallenge) {
        const id = this.currentAthleteChallengeId++;
        const now = /* @__PURE__ */ new Date();
        const newAthleteChallenge = {
          ...athleteChallenge,
          id,
          startedAt: now,
          completedAt: null
        };
        this.athleteChallenges.set(id, newAthleteChallenge);
        return newAthleteChallenge;
      }
      async updateAthleteChallenge(id, data) {
        const athleteChallenge = this.athleteChallenges.get(id);
        if (!athleteChallenge) return void 0;
        const updatedAthleteChallenge = {
          ...athleteChallenge,
          ...data
        };
        this.athleteChallenges.set(id, updatedAthleteChallenge);
        return updatedAthleteChallenge;
      }
      // Recovery Tracker operations
      async getRecoveryLogs(userId) {
        return Array.from(this.recoveryLogs.values()).filter((log2) => log2.userId === userId).sort((a, b) => new Date(b.logDate).getTime() - new Date(a.logDate).getTime());
      }
      async getLatestRecoveryLog(userId) {
        const logs = await this.getRecoveryLogs(userId);
        return logs.length > 0 ? logs[0] : void 0;
      }
      async createRecoveryLog(recoveryLog) {
        const id = this.currentRecoveryLogId++;
        const today = /* @__PURE__ */ new Date();
        const newRecoveryLog = {
          ...recoveryLog,
          id,
          logDate: today
        };
        this.recoveryLogs.set(id, newRecoveryLog);
        return newRecoveryLog;
      }
      // Fan Club operations
      async getFanClubFollowers(athleteId) {
        return Array.from(this.fanClubFollowers.values()).filter((follower) => follower.athleteId === athleteId).sort((a, b) => new Date(b.followDate).getTime() - new Date(a.followDate).getTime());
      }
      async getFanClubStats(athleteId) {
        const followers = await this.getFanClubFollowers(athleteId);
        return {
          totalFollowers: followers.length,
          fans: followers.filter((f) => f.followerType === "fan").length,
          recruiters: followers.filter((f) => f.followerType === "recruiter").length,
          family: followers.filter((f) => f.followerType === "family").length,
          friends: followers.filter((f) => f.followerType === "friend").length
        };
      }
      async createFanClubFollower(follower) {
        const id = this.currentFanClubFollowerId++;
        const now = /* @__PURE__ */ new Date();
        const newFollower = {
          ...follower,
          id,
          followDate: now
        };
        this.fanClubFollowers.set(id, newFollower);
        return newFollower;
      }
      // Leaderboard operations
      async getLeaderboardEntries(category) {
        return Array.from(this.leaderboardEntries.values()).filter((entry) => entry.category === category).sort((a, b) => a.rankPosition - b.rankPosition);
      }
      async getUserLeaderboardEntry(userId, category) {
        return Array.from(this.leaderboardEntries.values()).find(
          (entry) => entry.userId === userId && entry.category === category
        );
      }
      async createLeaderboardEntry(entry) {
        const id = this.currentLeaderboardEntryId++;
        const now = /* @__PURE__ */ new Date();
        const newEntry = {
          ...entry,
          id,
          updatedAt: now
        };
        this.leaderboardEntries.set(id, newEntry);
        return newEntry;
      }
      async updateLeaderboardEntry(id, data) {
        const entry = this.leaderboardEntries.get(id);
        if (!entry) return void 0;
        const now = /* @__PURE__ */ new Date();
        const updatedEntry = {
          ...entry,
          ...data,
          updatedAt: now
        };
        this.leaderboardEntries.set(id, updatedEntry);
        return updatedEntry;
      }
      // Blog Post operations
      async getBlogPosts(limit = 20, offset = 0) {
        return Array.from(this.blogPosts.values()).sort((a, b) => new Date(b.publishDate || Date.now()).getTime() - new Date(a.publishDate || Date.now()).getTime()).slice(offset, offset + limit);
      }
      async getFeaturedBlogPosts(limit = 5) {
        return Array.from(this.blogPosts.values()).filter((post) => post.featured).sort((a, b) => new Date(b.publishDate || Date.now()).getTime() - new Date(a.publishDate || Date.now()).getTime()).slice(0, limit);
      }
      async getBlogPostsByCategory(category, limit = 10) {
        return Array.from(this.blogPosts.values()).filter((post) => post.category === category).sort((a, b) => new Date(b.publishDate || Date.now()).getTime() - new Date(a.publishDate || Date.now()).getTime()).slice(0, limit);
      }
      async getBlogPostBySlug(slug) {
        return Array.from(this.blogPosts.values()).find(
          (post) => post.slug === slug
        );
      }
      async getBlogPost(id) {
        return this.blogPosts.get(id);
      }
      async createBlogPost(post) {
        const id = this.currentBlogPostId++;
        const now = /* @__PURE__ */ new Date();
        const newPost = {
          ...post,
          id,
          publishDate: post.publishDate || now
        };
        this.blogPosts.set(id, newPost);
        return newPost;
      }
      async updateBlogPost(id, data) {
        const post = this.blogPosts.get(id);
        if (!post) return void 0;
        const updatedPost = {
          ...post,
          ...data
        };
        this.blogPosts.set(id, updatedPost);
        return updatedPost;
      }
      async deleteBlogPost(id) {
        return this.blogPosts.delete(id);
      }
      // ContentBlock operations
      async getContentBlocks(section) {
        if (section) {
          return Array.from(this.contentBlocks.values()).filter(
            (block) => block.section === section
          );
        }
        return Array.from(this.contentBlocks.values());
      }
      async getContentBlocksByIdentifier(identifier) {
        return Array.from(this.contentBlocks.values()).find(
          (block) => block.identifier === identifier
        );
      }
      async getContentBlock(id) {
        return this.contentBlocks.get(id);
      }
      async createContentBlock(contentBlock) {
        const id = this.currentContentBlockId++;
        const now = /* @__PURE__ */ new Date();
        const newContentBlock = {
          ...contentBlock,
          id,
          lastUpdated: now
        };
        this.contentBlocks.set(id, newContentBlock);
        return newContentBlock;
      }
      async updateContentBlock(id, data) {
        const contentBlock = this.contentBlocks.get(id);
        if (!contentBlock) return void 0;
        const now = /* @__PURE__ */ new Date();
        const updatedContentBlock = {
          ...contentBlock,
          ...data,
          lastUpdated: now
        };
        this.contentBlocks.set(id, updatedContentBlock);
        return updatedContentBlock;
      }
      async deleteContentBlock(id) {
        return this.contentBlocks.delete(id);
      }
      // Featured Athlete operations
      async getFeaturedAthletes(limit = 4) {
        return Array.from(this.featuredAthletes.values()).filter((athlete) => athlete.active).sort((a, b) => new Date(b.featuredDate || Date.now()).getTime() - new Date(a.featuredDate || Date.now()).getTime()).slice(0, limit);
      }
      async getFeaturedAthlete(id) {
        return this.featuredAthletes.get(id);
      }
      async getFeaturedAthleteByUserId(userId) {
        return Array.from(this.featuredAthletes.values()).find(
          (athlete) => athlete.userId === userId
        );
      }
      async createFeaturedAthlete(athlete) {
        const id = this.currentFeaturedAthleteId++;
        const now = /* @__PURE__ */ new Date();
        const newAthlete = {
          ...athlete,
          id,
          featuredDate: athlete.featuredDate || now,
          order: athlete.order || 0,
          active: athlete.active === void 0 ? true : athlete.active
        };
        this.featuredAthletes.set(id, newAthlete);
        return newAthlete;
      }
      async updateFeaturedAthlete(id, data) {
        const athlete = this.featuredAthletes.get(id);
        if (!athlete) return void 0;
        const updatedAthlete = {
          ...athlete,
          ...data
        };
        this.featuredAthletes.set(id, updatedAthlete);
        return updatedAthlete;
      }
      async deactivateFeaturedAthlete(id) {
        const athlete = this.featuredAthletes.get(id);
        if (!athlete) return false;
        athlete.active = false;
        this.featuredAthletes.set(id, athlete);
        return true;
      }
      // Workout Playlist operations
      async getWorkoutPlaylists(userId) {
        return Array.from(this.workoutPlaylists.values()).filter((playlist) => playlist.userId === userId).sort((a, b) => new Date(b.lastUsed || Date.now()).getTime() - new Date(a.lastUsed || Date.now()).getTime());
      }
      async getWorkoutPlaylist(id) {
        return this.workoutPlaylists.get(id);
      }
      async createWorkoutPlaylist(playlist) {
        const id = this.currentWorkoutPlaylistId++;
        const now = /* @__PURE__ */ new Date();
        const newPlaylist = {
          ...playlist,
          id,
          createdAt: now,
          lastUsed: now,
          timesUsed: 0
        };
        this.workoutPlaylists.set(id, newPlaylist);
        return newPlaylist;
      }
      async updateWorkoutPlaylist(id, data) {
        const playlist = this.workoutPlaylists.get(id);
        if (!playlist) return void 0;
        const updatedPlaylist = { ...playlist, ...data };
        this.workoutPlaylists.set(id, updatedPlaylist);
        return updatedPlaylist;
      }
      async deleteWorkoutPlaylist(id) {
        Array.from(this.workoutExercises.values()).filter((exercise) => exercise.playlistId === id).forEach((exercise) => this.workoutExercises.delete(exercise.id));
        return this.workoutPlaylists.delete(id);
      }
      async incrementPlaylistUsage(id) {
        const playlist = this.workoutPlaylists.get(id);
        if (!playlist) return void 0;
        const now = /* @__PURE__ */ new Date();
        const updatedPlaylist = {
          ...playlist,
          lastUsed: now,
          timesUsed: (playlist.timesUsed || 0) + 1
        };
        this.workoutPlaylists.set(id, updatedPlaylist);
        return updatedPlaylist;
      }
      async getWorkoutExercises(playlistId) {
        return Array.from(this.workoutExercises.values()).filter((exercise) => exercise.playlistId === playlistId).sort((a, b) => a.orderIndex - b.orderIndex);
      }
      async createWorkoutExercise(exercise) {
        const id = this.currentWorkoutExerciseId++;
        const newExercise = {
          ...exercise,
          id
        };
        this.workoutExercises.set(id, newExercise);
        return newExercise;
      }
      async updateWorkoutExercise(id, data) {
        const exercise = this.workoutExercises.get(id);
        if (!exercise) return void 0;
        const updatedExercise = { ...exercise, ...data };
        this.workoutExercises.set(id, updatedExercise);
        return updatedExercise;
      }
      async deleteWorkoutExercise(id) {
        return this.workoutExercises.delete(id);
      }
      async getPublicWorkoutPlaylists(workoutType, intensityLevel) {
        let playlists = Array.from(this.workoutPlaylists.values()).filter((playlist) => playlist.isPublic);
        if (workoutType) {
          playlists = playlists.filter((playlist) => playlist.workoutType === workoutType);
        }
        if (intensityLevel) {
          playlists = playlists.filter((playlist) => playlist.intensityLevel === intensityLevel);
        }
        return playlists.sort(
          (a, b) => (b.timesUsed || 0) - (a.timesUsed || 0)
          // Sort by popularity
        );
      }
      async generateAIWorkoutPlaylist(userId, preferences) {
        const now = /* @__PURE__ */ new Date();
        const id = this.currentWorkoutPlaylistId++;
        const playlist = {
          id,
          userId,
          name: `AI Generated ${preferences.workoutType} Workout (${preferences.intensityLevel})`,
          description: `A ${preferences.intensityLevel} ${preferences.workoutType} workout targeting ${preferences.targets.join(", ")}`,
          workoutType: preferences.workoutType,
          intensityLevel: preferences.intensityLevel,
          durationMinutes: preferences.duration,
          targetAreas: preferences.targets,
          isPublic: false,
          createdAt: now,
          lastUsed: now,
          timesUsed: 0
        };
        this.workoutPlaylists.set(id, playlist);
        const exercises = [];
        if (preferences.workoutType === "Strength") {
          if (preferences.targets.includes("Upper Body")) {
            exercises.push({
              playlistId: id,
              name: "Push-ups",
              description: "Standard push-ups with proper form",
              durationSeconds: 60,
              repetitions: 15,
              sets: 3,
              restSeconds: 30,
              orderIndex: 1
            });
            exercises.push({
              playlistId: id,
              name: "Pull-ups",
              description: "Pull-ups with proper form",
              durationSeconds: 60,
              repetitions: 10,
              sets: 3,
              restSeconds: 45,
              orderIndex: 2
            });
          }
          if (preferences.targets.includes("Lower Body")) {
            exercises.push({
              playlistId: id,
              name: "Squats",
              description: "Bodyweight squats with proper form",
              durationSeconds: 60,
              repetitions: 20,
              sets: 3,
              restSeconds: 30,
              orderIndex: 3
            });
            exercises.push({
              playlistId: id,
              name: "Lunges",
              description: "Alternating lunges with proper form",
              durationSeconds: 60,
              repetitions: 12,
              sets: 3,
              restSeconds: 30,
              orderIndex: 4
            });
          }
        } else if (preferences.workoutType === "Cardio") {
          exercises.push({
            playlistId: id,
            name: "Jumping Jacks",
            description: "Standard jumping jacks at a moderate pace",
            durationSeconds: 60,
            repetitions: null,
            sets: 3,
            restSeconds: 15,
            orderIndex: 1
          });
          exercises.push({
            playlistId: id,
            name: "Mountain Climbers",
            description: "Mountain climbers at a quick pace",
            durationSeconds: 45,
            repetitions: null,
            sets: 3,
            restSeconds: 15,
            orderIndex: 2
          });
        } else if (preferences.workoutType === "Flexibility") {
          exercises.push({
            playlistId: id,
            name: "Standing Hamstring Stretch",
            description: "Gentle hamstring stretch while standing",
            durationSeconds: 30,
            repetitions: null,
            sets: 3,
            restSeconds: 10,
            orderIndex: 1
          });
          exercises.push({
            playlistId: id,
            name: "Hip Flexor Stretch",
            description: "Gentle hip flexor stretch in lunge position",
            durationSeconds: 30,
            repetitions: null,
            sets: 3,
            restSeconds: 10,
            orderIndex: 2
          });
        }
        for (const exercise of exercises) {
          await this.createWorkoutExercise(exercise);
        }
        return playlist;
      }
      // Film Comparison operations
      async getFilmComparisons(userId) {
        return Array.from(this.filmComparisons.values()).filter(
          (comparison) => comparison.userId === userId
        );
      }
      async getFilmComparison(id) {
        return this.filmComparisons.get(id);
      }
      async createFilmComparison(comparison) {
        const id = this.currentFilmComparisonId++;
        const now = /* @__PURE__ */ new Date();
        const filmComparison = {
          ...comparison,
          id,
          createdAt: now,
          updatedAt: now
        };
        this.filmComparisons.set(id, filmComparison);
        return filmComparison;
      }
      async updateFilmComparison(id, data) {
        const comparison = this.filmComparisons.get(id);
        if (!comparison) return void 0;
        const now = /* @__PURE__ */ new Date();
        const updatedComparison = {
          ...comparison,
          ...data,
          updatedAt: now
        };
        this.filmComparisons.set(id, updatedComparison);
        return updatedComparison;
      }
      async deleteFilmComparison(id) {
        return this.filmComparisons.delete(id);
      }
      async getComparisonVideos(comparisonId) {
        return Array.from(this.comparisonVideos.values()).filter(
          (video) => video.comparisonId === comparisonId
        );
      }
      async getComparisonVideo(id) {
        return this.comparisonVideos.get(id);
      }
      async createComparisonVideo(video) {
        const id = this.currentComparisonVideoId++;
        const now = /* @__PURE__ */ new Date();
        const comparisonVideo = {
          ...video,
          id,
          uploadDate: now
        };
        this.comparisonVideos.set(id, comparisonVideo);
        return comparisonVideo;
      }
      async updateComparisonVideo(id, data) {
        const video = this.comparisonVideos.get(id);
        if (!video) return void 0;
        const updatedVideo = {
          ...video,
          ...data
        };
        this.comparisonVideos.set(id, updatedVideo);
        return updatedVideo;
      }
      async deleteComparisonVideo(id) {
        return this.comparisonVideos.delete(id);
      }
      async getComparisonAnalysis(comparisonId) {
        return Array.from(this.comparisonAnalyses.values()).find(
          (analysis) => analysis.comparisonId === comparisonId
        );
      }
      async createComparisonAnalysis(analysis) {
        const id = this.currentComparisonAnalysisId++;
        const now = /* @__PURE__ */ new Date();
        const comparisonAnalysis = {
          ...analysis,
          id,
          analysisDate: now
        };
        this.comparisonAnalyses.set(id, comparisonAnalysis);
        return comparisonAnalysis;
      }
      async updateComparisonAnalysis(id, data) {
        const analysis = this.comparisonAnalyses.get(id);
        if (!analysis) return void 0;
        const updatedAnalysis = {
          ...analysis,
          ...data
        };
        this.comparisonAnalyses.set(id, updatedAnalysis);
        return updatedAnalysis;
      }
      // NextUp Spotlight operations
      async getSpotlightProfiles(limit, offset) {
        let profiles = Array.from(this.spotlightProfiles.values());
        if (offset) {
          profiles = profiles.slice(offset);
        }
        if (limit) {
          profiles = profiles.slice(0, limit);
        }
        return profiles;
      }
      async getFeaturedSpotlightProfiles(limit) {
        let profiles = Array.from(this.spotlightProfiles.values()).filter((profile) => profile.featured).sort((a, b) => b.views - a.views);
        if (limit) {
          profiles = profiles.slice(0, limit);
        }
        return profiles;
      }
      async getSpotlightProfilesByCategory(category, limit) {
        let profiles = Array.from(this.spotlightProfiles.values()).filter((profile) => profile.sportCategory === category).sort((a, b) => b.views - a.views);
        if (limit) {
          profiles = profiles.slice(0, limit);
        }
        return profiles;
      }
      async getSpotlightProfile(id) {
        return this.spotlightProfiles.get(id);
      }
      async getSpotlightProfileByUserId(userId) {
        return Array.from(this.spotlightProfiles.values()).find(
          (profile) => profile.userId === userId
        );
      }
      async createSpotlightProfile(profile) {
        const id = this.currentSpotlightProfileId++;
        const now = /* @__PURE__ */ new Date();
        const spotlightProfile = {
          ...profile,
          id,
          createdAt: now,
          updatedAt: now,
          views: 0,
          likes: 0,
          featured: false
        };
        this.spotlightProfiles.set(id, spotlightProfile);
        return spotlightProfile;
      }
      async updateSpotlightProfile(id, data) {
        const profile = this.spotlightProfiles.get(id);
        if (!profile) return void 0;
        const now = /* @__PURE__ */ new Date();
        const updatedProfile = {
          ...profile,
          ...data,
          updatedAt: now
        };
        this.spotlightProfiles.set(id, updatedProfile);
        return updatedProfile;
      }
      async deleteSpotlightProfile(id) {
        return this.spotlightProfiles.delete(id);
      }
      async incrementSpotlightViews(id) {
        const profile = this.spotlightProfiles.get(id);
        if (!profile) return void 0;
        const updatedProfile = {
          ...profile,
          views: profile.views + 1
        };
        this.spotlightProfiles.set(id, updatedProfile);
        return updatedProfile;
      }
      async likeSpotlightProfile(id) {
        const profile = this.spotlightProfiles.get(id);
        if (!profile) return void 0;
        const updatedProfile = {
          ...profile,
          likes: profile.likes + 1
        };
        this.spotlightProfiles.set(id, updatedProfile);
        return updatedProfile;
      }
      // MyPlayer XP System operations
      async getPlayerProgress(userId) {
        return Array.from(this.playerProgress.values()).find(
          (progress) => progress.userId === userId
        );
      }
      async createPlayerProgress(progress) {
        const id = this.currentPlayerProgressId++;
        const now = /* @__PURE__ */ new Date();
        const playerProgress2 = {
          ...progress,
          id,
          createdAt: now,
          updatedAt: now
        };
        this.playerProgress.set(id, playerProgress2);
        return playerProgress2;
      }
      async updatePlayerProgress(userId, data) {
        const progress = Array.from(this.playerProgress.values()).find(
          (progress2) => progress2.userId === userId
        );
        if (!progress) return void 0;
        const now = /* @__PURE__ */ new Date();
        const updatedProgress = {
          ...progress,
          ...data,
          updatedAt: now
        };
        this.playerProgress.set(progress.id, updatedProgress);
        return updatedProgress;
      }
      async addXpToPlayer(userId, amount, type, description, sourceId) {
        let progress = await this.getPlayerProgress(userId);
        if (!progress) {
          progress = await this.createPlayerProgress({
            userId,
            level: 1,
            totalXp: 0,
            currentLevelXp: 0,
            nextLevelXp: 100,
            streak: 0
          });
        }
        const newTotalXp = progress.totalXp + amount;
        const newCurrentLevelXp = progress.currentLevelXp + amount;
        let leveledUp = false;
        let newLevel = progress.level;
        let newNextLevelXp = progress.nextLevelXp;
        let remainingXp = 0;
        if (newCurrentLevelXp >= progress.nextLevelXp) {
          leveledUp = true;
          newLevel = progress.level + 1;
          remainingXp = newCurrentLevelXp - progress.nextLevelXp;
          newNextLevelXp = Math.round(progress.nextLevelXp * 1.5);
        }
        const updatedProgress = await this.updatePlayerProgress(userId, {
          totalXp: newTotalXp,
          currentLevelXp: leveledUp ? remainingXp : newCurrentLevelXp,
          level: newLevel,
          nextLevelXp: leveledUp ? newNextLevelXp : progress.nextLevelXp
        });
        const transaction = await this.createXpTransaction({
          userId,
          amount,
          type,
          description,
          sourceId,
          awarded: /* @__PURE__ */ new Date()
        });
        return {
          progress: updatedProgress,
          transaction,
          leveledUp
        };
      }
      async getXpTransactions(userId, limit) {
        let transactions = Array.from(this.xpTransactions.values()).filter((tx) => tx.userId === userId).sort((a, b) => new Date(b.awarded).getTime() - new Date(a.awarded).getTime());
        if (limit) {
          transactions = transactions.slice(0, limit);
        }
        return transactions;
      }
      async createXpTransaction(transaction) {
        const id = this.currentXpTransactionId++;
        const xpTransaction = {
          ...transaction,
          id
        };
        this.xpTransactions.set(id, xpTransaction);
        return xpTransaction;
      }
      async getPlayerBadges(userId) {
        return Array.from(this.playerBadges.values()).filter(
          (badge) => badge.userId === userId
        );
      }
      async getPlayerBadgesByCategory(userId, category) {
        return Array.from(this.playerBadges.values()).filter(
          (badge) => badge.userId === userId && badge.category === category
        );
      }
      async createPlayerBadge(badge) {
        const id = this.currentPlayerBadgeId++;
        const now = /* @__PURE__ */ new Date();
        const playerBadge = {
          ...badge,
          id,
          earnedAt: now
        };
        this.playerBadges.set(id, playerBadge);
        return playerBadge;
      }
      async updatePlayerBadge(id, data) {
        const badge = this.playerBadges.get(id);
        if (!badge) return void 0;
        const updatedBadge = {
          ...badge,
          ...data
        };
        this.playerBadges.set(id, updatedBadge);
        return updatedBadge;
      }
      // MyPlayer Workout Verification operations
      async getWorkoutVerifications(userId) {
        return Array.from(this.workoutVerifications.values()).filter(
          (verification) => verification.userId === userId
        );
      }
      async getPendingWorkoutVerifications() {
        return Array.from(this.workoutVerifications.values()).filter(
          (verification) => verification.status === "pending"
        );
      }
      async getWorkoutVerification(id) {
        return this.workoutVerifications.get(id);
      }
      async createWorkoutVerification(verification) {
        const id = this.currentWorkoutVerificationId++;
        const now = /* @__PURE__ */ new Date();
        const workoutVerification = {
          ...verification,
          id,
          submittedAt: now,
          status: "pending",
          verifiedAt: null,
          verifierId: null,
          verifierNotes: null
        };
        this.workoutVerifications.set(id, workoutVerification);
        return workoutVerification;
      }
      async updateWorkoutVerification(id, data) {
        const verification = this.workoutVerifications.get(id);
        if (!verification) return void 0;
        const updatedVerification = {
          ...verification,
          ...data
        };
        this.workoutVerifications.set(id, updatedVerification);
        return updatedVerification;
      }
      async verifyWorkout(id, verifierId, status, notes) {
        const verification = this.workoutVerifications.get(id);
        if (!verification) return void 0;
        const now = /* @__PURE__ */ new Date();
        const updatedVerification = {
          ...verification,
          status,
          verifierId,
          verifierNotes: notes || null,
          verifiedAt: now
        };
        this.workoutVerifications.set(id, updatedVerification);
        if (status === "approved") {
          await this.addXpToPlayer(
            verification.userId,
            50,
            "workout_verification",
            `Workout "${verification.workoutTitle}" verified`,
            String(id)
          );
        }
        return updatedVerification;
      }
      async getWorkoutVerificationCheckpoints(verificationId) {
        return Array.from(this.workoutVerificationCheckpoints.values()).filter(
          (checkpoint) => checkpoint.verificationId === verificationId
        );
      }
      async createWorkoutVerificationCheckpoint(checkpoint) {
        const id = this.currentWorkoutVerificationCheckpointId++;
        const workoutVerificationCheckpoint = {
          ...checkpoint,
          id
        };
        this.workoutVerificationCheckpoints.set(id, workoutVerificationCheckpoint);
        return workoutVerificationCheckpoint;
      }
      async updateWorkoutVerificationCheckpoint(id, data) {
        const checkpoint = this.workoutVerificationCheckpoints.get(id);
        if (!checkpoint) return void 0;
        const updatedCheckpoint = {
          ...checkpoint,
          ...data
        };
        this.workoutVerificationCheckpoints.set(id, updatedCheckpoint);
        return updatedCheckpoint;
      }
      // MyPlayer UI Weight Room operations
      async getWeightRoomEquipment(category) {
        let equipment = Array.from(this.weightRoomEquipment.values());
        if (category) {
          equipment = equipment.filter(
            (item) => item.category === category
          );
        }
        return equipment;
      }
      async getWeightRoomEquipmentById(id) {
        return this.weightRoomEquipment.get(id);
      }
      async createWeightRoomEquipment(equipment) {
        const id = this.currentWeightRoomEquipmentId++;
        const weightRoomEquipment2 = {
          ...equipment,
          id
        };
        this.weightRoomEquipment.set(id, weightRoomEquipment2);
        return weightRoomEquipment2;
      }
      async updateWeightRoomEquipment(id, data) {
        const equipment = this.weightRoomEquipment.get(id);
        if (!equipment) return void 0;
        const updatedEquipment = {
          ...equipment,
          ...data
        };
        this.weightRoomEquipment.set(id, updatedEquipment);
        return updatedEquipment;
      }
      async getPlayerEquipment(userId) {
        return Array.from(this.playerEquipment.values()).filter(
          (equipment) => equipment.userId === userId
        );
      }
      async getPlayerEquipmentById(id) {
        return this.playerEquipment.get(id);
      }
      async createPlayerEquipment(equipment) {
        const id = this.currentPlayerEquipmentId++;
        const now = /* @__PURE__ */ new Date();
        const playerEquipment2 = {
          ...equipment,
          id,
          acquiredDate: now,
          timesUsed: 0,
          lastUsed: null
        };
        this.playerEquipment.set(id, playerEquipment2);
        return playerEquipment2;
      }
      async updatePlayerEquipment(id, data) {
        const equipment = this.playerEquipment.get(id);
        if (!equipment) return void 0;
        const updatedEquipment = {
          ...equipment,
          ...data
        };
        this.playerEquipment.set(id, updatedEquipment);
        return updatedEquipment;
      }
      async incrementEquipmentUsage(id) {
        const equipment = this.playerEquipment.get(id);
        if (!equipment) return void 0;
        const now = /* @__PURE__ */ new Date();
        const updatedEquipment = {
          ...equipment,
          timesUsed: (equipment.timesUsed || 0) + 1,
          lastUsed: now
        };
        this.playerEquipment.set(id, updatedEquipment);
        return updatedEquipment;
      }
      // Athlete Star Profile operations
      async getAthleteStarProfiles(filters) {
        const profiles = Array.from(this.athleteStarProfiles.values());
        if (!filters) {
          return profiles;
        }
        return profiles.filter((profile) => {
          if (filters.sport && profile.sport !== filters.sport) {
            return false;
          }
          if (filters.position && profile.position !== filters.position) {
            return false;
          }
          if (filters.starLevel && profile.starLevel !== filters.starLevel) {
            return false;
          }
          return true;
        });
      }
      async getAthleteStarProfile(id) {
        return this.athleteStarProfiles.get(id);
      }
      async createAthleteStarProfile(profile) {
        const id = this.currentAthleteStarProfileId++;
        const now = /* @__PURE__ */ new Date();
        const newProfile = {
          ...profile,
          id,
          createdAt: now,
          updatedAt: now
        };
        this.athleteStarProfiles.set(id, newProfile);
        return newProfile;
      }
      // Video Highlight operations
      videoHighlights = /* @__PURE__ */ new Map();
      currentVideoHighlightId = 1;
      // Highlight Generator Config operations
      highlightGeneratorConfigs = /* @__PURE__ */ new Map();
      currentHighlightGeneratorConfigId = 1;
      async getVideoHighlights(videoId) {
        const highlights = [];
        for (const highlight of this.videoHighlights.values()) {
          if (highlight.videoId === videoId) {
            highlights.push(highlight);
          }
        }
        return highlights.sort(
          (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
        );
      }
      async getVideoHighlight(id) {
        return this.videoHighlights.get(id);
      }
      async createVideoHighlight(highlight) {
        const now = /* @__PURE__ */ new Date();
        const newHighlight = {
          id: this.currentVideoHighlightId++,
          ...highlight,
          createdAt: now,
          views: 0,
          likes: 0,
          featured: false,
          aiGenerated: highlight.aiGenerated || false
        };
        this.videoHighlights.set(newHighlight.id, newHighlight);
        return newHighlight;
      }
      async updateVideoHighlight(id, data) {
        const highlight = this.videoHighlights.get(id);
        if (!highlight) return void 0;
        const updatedHighlight = {
          ...highlight,
          ...data
        };
        this.videoHighlights.set(id, updatedHighlight);
        return updatedHighlight;
      }
      async deleteVideoHighlight(id) {
        return this.videoHighlights.delete(id);
      }
      async getFeaturedVideoHighlights(limit = 10) {
        const highlights = [];
        for (const highlight of this.videoHighlights.values()) {
          if (highlight.featured) {
            highlights.push(highlight);
          }
        }
        return highlights.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()).slice(0, limit);
      }
      async generateVideoHighlight(videoId, options) {
        const video = await this.getVideo(videoId);
        if (!video) {
          throw new Error("Video not found");
        }
        const now = /* @__PURE__ */ new Date();
        const newHighlight = {
          id: this.currentVideoHighlightId++,
          videoId,
          title: options.title,
          description: options.description || null,
          startTime: options.startTime,
          endTime: options.endTime,
          duration: options.endTime - options.startTime,
          userId: options.userId,
          createdAt: now,
          aiGenerated: options.aiGenerated || false,
          featured: false,
          views: 0,
          likes: 0
        };
        this.videoHighlights.set(newHighlight.id, newHighlight);
        return newHighlight;
      }
      // Highlight Generator Config operations
      async getHighlightGeneratorConfigs() {
        return Array.from(this.highlightGeneratorConfigs.values());
      }
      async getHighlightGeneratorConfigsBySport(sportType) {
        const configs = [];
        for (const config of this.highlightGeneratorConfigs.values()) {
          if (config.sportType === sportType) {
            configs.push(config);
          }
        }
        return configs;
      }
      async getHighlightGeneratorConfig(id) {
        return this.highlightGeneratorConfigs.get(id);
      }
      async createHighlightGeneratorConfig(config) {
        const id = this.currentHighlightGeneratorConfigId++;
        const now = /* @__PURE__ */ new Date();
        const newConfig = {
          ...config,
          id,
          createdAt: now,
          lastRun: null
        };
        this.highlightGeneratorConfigs.set(id, newConfig);
        return newConfig;
      }
      async updateHighlightGeneratorConfig(id, data) {
        const config = this.highlightGeneratorConfigs.get(id);
        if (!config) return void 0;
        const updatedConfig = {
          ...config,
          ...data
        };
        this.highlightGeneratorConfigs.set(id, updatedConfig);
        return updatedConfig;
      }
      async deleteHighlightGeneratorConfig(id) {
        return this.highlightGeneratorConfigs.delete(id);
      }
      async getActiveHighlightGeneratorConfigs() {
        const configs = [];
        for (const config of this.highlightGeneratorConfigs.values()) {
          if (config.active) {
            configs.push(config);
          }
        }
        return configs;
      }
      // API Key operations
      async getApiKey(keyType) {
        return this.apiKeys.get(keyType);
      }
      async getAllApiKeys() {
        return Array.from(this.apiKeys.values());
      }
      async getAllActiveApiKeys() {
        return Array.from(this.apiKeys.values()).filter(
          (key) => key.isActive === true
        );
      }
      async getApiKeyStatus() {
        const keyTypes = ["openai", "stripe", "sendgrid", "twilio", "google", "aws", "active"];
        const result = {};
        for (const keyType of keyTypes) {
          result[keyType] = this.apiKeys.has(keyType);
        }
        return result;
      }
      async saveApiKey(key) {
        const now = /* @__PURE__ */ new Date();
        const newApiKey = {
          id: 1,
          // ID doesn't matter for apiKeys since we use keyType as the key
          keyType: key.keyType,
          keyValue: key.keyValue,
          addedAt: now,
          lastUsed: null,
          isActive: key.isActive ?? true
        };
        this.apiKeys.set(key.keyType, newApiKey);
        if (key.keyType === "openai" && process.env) {
          process.env.OPENAI_API_KEY = key.keyValue;
        }
        return newApiKey;
      }
      async updateApiKey(keyType, data) {
        const existingKey = this.apiKeys.get(keyType);
        if (!existingKey) {
          return void 0;
        }
        const updatedKey = {
          ...existingKey,
          ...data,
          lastUsed: data.lastUsed || existingKey.lastUsed
        };
        this.apiKeys.set(keyType, updatedKey);
        if (keyType === "openai" && data.keyValue && process.env) {
          process.env.OPENAI_API_KEY = data.keyValue;
        }
        return updatedKey;
      }
      async deleteApiKey(keyType) {
        return this.apiKeys.delete(keyType);
      }
      // Method to seed some initial data for development
      seedInitialData() {
        const athleteUser = {
          id: this.currentUserId++,
          username: "alexjohnson",
          password: "password123",
          // In a real app, this would be hashed
          email: "alex@example.com",
          name: "Alex Johnson",
          role: "athlete",
          profileImage: "https://images.unsplash.com/photo-1628157588553-5eeea00af15c?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80",
          bio: "High school student athlete looking to compete at the college level.",
          createdAt: /* @__PURE__ */ new Date()
        };
        this.users.set(athleteUser.id, athleteUser);
        const coachUser1 = {
          id: this.currentUserId++,
          username: "coachwilliams",
          password: "coachpass123",
          email: "williams@stateuniversity.edu",
          name: "Coach Williams",
          role: "coach",
          profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80",
          bio: "Basketball coach at State University with 15 years of experience.",
          createdAt: /* @__PURE__ */ new Date()
        };
        this.users.set(coachUser1.id, coachUser1);
        const coachUser2 = {
          id: this.currentUserId++,
          username: "coachmartinez",
          password: "coachpass456",
          email: "martinez@centralcollege.edu",
          name: "Coach Martinez",
          role: "coach",
          profileImage: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80",
          bio: "Volleyball coach at Central College, specializing in developing high school talent.",
          createdAt: /* @__PURE__ */ new Date()
        };
        this.users.set(coachUser2.id, coachUser2);
        const adminUser = {
          id: this.currentUserId++,
          username: "admin",
          password: "adminpass123",
          email: "admin@goforit.com",
          name: "Admin User",
          role: "admin",
          createdAt: /* @__PURE__ */ new Date()
        };
        this.users.set(adminUser.id, adminUser);
        const athleteProfile = {
          id: this.currentAthleteProfileId++,
          userId: athleteUser.id,
          height: 188,
          // 6'2" in cm
          weight: 82,
          // 180 lbs in kg
          age: 17,
          school: "Washington High School",
          graduationYear: 2024,
          sportsInterest: ["basketball", "volleyball", "track"],
          motionScore: 65,
          profileCompletionPercentage: 50
        };
        this.athleteProfiles.set(athleteProfile.id, athleteProfile);
        const coachProfile1 = {
          id: this.currentCoachProfileId++,
          userId: coachUser1.id,
          institution: "State University",
          sports: ["basketball"],
          level: "college",
          experience: 15,
          achievements: "3 conference championships, 2 NCAA tournament appearances"
        };
        this.coachProfiles.set(coachProfile1.id, coachProfile1);
        const coachProfile2 = {
          id: this.currentCoachProfileId++,
          userId: coachUser2.id,
          institution: "Central College",
          sports: ["volleyball"],
          level: "college",
          experience: 8,
          achievements: "Regional championship, developed 5 D1 athletes"
        };
        this.coachProfiles.set(coachProfile2.id, coachProfile2);
        const sampleVideo = {
          id: this.currentVideoId++,
          userId: athleteUser.id,
          title: "Basketball Jump Shot",
          description: "My jump shot form from practice yesterday",
          filePath: "/uploads/videos/jumpshotvideo.mp4",
          uploadDate: new Date(2023, 4, 12),
          // May 12, 2023
          analyzed: true,
          sportType: "basketball",
          thumbnailPath: "https://images.unsplash.com/photo-1546519638-68e109498ffc?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
        };
        this.videos.set(sampleVideo.id, sampleVideo);
        const sampleAnalysis = {
          id: this.currentVideoAnalysisId++,
          videoId: sampleVideo.id,
          analysisDate: new Date(2023, 4, 12),
          motionData: {
            elbowAlignment: 85,
            releasePoint: 72,
            followThrough: 55,
            balance: 90,
            keypoints: [
              { x: 0.42, y: 0.35, confidence: 0.95, name: "elbow" },
              { x: 0.52, y: 0.45, confidence: 0.9, name: "wrist" },
              { x: 0.48, y: 0.65, confidence: 0.85, name: "knee" }
            ]
          },
          overallScore: 75,
          feedback: "Good elbow alignment and balance. Work on follow through.",
          improvementTips: [
            "Maintain follow through position longer",
            "Keep your shooting elbow tucked in more consistently",
            "Work on consistent release point"
          ],
          keyFrameTimestamps: [2.4, 3.1, 4.5]
        };
        this.videoAnalyses.set(sampleAnalysis.id, sampleAnalysis);
        const basketballRecommendation = {
          id: this.currentSportRecommendationId++,
          userId: athleteUser.id,
          sport: "Basketball",
          matchPercentage: 92,
          positionRecommendation: "Guard",
          potentialLevel: "NCAA Div II Potential",
          reasonForMatch: "Great match for your height and vertical jumping ability.",
          recommendationDate: /* @__PURE__ */ new Date()
        };
        this.sportRecommendations.set(basketballRecommendation.id, basketballRecommendation);
        const volleyballRecommendation = {
          id: this.currentSportRecommendationId++,
          userId: athleteUser.id,
          sport: "Volleyball",
          matchPercentage: 85,
          positionRecommendation: "Outside Hitter",
          potentialLevel: "Club Level Potential",
          reasonForMatch: "Your jumping and arm extension are perfect for volleyball.",
          recommendationDate: /* @__PURE__ */ new Date()
        };
        this.sportRecommendations.set(volleyballRecommendation.id, volleyballRecommendation);
        const trackRecommendation = {
          id: this.currentSportRecommendationId++,
          userId: athleteUser.id,
          sport: "Track & Field",
          matchPercentage: 78,
          positionRecommendation: "Sprinter",
          potentialLevel: "NCAA Div I Potential",
          reasonForMatch: "Your stride length and acceleration show potential.",
          recommendationDate: /* @__PURE__ */ new Date()
        };
        this.sportRecommendations.set(trackRecommendation.id, trackRecommendation);
        const ncaaEligibility2 = {
          id: this.currentNcaaEligibilityId++,
          userId: athleteUser.id,
          coreCoursesCompleted: 12,
          coreCoursesRequired: 16,
          gpa: 3.5,
          gpaMeetsRequirement: true,
          testScores: "1200 SAT",
          testScoresMeetRequirement: true,
          amateurismStatus: "incomplete",
          overallEligibilityStatus: "partial",
          lastUpdated: /* @__PURE__ */ new Date()
        };
        this.ncaaEligibility.set(ncaaEligibility2.id, ncaaEligibility2);
        const connection1 = {
          id: this.currentCoachConnectionId++,
          coachId: coachUser1.id,
          athleteId: athleteUser.id,
          connectionStatus: "accepted",
          connectionDate: new Date(2023, 3, 15),
          // April 15, 2023
          notes: "Interested in your jump shot technique. Would like to see more training videos.",
          lastContact: /* @__PURE__ */ new Date()
        };
        this.coachConnections.set(connection1.id, connection1);
        const connection2 = {
          id: this.currentCoachConnectionId++,
          coachId: coachUser2.id,
          athleteId: athleteUser.id,
          connectionStatus: "pending",
          connectionDate: new Date(2023, 5, 1),
          // June 1, 2023
          notes: "Your vertical leap is impressive. Let's discuss your volleyball experience.",
          lastContact: /* @__PURE__ */ new Date()
        };
        this.coachConnections.set(connection2.id, connection2);
        const achievement1 = {
          id: this.currentAchievementId++,
          userId: athleteUser.id,
          title: "First Video Analysis",
          description: "Completed your first video motion analysis",
          achievementType: "video",
          earnedDate: new Date(2023, 4, 12),
          iconType: "trophy"
        };
        this.achievements.set(achievement1.id, achievement1);
        const achievement2 = {
          id: this.currentAchievementId++,
          userId: athleteUser.id,
          title: "Profile 50% Complete",
          description: "Reached 50% completion on your athlete profile",
          achievementType: "profile",
          earnedDate: new Date(2023, 4, 20),
          iconType: "profile"
        };
        this.achievements.set(achievement2.id, achievement2);
        const achievement3 = {
          id: this.currentAchievementId++,
          userId: athleteUser.id,
          title: "Connected with Coach",
          description: "Made your first connection with a college coach",
          achievementType: "connection",
          earnedDate: new Date(2023, 4, 25),
          iconType: "handshake"
        };
        this.achievements.set(achievement3.id, achievement3);
        const achievement4 = {
          id: this.currentAchievementId++,
          userId: athleteUser.id,
          title: "NCAA GPA Eligible",
          description: "Achieved the minimum GPA required for NCAA eligibility",
          achievementType: "ncaa",
          earnedDate: new Date(2023, 5, 10),
          iconType: "certificate"
        };
        this.achievements.set(achievement4.id, achievement4);
        const jumpingSkill = {
          id: this.currentSkillId++,
          userId: athleteUser.id,
          skillName: "Vertical Jump",
          skillCategory: "athletic",
          currentLevel: 7,
          maxLevel: 10,
          description: "Ability to jump vertically with power and control",
          xpPoints: 850,
          xpToNextLevel: 1e3,
          updatedAt: new Date(2023, 5, 15)
        };
        this.skills.set(jumpingSkill.id, jumpingSkill);
        const shootingSkill = {
          id: this.currentSkillId++,
          userId: athleteUser.id,
          skillName: "Jump Shot",
          skillCategory: "basketball",
          currentLevel: 6,
          maxLevel: 10,
          description: "Basketball jump shot form and accuracy",
          xpPoints: 750,
          xpToNextLevel: 1e3,
          updatedAt: new Date(2023, 5, 15)
        };
        this.skills.set(shootingSkill.id, shootingSkill);
        const speedSkill = {
          id: this.currentSkillId++,
          userId: athleteUser.id,
          skillName: "Sprint Speed",
          skillCategory: "athletic",
          currentLevel: 8,
          maxLevel: 10,
          description: "Speed in short distance sprints",
          xpPoints: 900,
          xpToNextLevel: 1e3,
          updatedAt: new Date(2023, 5, 15)
        };
        this.skills.set(speedSkill.id, speedSkill);
        const conditioningChallenge = {
          id: this.currentChallengeId++,
          title: "Conditioning Challenge",
          description: "Complete 10 suicides under 3 minutes",
          difficulty: "intermediate",
          category: "conditioning",
          pointsAwarded: 200,
          createdAt: new Date(2023, 4, 1)
        };
        this.challenges.set(conditioningChallenge.id, conditioningChallenge);
        const shootingChallenge = {
          id: this.currentChallengeId++,
          title: "Shooting Challenge",
          description: "Make 50 free throws with 80% accuracy",
          difficulty: "beginner",
          category: "basketball",
          pointsAwarded: 150,
          createdAt: new Date(2023, 4, 1)
        };
        this.challenges.set(shootingChallenge.id, shootingChallenge);
        const strengthChallenge = {
          id: this.currentChallengeId++,
          title: "Strength Challenge",
          description: "Complete 5 sets of 10 push-ups, 10 sit-ups, and 10 squats",
          difficulty: "beginner",
          category: "strength",
          pointsAwarded: 100,
          createdAt: new Date(2023, 4, 1)
        };
        this.challenges.set(strengthChallenge.id, strengthChallenge);
        const athleteShootingChallenge = {
          id: this.currentAthleteChallengeId++,
          userId: athleteUser.id,
          challengeId: shootingChallenge.id,
          status: "completed",
          progress: 100,
          startedAt: new Date(2023, 5, 10),
          completedAt: new Date(2023, 5, 12)
        };
        this.athleteChallenges.set(athleteShootingChallenge.id, athleteShootingChallenge);
        const athleteStrengthChallenge = {
          id: this.currentAthleteChallengeId++,
          userId: athleteUser.id,
          challengeId: strengthChallenge.id,
          status: "in-progress",
          progress: 60,
          startedAt: new Date(2023, 5, 15),
          completedAt: null
        };
        this.athleteChallenges.set(athleteStrengthChallenge.id, athleteStrengthChallenge);
        const recoveryLog1 = {
          id: this.currentRecoveryLogId++,
          userId: athleteUser.id,
          sleepHours: 8,
          hydrationLevel: 7,
          nutritionLevel: 6,
          fatigueLevel: 3,
          soreness: 4,
          notes: "Feeling good overall, slight soreness in quads from yesterday's workout",
          logDate: new Date(2023, 5, 18)
        };
        this.recoveryLogs.set(recoveryLog1.id, recoveryLog1);
        const recoveryLog2 = {
          id: this.currentRecoveryLogId++,
          userId: athleteUser.id,
          sleepHours: 6,
          hydrationLevel: 5,
          nutritionLevel: 7,
          fatigueLevel: 6,
          soreness: 5,
          notes: "Not enough sleep last night, more tired than usual",
          logDate: new Date(2023, 5, 17)
        };
        this.recoveryLogs.set(recoveryLog2.id, recoveryLog2);
        const fanClubFollower1 = {
          id: this.currentFanClubFollowerId++,
          athleteId: athleteUser.id,
          followerName: "James Smith",
          followerType: "fan",
          followDate: new Date(2023, 4, 20)
        };
        this.fanClubFollowers.set(fanClubFollower1.id, fanClubFollower1);
        const fanClubFollower2 = {
          id: this.currentFanClubFollowerId++,
          athleteId: athleteUser.id,
          followerName: "Coach Thompson",
          followerType: "recruiter",
          followDate: new Date(2023, 5, 5)
        };
        this.fanClubFollowers.set(fanClubFollower2.id, fanClubFollower2);
        const fanClubFollower3 = {
          id: this.currentFanClubFollowerId++,
          athleteId: athleteUser.id,
          followerName: "John Johnson",
          followerType: "family",
          followDate: new Date(2023, 4, 15)
        };
        this.fanClubFollowers.set(fanClubFollower3.id, fanClubFollower3);
        const message1 = {
          id: this.currentMessageId++,
          senderId: coachUser1.id,
          recipientId: athleteUser.id,
          content: "Hi Alex, I was impressed with your basketball jump shot video. Would love to discuss your college plans.",
          createdAt: new Date(2023, 4, 20),
          isRead: true
        };
        this.messages.set(message1.id, message1);
        const message2 = {
          id: this.currentMessageId++,
          senderId: athleteUser.id,
          recipientId: coachUser1.id,
          content: "Thank you Coach Williams! I'm very interested in your basketball program. When would be a good time to talk?",
          createdAt: new Date(2023, 4, 21),
          isRead: true
        };
        this.messages.set(message2.id, message2);
        const message3 = {
          id: this.currentMessageId++,
          senderId: coachUser1.id,
          recipientId: athleteUser.id,
          content: "How about this Friday at 3pm? We can discuss scholarship opportunities and what our program can offer you.",
          createdAt: new Date(2023, 4, 22),
          isRead: false
        };
        this.messages.set(message3.id, message3);
        const message4 = {
          id: this.currentMessageId++,
          senderId: coachUser2.id,
          recipientId: athleteUser.id,
          content: "Alex, I noticed your vertical leap stats. Have you considered volleyball? We might have a spot for you on our team.",
          createdAt: new Date(2023, 5, 1),
          isRead: false
        };
        this.messages.set(message4.id, message4);
        const shootingLeaderboardEntry = {
          id: this.currentLeaderboardEntryId++,
          userId: athleteUser.id,
          username: athleteUser.username,
          category: "basketball-shooting",
          score: 850,
          rankPosition: 3,
          updatedAt: new Date(2023, 5, 15)
        };
        this.leaderboardEntries.set(shootingLeaderboardEntry.id, shootingLeaderboardEntry);
        const verticalLeaderboardEntry = {
          id: this.currentLeaderboardEntryId++,
          userId: athleteUser.id,
          username: athleteUser.username,
          category: "vertical-jump",
          score: 920,
          rankPosition: 2,
          updatedAt: new Date(2023, 5, 15)
        };
        this.leaderboardEntries.set(verticalLeaderboardEntry.id, verticalLeaderboardEntry);
        const blogPost1 = {
          id: this.currentBlogPostId++,
          title: "5 Tips to Improve Your Vertical Jump",
          slug: "5-tips-improve-vertical-jump",
          content: "Increasing your vertical jump can dramatically improve your performance in basketball, volleyball, and many other sports. Here are five evidence-based tips to help you add inches to your vertical leap...",
          summary: "Learn how to increase your vertical jump with these proven techniques that can help you gain an edge in your sport.",
          category: "training",
          authorId: coachUser1.id,
          coverImage: "https://images.unsplash.com/photo-1574416792053-85da360629e5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
          publishDate: new Date(2023, 5, 10),
          featured: true,
          tags: ["vertical jump", "training", "basketball", "volleyball"]
        };
        this.blogPosts.set(blogPost1.id, blogPost1);
        const blogPost2 = {
          id: this.currentBlogPostId++,
          title: "Understanding the NCAA Eligibility Process",
          slug: "understanding-ncaa-eligibility-process",
          content: "Navigating the NCAA eligibility process can be complex for student athletes. This comprehensive guide breaks down each requirement and provides a clear roadmap to ensure you maintain your eligibility...",
          summary: "A complete guide to NCAA eligibility requirements and how to ensure you meet all criteria as a student athlete.",
          category: "ncaa",
          authorId: adminUser.id,
          coverImage: "https://images.unsplash.com/photo-1580846629473-61e93f9b2268?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
          publishDate: new Date(2023, 5, 15),
          featured: true,
          tags: ["ncaa", "eligibility", "college sports", "recruitment"]
        };
        this.blogPosts.set(blogPost2.id, blogPost2);
        const blogPost3 = {
          id: this.currentBlogPostId++,
          title: "How AI Is Transforming Sports Analysis",
          slug: "how-ai-transforming-sports-analysis",
          content: "Artificial intelligence is revolutionizing how athletes and coaches analyze performance. From motion detection to predictive analytics, discover how AI tools are providing unprecedented insights into athletic performance...",
          summary: "Discover the cutting-edge AI technologies that are changing how athletes train and coaches recruit.",
          category: "technology",
          authorId: adminUser.id,
          coverImage: "https://images.unsplash.com/photo-1531482615713-2afd69097998?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
          publishDate: new Date(2023, 5, 20),
          featured: false,
          tags: ["AI", "technology", "sports analytics", "motion analysis"]
        };
        this.blogPosts.set(blogPost3.id, blogPost3);
        const contentBlock1 = {
          id: this.currentContentBlockId++,
          identifier: "what-makes-us-different-intro",
          title: "What Makes Us Different",
          content: "At Go4It, we're not just another sports platform. Our unique approach combines cutting-edge technology with deep sports expertise to provide student-athletes with unprecedented opportunities for growth and exposure.",
          section: "what-makes-us-different",
          order: 1,
          active: true,
          lastUpdated: /* @__PURE__ */ new Date(),
          lastUpdatedBy: 3,
          // Admin user
          metadata: {}
        };
        const contentBlock2 = {
          id: this.currentContentBlockId++,
          identifier: "pillar-ai-powered-analysis",
          title: "AI-Powered Analysis",
          content: "Our proprietary AI technology analyzes your game film and training videos to provide detailed feedback on technique, positioning, and performance metrics that would typically require multiple coaches.",
          section: "what-makes-us-different",
          order: 2,
          active: true,
          lastUpdated: /* @__PURE__ */ new Date(),
          lastUpdatedBy: 3,
          // Admin user
          metadata: { icon: "brain-circuit" }
        };
        const contentBlock3 = {
          id: this.currentContentBlockId++,
          identifier: "pillar-verified-combines",
          title: "Verified Combines",
          content: "Our combines provide accurate, standardized measurements and assessments that are trusted by college recruiters and coaches across the country.",
          section: "what-makes-us-different",
          order: 3,
          active: true,
          lastUpdated: /* @__PURE__ */ new Date(),
          lastUpdatedBy: 3,
          // Admin user
          metadata: { icon: "medal" }
        };
        const contentBlock4 = {
          id: this.currentContentBlockId++,
          identifier: "pillar-direct-scout-connections",
          title: "Direct Scout Connections",
          content: "Get noticed by our network of scouts and recruiters who are actively searching for talent across all levels of competition.",
          section: "what-makes-us-different",
          order: 4,
          active: true,
          lastUpdated: /* @__PURE__ */ new Date(),
          lastUpdatedBy: 3,
          // Admin user
          metadata: { icon: "user-search" }
        };
        const contentBlock5 = {
          id: this.currentContentBlockId++,
          identifier: "pillar-personalized-development",
          title: "Personalized Development",
          content: "Our GAR (Growth, Achievement, Recognition) model creates a personalized development path that adapts to your unique strengths, goals, and progress.",
          section: "what-makes-us-different",
          order: 5,
          active: true,
          lastUpdated: /* @__PURE__ */ new Date(),
          lastUpdatedBy: 3,
          // Admin user
          metadata: { icon: "line-chart" }
        };
        this.contentBlocks.set(contentBlock1.id, contentBlock1);
        this.contentBlocks.set(contentBlock2.id, contentBlock2);
        this.contentBlocks.set(contentBlock3.id, contentBlock3);
        this.contentBlocks.set(contentBlock4.id, contentBlock4);
        this.contentBlocks.set(contentBlock5.id, contentBlock5);
        const featuredAthlete1 = {
          id: this.currentFeaturedAthleteId++,
          userId: athleteUser.id,
          highlightText: "Alex Johnson has shown exceptional progress in basketball skills, with a 92% match to the sport based on motion analysis.",
          sportPosition: "Guard",
          starRating: 4,
          featuredStats: {
            points: 25,
            rebounds: 8,
            assists: 5,
            achievements: ["Regional championship MVP", "25 points per game average"]
          },
          featuredDate: new Date(2023, 5, 15),
          featuredVideo: sampleVideo.id.toString(),
          coverImage: athleteUser.profileImage || "https://images.unsplash.com/photo-1628157588553-5eeea00af15c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
          order: 1,
          active: true
        };
        this.featuredAthletes.set(featuredAthlete1.id, featuredAthlete1);
        const now = /* @__PURE__ */ new Date();
        const strengthPlaylist = {
          id: this.currentWorkoutPlaylistId++,
          userId: athleteUser.id,
          name: "Basketball Strength Builder",
          description: "A strength training program designed for basketball players to improve performance",
          workoutType: "Strength",
          intensityLevel: "Intermediate",
          durationMinutes: 45,
          targetAreas: ["Upper Body", "Lower Body", "Core"],
          isPublic: true,
          createdAt: now,
          lastUsed: now,
          timesUsed: 12
        };
        this.workoutPlaylists.set(strengthPlaylist.id, strengthPlaylist);
        const strengthExercises = [
          {
            id: this.currentWorkoutExerciseId++,
            playlistId: strengthPlaylist.id,
            name: "Push-ups",
            description: "Standard push-ups focusing on chest and triceps",
            durationSeconds: 60,
            repetitions: 15,
            sets: 3,
            restSeconds: 30,
            orderIndex: 1
          },
          {
            id: this.currentWorkoutExerciseId++,
            playlistId: strengthPlaylist.id,
            name: "Bodyweight Squats",
            description: "Deep squats to strengthen quads and glutes",
            durationSeconds: 60,
            repetitions: 20,
            sets: 3,
            restSeconds: 45,
            orderIndex: 2
          },
          {
            id: this.currentWorkoutExerciseId++,
            playlistId: strengthPlaylist.id,
            name: "Plank",
            description: "Core stabilization exercise",
            durationSeconds: 45,
            repetitions: null,
            sets: 3,
            restSeconds: 30,
            orderIndex: 3
          },
          {
            id: this.currentWorkoutExerciseId++,
            playlistId: strengthPlaylist.id,
            name: "Lunges",
            description: "Forward lunges for leg strength",
            durationSeconds: 60,
            repetitions: 12,
            sets: 3,
            restSeconds: 30,
            orderIndex: 4
          }
        ];
        for (const exercise of strengthExercises) {
          this.workoutExercises.set(exercise.id, exercise);
        }
        const cardioPlaylist = {
          id: this.currentWorkoutPlaylistId++,
          userId: athleteUser.id,
          name: "Basketball Conditioning",
          description: "High-intensity cardio workout to improve basketball endurance",
          workoutType: "Cardio",
          intensityLevel: "Advanced",
          durationMinutes: 30,
          targetAreas: ["Cardiovascular", "Agility"],
          isPublic: true,
          createdAt: now,
          lastUsed: new Date(now.getTime() - 7 * 24 * 60 * 60 * 1e3),
          // 7 days ago
          timesUsed: 8
        };
        this.workoutPlaylists.set(cardioPlaylist.id, cardioPlaylist);
        const cardioExercises = [
          {
            id: this.currentWorkoutExerciseId++,
            playlistId: cardioPlaylist.id,
            name: "Line Sprints",
            description: "Court line-to-line sprints",
            durationSeconds: 30,
            repetitions: 10,
            sets: 2,
            restSeconds: 15,
            orderIndex: 1
          },
          {
            id: this.currentWorkoutExerciseId++,
            playlistId: cardioPlaylist.id,
            name: "Jumping Jacks",
            description: "Classic cardio exercise",
            durationSeconds: 60,
            repetitions: null,
            sets: 3,
            restSeconds: 20,
            orderIndex: 2
          },
          {
            id: this.currentWorkoutExerciseId++,
            playlistId: cardioPlaylist.id,
            name: "Burpees",
            description: "Full body cardio exercise",
            durationSeconds: 45,
            repetitions: 12,
            sets: 3,
            restSeconds: 30,
            orderIndex: 3
          }
        ];
        for (const exercise of cardioExercises) {
          this.workoutExercises.set(exercise.id, exercise);
        }
        const flexPlaylist = {
          id: this.currentWorkoutPlaylistId++,
          userId: athleteUser.id,
          name: "My Recovery Routine",
          description: "Personal flexibility and recovery routine",
          workoutType: "Flexibility",
          intensityLevel: "Beginner",
          durationMinutes: 20,
          targetAreas: ["Recovery", "Flexibility"],
          isPublic: false,
          createdAt: now,
          lastUsed: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1e3),
          // 2 days ago
          timesUsed: 5
        };
        this.workoutPlaylists.set(flexPlaylist.id, flexPlaylist);
        const flexExercises = [
          {
            id: this.currentWorkoutExerciseId++,
            playlistId: flexPlaylist.id,
            name: "Hamstring Stretch",
            description: "Seated hamstring stretch",
            durationSeconds: 30,
            repetitions: null,
            sets: 2,
            restSeconds: 10,
            orderIndex: 1
          },
          {
            id: this.currentWorkoutExerciseId++,
            playlistId: flexPlaylist.id,
            name: "Shoulder Stretch",
            description: "Cross-body shoulder stretch",
            durationSeconds: 30,
            repetitions: null,
            sets: 2,
            restSeconds: 10,
            orderIndex: 2
          },
          {
            id: this.currentWorkoutExerciseId++,
            playlistId: flexPlaylist.id,
            name: "Quad Stretch",
            description: "Standing quad stretch",
            durationSeconds: 30,
            repetitions: null,
            sets: 2,
            restSeconds: 10,
            orderIndex: 3
          },
          {
            id: this.currentWorkoutExerciseId++,
            playlistId: flexPlaylist.id,
            name: "Calf Stretch",
            description: "Wall calf stretch",
            durationSeconds: 30,
            repetitions: null,
            sets: 2,
            restSeconds: 10,
            orderIndex: 4
          }
        ];
        for (const exercise of flexExercises) {
          this.workoutExercises.set(exercise.id, exercise);
        }
      }
    };
    storage = new DatabaseStorage();
  }
});

// server/services/openai-service.ts
import { OpenAI } from "openai";
import { eq as eq3 } from "drizzle-orm";
var OpenAIService, openAIService;
var init_openai_service = __esm({
  "server/services/openai-service.ts"() {
    "use strict";
    init_db();
    init_schema();
    OpenAIService = class {
      client = null;
      apiKey = null;
      constructor() {
        console.log("Using OpenAI service for all OpenAI API calls");
      }
      /**
       * Check if a valid OpenAI API key is available
       * @returns Promise resolving to true if valid key is available
       * @throws Error if no valid key is found
       */
      async hasValidApiKey() {
        await this.getClient();
        return true;
      }
      /**
       * Get or create an OpenAI client with a valid API key
       * @returns Promise resolving to an OpenAI client
       * @throws Error if no valid key is found
       */
      async getClient() {
        if (this.client) {
          return this.client;
        }
        const apiKey = await this.getApiKeyFromDatabase();
        if (!apiKey) {
          throw new Error("No OpenAI API key found in the database or environment");
        }
        try {
          this.client = new OpenAI({
            apiKey
          });
          await this.client.models.list();
          this.updateApiKeyLastUsed("openai").catch((err) => {
            console.error("Error updating API key last used timestamp:", err);
          });
          this.apiKey = apiKey;
          return this.client;
        } catch (error) {
          console.error("Error validating OpenAI API key:", error);
          this.client = null;
          throw new Error("Invalid OpenAI API key");
        }
      }
      /**
       * Get the OpenAI API key from the database
       * @returns Promise resolving to the API key or null if not found
       */
      async getApiKeyFromDatabase() {
        try {
          const result = await db.select().from(apiKeys).where(eq3(apiKeys.keyType, "openai")).limit(1);
          if (result && result.length > 0) {
            return result[0].keyValue;
          }
          return process.env.OPENAI_API_KEY || null;
        } catch (error) {
          console.error("Error getting API key from database:", error);
          return process.env.OPENAI_API_KEY || null;
        }
      }
      /**
       * Update the last used timestamp for an API key
       * @param keyType The type of API key to update
       */
      async updateApiKeyLastUsed(keyType) {
        try {
          await db.update(apiKeys).set({ lastUsed: /* @__PURE__ */ new Date() }).where(eq3(apiKeys.keyType, keyType));
        } catch (error) {
          console.error("Error updating API key last used timestamp:", error);
        }
      }
    };
    openAIService = new OpenAIService();
  }
});

// server/openai.ts
var openai_exports = {};
__export(openai_exports, {
  analyzeVideo: () => analyzeVideo,
  analyzeWorkoutVerification: () => analyzeWorkoutVerification,
  generateAICoachResponse: () => generateAICoachResponse,
  generateAthleteImage: () => generateAthleteImage,
  generatePersonalizedTrainingPlan: () => generatePersonalizedTrainingPlan,
  generateRealTimeWorkoutFeedback: () => generateRealTimeWorkoutFeedback,
  generateSportRecommendations: () => generateSportRecommendations,
  generateWeightRoomPlan: () => generateWeightRoomPlan,
  getFormFeedback: () => getFormFeedback,
  verifyWorkoutVideo: () => verifyWorkoutVideo
});
import OpenAI2 from "openai";
import fs5 from "fs";
import path6 from "path";
import { v4 as uuidv43 } from "uuid";
async function getOpenAIClient() {
  try {
    return await openAIService.getClient();
  } catch (error) {
    console.error("Error getting OpenAI client from service:", error);
    if (openai) {
      return openai;
    }
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      throw new Error("No OpenAI API key available");
    }
    openai = new OpenAI2({ apiKey });
    return openai;
  }
}
async function generateAthleteImage(sport, position, starLevel) {
  try {
    console.log(`Generating athlete image for ${position} in ${sport} (${starLevel} stars)`);
    const uploadsDir2 = path6.join(process.cwd(), "uploads", "athletes");
    if (!fs5.existsSync(uploadsDir2)) {
      fs5.mkdirSync(uploadsDir2, { recursive: true });
    }
    const quality = starLevel >= 4 ? "hd" : "standard";
    const prompt = `A realistic photograph portrait of a student athlete playing ${sport} as a ${position}. 
    They are ${starLevel >= 4 ? "elite-level" : starLevel >= 3 ? "varsity-level" : "junior varsity level"}. 
    The image should be a close-up headshot showing their face clearly while they're wearing appropriate uniform/gear for ${sport}. 
    This should be a professional-looking action portrait of a real high school/college athlete, similar to those used in college recruiting profiles.
    Focus on a realistic, natural expression, not posed or artificial-looking. Show them actively engaged in their sport.`;
    const client = await getOpenAIClient();
    const response = await client.images.generate({
      model: "dall-e-3",
      prompt,
      n: 1,
      size: "1024x1024",
      quality,
      style: "natural"
    });
    const imageUrl = response.data[0].url;
    if (!imageUrl) {
      throw new Error("No image URL returned from OpenAI");
    }
    const response1 = await fetch(imageUrl);
    const arrayBuffer = await response1.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    const uniqueFilename = `${sport.toLowerCase()}_${position.toLowerCase()}_${starLevel}star_${uuidv43().substring(0, 8)}.png`;
    const imagePath = path6.join(uploadsDir2, uniqueFilename);
    fs5.writeFileSync(imagePath, buffer);
    return `/uploads/athletes/${uniqueFilename}`;
  } catch (error) {
    console.error("Error generating athlete image:", error);
    throw new Error(`Failed to generate athlete image: ${error?.message || "Unknown error"}`);
  }
}
function generateMockAnalysis(sportType) {
  console.log(`Generating mock analysis for ${sportType} due to missing API key`);
  const getDefaultMetrics = () => {
    switch (sportType.toLowerCase()) {
      case "basketball":
        return {
          elbowAlignment: 85,
          releasePoint: 78,
          followThrough: 82,
          balance: 75
        };
      case "soccer":
        return {
          kickingForm: 80,
          balance: 85,
          followThrough: 75,
          positioning: 82
        };
      case "baseball":
        return {
          stanceBalance: 78,
          swingPath: 82,
          hipRotation: 76,
          followThrough: 80
        };
      case "volleyball":
        return {
          approachTiming: 75,
          armSwing: 80,
          jumpHeight: 85,
          handContact: 78
        };
      case "track":
        return {
          stride: 82,
          armMotion: 78,
          posture: 85,
          kneeHeight: 80
        };
      default:
        return {
          athleticism: 80,
          coordination: 78,
          balance: 75,
          powerGeneration: 82
        };
    }
  };
  const mockKeypoints = [
    { x: 0.45, y: 0.38, confidence: 0.92, name: "head" },
    { x: 0.48, y: 0.52, confidence: 0.95, name: "torso" },
    { x: 0.42, y: 0.65, confidence: 0.88, name: "knees" },
    { x: 0.46, y: 0.85, confidence: 0.85, name: "feet" }
  ];
  const generateFeedback = () => {
    switch (sportType.toLowerCase()) {
      case "basketball":
        return "Good form on your jumpshot. Your elbow alignment is solid, and your follow-through shows good technique. Your balance could use some improvement on landing.";
      case "soccer":
        return "Your kicking technique shows good fundamentals. You maintain solid balance throughout the motion, and your follow-through is consistent. Work on your positioning for maximum power.";
      case "baseball":
        return "Your swing demonstrates good fundamentals. Your stance is balanced, and you generate good hip rotation. Work on completing your follow-through for maximum power.";
      case "volleyball":
        return "Your approach timing is consistent, and you generate good height on your jump. Your arm swing technique is solid, but you could improve hand contact for better ball control.";
      case "track":
        return "Your running form shows good fundamentals. Your stride length is efficient, and your posture remains upright. Focus on arm motion to complement your leg drive.";
      default:
        return "Your athletic movement demonstrates good overall technique. You show solid coordination and balance throughout the motion. Continue to work on power generation for improved performance.";
    }
  };
  const generateTips = () => {
    switch (sportType.toLowerCase()) {
      case "basketball":
        return [
          "Focus on landing with knees slightly bent for better balance after shot",
          "Ensure your guide hand stays on the side of the ball without affecting the shot",
          "Practice maintaining a consistent release point",
          "Work on keeping your shooting elbow directly under the ball"
        ];
      case "soccer":
        return [
          "Practice planting your non-kicking foot more firmly beside the ball",
          "Focus on striking the ball with the instep for more power",
          "Improve your follow-through by extending through the kick",
          "Work on hip rotation to generate more power"
        ];
      case "baseball":
        return [
          "Keep your weight back slightly longer before transferring forward",
          "Focus on keeping your hands inside the ball during your swing",
          "Improve hip rotation timing for better power transfer",
          "Work on maintaining a level swing path through the zone"
        ];
      case "volleyball":
        return [
          "Focus on timing your approach consistently with the set",
          "Work on extending your arm fully during your swing",
          "Practice contacting the ball at the highest point of your jump",
          "Improve wrist snap at contact for better ball control"
        ];
      case "track":
        return [
          "Focus on driving your knees higher during acceleration phase",
          "Work on arm motion that complements your stride",
          "Practice maintaining upright posture throughout your run",
          "Improve foot strike for more efficient energy transfer"
        ];
      default:
        return [
          "Focus on maintaining balanced positioning throughout the movement",
          "Work on coordinating upper and lower body movements",
          "Practice consistent technique to build muscle memory",
          "Improve power generation through proper sequencing of movements"
        ];
    }
  };
  return {
    motionData: {
      ...getDefaultMetrics(),
      keypoints: mockKeypoints
    },
    overallScore: Math.floor(75 + Math.random() * 10),
    // 75-85 range
    feedback: generateFeedback(),
    improvementTips: generateTips(),
    keyFrameTimestamps: [1.2, 2.8, 4.1, 5.6]
  };
}
async function analyzeVideo(videoId, videoPath) {
  try {
    console.log(`Analyzing video with ID: ${videoId} at path: ${videoPath}`);
    const video = await storage.getVideo(videoId);
    if (!video) {
      throw new Error("Video not found");
    }
    const sportType = video.sportType || "basketball";
    try {
      await getOpenAIClient();
    } catch (error) {
      console.log("No OpenAI API key found, using mock analysis");
      const mockAnalysis = generateMockAnalysis(sportType);
      await storage.saveVideoAnalysis(videoId, mockAnalysis);
      return mockAnalysis;
    }
    const analysisPrompt = `
You are an expert sports motion analyst and coach. You are analyzing a video of an athlete performing in ${sportType}. 
Please provide a detailed analysis of their form and technique.

Generate a JSON response with the following structure:
{
  "motionData": {
    // Include 3-5 sport-specific metrics as decimal values between 0-100
    // For basketball: elbowAlignment, releasePoint, followThrough, balance
    // For soccer: kickingForm, balance, followThrough, positioning
    // For baseball: stanceBalance, swingPath, hipRotation, followThrough
    // For volleyball: approachTiming, armSwing, jumpHeight, handContact
    // For track: stride, armMotion, posture, kneeHeight
    // Include 3-5 keypoints representing important body positions during the motion
    "keypoints": [
      {"x": decimal, "y": decimal, "confidence": decimal, "name": "bodyPart"}
    ]
  },
  "overallScore": number between 0-100,
  "feedback": "Detailed feedback on the athlete's form and technique",
  "improvementTips": [
    "3-5 specific, actionable tips for improvement"
  ],
  "keyFrameTimestamps": [
    // 3-4 key timestamps in seconds where form should be analyzed
  ]
}

Keep in mind that this is for a student athlete who is looking to improve and potentially be recruited.
Focus on constructive feedback while being encouraging. Be specific about strengths and areas for improvement.
    `;
    const client = await getOpenAIClient();
    const response = await client.chat.completions.create({
      model: "gpt-4o",
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are an expert sports motion analyst specializing in biomechanics and athletic performance."
        },
        {
          role: "user",
          content: analysisPrompt
        }
      ],
      response_format: { type: "json_object" }
    });
    const analysisResult = JSON.parse(response.choices[0].message.content || "{}");
    if (!analysisResult.motionData) analysisResult.motionData = {};
    if (!analysisResult.keyFrameTimestamps) analysisResult.keyFrameTimestamps = [1.5, 3, 4.5];
    if (!analysisResult.improvementTips) analysisResult.improvementTips = [];
    if (!analysisResult.feedback) analysisResult.feedback = "Analysis completed.";
    await storage.saveVideoAnalysis(videoId, analysisResult);
    console.log("Analysis completed successfully");
    return analysisResult;
  } catch (error) {
    console.error("Error analyzing video:", error);
    if (error.message && error.message.includes("API key")) {
      console.log("API key error, falling back to mock analysis");
      const video = await storage.getVideo(videoId);
      if (!video) {
        throw new Error("Video not found");
      }
      const sportType = video.sportType || "basketball";
      const mockAnalysis = generateMockAnalysis(sportType);
      await storage.saveVideoAnalysis(videoId, mockAnalysis);
      return mockAnalysis;
    }
    throw new Error(`Failed to analyze video: ${error?.message || "Unknown error"}`);
  }
}
async function generateSportRecommendations(userId, motionData, athleteProfile) {
  try {
    console.log(`Generating sport recommendations for user ${userId}`);
    const existingRecommendations = await storage.getSportRecommendations(userId);
    const existingSports = new Set(existingRecommendations.map((r) => r.sport.toLowerCase()));
    const athleteInfo = {
      age: athleteProfile.age || 18,
      height: athleteProfile.height || 175,
      // in cm
      weight: athleteProfile.weight || 70,
      // in kg
      sports: athleteProfile.sportsInterest || [],
      injuries: [],
      strengths: [],
      goals: []
    };
    const formattedMotionData = {
      ...motionData,
      overallScore: motionData.overallScore || 75
    };
    const recommendationPrompt = `
You are an expert sports scout and talent evaluator helping a student athlete find the sports that best match their physical attributes and movement patterns.

ATHLETE PROFILE:
- Age: ${athleteInfo.age} years
- Height: ${athleteInfo.height} cm
- Weight: ${athleteInfo.weight} kg
- Previous Sports Experience: ${athleteInfo.sports.join(", ") || "None"}
- Physical Strengths: ${athleteInfo.strengths.join(", ") || "Not specified"}
- Injuries: ${athleteInfo.injuries.join(", ") || "None"}
- Athletic Goals: ${athleteInfo.goals.join(", ") || "Not specified"}

MOTION ANALYSIS DATA:
${JSON.stringify(formattedMotionData, null, 2)}

TASK:
Recommend 5 sports that would be an excellent match for this athlete based on their profile and motion analysis data. 
For each recommendation, provide:
1. Sport name
2. Match percentage (1-100)
3. Position recommendation
4. Potential level (High School, Club, NCAA Div II, NCAA Div I, etc.)
5. A specific reason for why this sport matches their attributes

Return your response as a JSON array with the following structure:
[
  {
    "sport": "Sport name",
    "matchPercentage": number between 60-95,
    "positionRecommendation": "Best position for this athlete",
    "potentialLevel": "Competitive level potential",
    "reasonForMatch": "Detailed reason for this recommendation based on their attributes"
  },
  ...
]

Consider both traditional sports (basketball, soccer, etc.) and less common sports (rowing, fencing, etc.) that might be a good match.
Focus on realistic NCAA recruitment potential for college scholarships.

${existingSports.size > 0 ? `Note: The athlete already has recommendations for these sports, so exclude them: ${Array.from(existingSports).join(", ")}` : ""}
`;
    const client = await getOpenAIClient();
    const response = await client.chat.completions.create({
      model: "gpt-4o",
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are an expert sports talent scout with deep knowledge of athletic performance metrics and NCAA recruitment standards."
        },
        {
          role: "user",
          content: recommendationPrompt
        }
      ],
      response_format: { type: "json_object" }
    });
    let recommendations = JSON.parse(response.choices[0].message.content || "[]");
    if (!Array.isArray(recommendations)) {
      recommendations = [];
    }
    recommendations.sort((a, b) => b.matchPercentage - a.matchPercentage);
    return recommendations.slice(0, 3);
  } catch (error) {
    console.error("Error generating sport recommendations:", error);
    throw new Error(`Failed to generate sport recommendations: ${error?.message || "Unknown error"}`);
  }
}
async function generateAICoachResponse(userId, userMessage, messageHistory = []) {
  try {
    console.log(`Generating AI coach response for user ${userId}`);
    const athleteProfile = await storage.getAthleteProfile(userId);
    const playerProgress2 = await storage.getPlayerProgress(userId);
    const athleteInfo = athleteProfile ? {
      age: athleteProfile.age || 18,
      height: athleteProfile.height || 175,
      // in cm
      weight: athleteProfile.weight || 70,
      // in kg
      sports: athleteProfile.sportsInterest || [],
      experience: "beginner"
      // Default to beginner since experienceLevel isn't in schema
    } : {
      experience: "beginner"
    };
    const progressInfo = playerProgress2 ? {
      level: playerProgress2.currentLevel,
      xpTotal: playerProgress2.totalXp,
      focusAreas: ["Overall Fitness"]
      // Default focus areas since skillsFocus isn't in schema
    } : {
      level: 1,
      xpTotal: 0,
      focusAreas: ["Overall Fitness"]
    };
    const videos3 = await storage.getVideosByUser(userId);
    const recentAnalyses = [];
    for (const video of videos3.slice(0, 3)) {
      const analysis = await storage.getVideoAnalysisByVideoId(video.id);
      if (analysis) {
        recentAnalyses.push({
          sport: video.sportType,
          score: analysis.overallScore,
          feedback: analysis.feedback,
          improvementAreas: analysis.improvementTips
        });
      }
    }
    const formattedHistory = messageHistory.map((msg) => ({
      role: msg.role === "coach" ? "assistant" : "user",
      content: msg.content
    }));
    const systemPrompt = `
You are an AI sports coach and performance specialist named Coach AI, embedded in the GetVerified platform. 
Your goal is to guide student athletes through personalized training, technique improvements, and performance analysis.

ATHLETE PROFILE:
${JSON.stringify(athleteInfo, null, 2)}

PROGRESS INFO:
${JSON.stringify(progressInfo, null, 2)}

${recentAnalyses.length > 0 ? `RECENT PERFORMANCE ANALYSIS:
${JSON.stringify(recentAnalyses, null, 2)}` : ""}

Your coaching style should be:
- Motivational and positive, but honest about areas for improvement
- Focused on proper technique and injury prevention
- Adaptable to the athlete's current level (${progressInfo.level}/10)
- Specific and actionable with personalized advice
- Educational about sports science concepts when relevant

You can provide various types of assistance:
1. Answer questions about training, technique, and athletic development
2. Create personalized training plans for different goals
3. Analyze technique descriptions and provide feedback
4. Explain sport-specific skills and drills
5. Give advice on recovery, nutrition, and mental preparation
6. Interpret performance data when shared by the athlete

If the user asks for a workout or training plan, create a structured plan with:
- Specific exercises with sets, reps, and rest periods
- Clear progression path
- Focus areas tailored to their sport interests
- Explanation of how each component improves performance

For form analysis, provide:
- Specific corrections
- Key technique points
- Safety considerations
- Progressive skill development

Remember that you're working with student athletes, primarily focused on development and improvement, not professional performance.
`;
    const messages2 = [
      { role: "system", content: systemPrompt },
      ...formattedHistory,
      { role: "user", content: userMessage }
    ];
    const client = await getOpenAIClient();
    const response = await client.chat.completions.create({
      model: "gpt-4o",
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
      messages: messages2,
      temperature: 0.7,
      max_tokens: 1e3
    });
    const content = response.choices[0].message.content || "I'm sorry, I couldn't process that request.";
    let metadata = void 0;
    if ((userMessage.toLowerCase().includes("workout") || userMessage.toLowerCase().includes("training plan") || userMessage.toLowerCase().includes("program") || userMessage.toLowerCase().includes("routine")) && (content.includes("Day 1") || content.includes("Week 1") || content.includes("Sets:") || content.includes("Reps:"))) {
      metadata = {
        type: "workout",
        title: extractWorkoutTitle(content),
        items: extractWorkoutItems(content)
      };
    }
    await storage.addXpToPlayer(
      userId,
      10,
      // Base XP for interaction
      "ai_coach",
      "Interacted with AI Coach",
      void 0
    );
    return {
      role: "coach",
      content,
      metadata
    };
  } catch (error) {
    console.error("Error generating AI coach response:", error);
    throw new Error(`Failed to generate AI coach response: ${error?.message || "Unknown error"}`);
  }
}
async function analyzeWorkoutVerification(verificationId, videoPath) {
  try {
    console.log(`Analyzing workout verification video with ID: ${verificationId} at path: ${videoPath}`);
    const verification = await storage.getWorkoutVerification(verificationId);
    if (!verification) {
      throw new Error("Workout verification not found");
    }
    const checkpoints = await storage.getWorkoutVerificationCheckpoints(verificationId);
    const checkpoint = checkpoints.length > 0 ? checkpoints[0] : null;
    const exerciseType = checkpoint ? checkpoint.exerciseName : "general exercise";
    const targetReps = checkpoint ? checkpoint.targetAmount || 10 : 10;
    try {
      await getOpenAIClient();
    } catch (error) {
      console.log("No OpenAI API key found, using mock workout verification");
      const mockAnalysis = {
        isCompleted: true,
        completedAmount: Math.floor(targetReps * 0.8 + Math.random() * targetReps * 0.4),
        targetAmount: targetReps,
        repAccuracy: 75 + Math.floor(Math.random() * 15),
        feedback: `Good effort on your ${exerciseType}! Your form was generally solid, but focus on maintaining proper alignment throughout the movement.`,
        motionAnalysis: {
          formScore: 75 + Math.floor(Math.random() * 15),
          rangeOfMotion: 70 + Math.floor(Math.random() * 20),
          consistency: 65 + Math.floor(Math.random() * 25),
          keyIssues: [
            "Slight elbow flare on some repetitions",
            "Depth varied between repetitions"
          ]
        }
      };
      mockAnalysis.isCompleted = mockAnalysis.completedAmount >= targetReps;
      return mockAnalysis;
    }
    let base64Video;
    try {
      console.log("Reading video file for OpenAI analysis");
      if (fs5.existsSync(videoPath)) {
        const videoBuffer = fs5.readFileSync(videoPath);
        base64Video = videoBuffer.toString("base64");
      } else {
        console.warn(`Video file not found at path: ${videoPath}`);
        throw new Error("Video file not found");
      }
    } catch (error) {
      console.error("Error reading video file:", error);
      throw new Error("Failed to read video file");
    }
    console.log("Using OpenAI GPT-4o to analyze workout video");
    const analysisPrompt = `
You are an expert fitness coach and exercise form analyst. You are reviewing a workout verification video of a student athlete performing ${exerciseType} exercise.

The target for this workout was ${targetReps} repetitions.

Please analyze the video and provide a detailed assessment of:
1. Whether the athlete completed the required number of repetitions
2. The quality and accuracy of their form
3. Any specific feedback for improvement

Generate a JSON response with the following structure:
{
  "isCompleted": boolean indicating if they completed the required reps,
  "completedAmount": number of completed repetitions with acceptable form,
  "targetAmount": ${targetReps},
  "repAccuracy": number between 0-100 rating the overall form accuracy,
  "feedback": "Detailed but concise feedback on their performance",
  "motionAnalysis": {
    "formScore": number between 0-100,
    "rangeOfMotion": number between 0-100,
    "consistency": number between 0-100,
    "keyIssues": [
      "List of 2-3 specific form issues identified during the exercise"
    ]
  }
}

Be honest but encouraging in your assessment. Focus on constructive feedback that will help the athlete improve their form and performance.
`;
    const client = await getOpenAIClient();
    const visionResponse = await client.chat.completions.create({
      model: "gpt-4o",
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
      messages: [
        {
          role: "system",
          content: "You are an expert fitness coach specializing in exercise form analysis and workout verification."
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: analysisPrompt
            },
            {
              type: "image_url",
              image_url: {
                url: `data:video/mp4;base64,${base64Video}`
              }
            }
          ]
        }
      ],
      response_format: { type: "json_object" }
    });
    const analysisResult = JSON.parse(visionResponse.choices[0].message.content || "{}");
    if (!analysisResult.motionAnalysis) analysisResult.motionAnalysis = {};
    if (!analysisResult.motionAnalysis.keyIssues) analysisResult.motionAnalysis.keyIssues = [];
    if (!analysisResult.feedback) analysisResult.feedback = "Workout verified.";
    await storage.updateWorkoutVerification(
      verificationId,
      {
        verificationStatus: analysisResult.isCompleted ? "verified" : "rejected",
        notes: analysisResult.feedback
      }
    );
    console.log("Workout verification analysis completed successfully");
    return analysisResult;
  } catch (error) {
    console.error("Error analyzing workout verification:", error);
    if (error.message && error.message.includes("API key")) {
      console.log("API key error, falling back to mock workout verification");
      const verification = await storage.getWorkoutVerification(verificationId);
      if (!verification) {
        throw new Error("Workout verification not found");
      }
      const checkpoints = await storage.getWorkoutVerificationCheckpoints(verificationId);
      const checkpoint = checkpoints.length > 0 ? checkpoints[0] : null;
      const exerciseType = checkpoint ? checkpoint.exerciseName : "general exercise";
      const targetReps = checkpoint ? checkpoint.targetAmount || 10 : 10;
      const mockAnalysis = {
        isCompleted: true,
        completedAmount: Math.floor(targetReps * 0.8 + Math.random() * targetReps * 0.4),
        targetAmount: targetReps,
        repAccuracy: 75 + Math.floor(Math.random() * 15),
        feedback: `Good effort on your ${exerciseType}! Your form was generally solid, but focus on maintaining proper alignment throughout the movement.`,
        motionAnalysis: {
          formScore: 75 + Math.floor(Math.random() * 15),
          rangeOfMotion: 70 + Math.floor(Math.random() * 20),
          consistency: 65 + Math.floor(Math.random() * 25),
          keyIssues: [
            "Slight elbow flare on some repetitions",
            "Depth varied between repetitions"
          ]
        }
      };
      mockAnalysis.isCompleted = mockAnalysis.completedAmount >= targetReps;
      await storage.updateWorkoutVerification(
        verificationId,
        {
          verificationStatus: mockAnalysis.isCompleted ? "verified" : "rejected",
          notes: mockAnalysis.feedback
        }
      );
      return mockAnalysis;
    }
    throw new Error(`Failed to analyze workout verification: ${error?.message || "Unknown error"}`);
  }
}
async function generateRealTimeWorkoutFeedback(userId, exerciseType, performanceData) {
  try {
    console.log(`Generating real-time feedback for ${exerciseType} workout`);
    const athleteProfile = await storage.getAthleteProfile(userId);
    const formattedPerformanceData = {
      exerciseType,
      ...performanceData
    };
    const feedbackPrompt = `
You are an expert real-time workout coach providing immediate feedback on a student athlete's exercise performance.

EXERCISE INFORMATION:
Type: ${exerciseType}

PERFORMANCE DATA:
${JSON.stringify(formattedPerformanceData, null, 2)}

ATHLETE PROFILE:
${athleteProfile ? JSON.stringify({
      age: athleteProfile.age || 18,
      height: athleteProfile.height || 175,
      weight: athleteProfile.weight || 70,
      experience: "beginner"
      // We don't have experienceLevel in the schema
    }, null, 2) : "Beginner level athlete"}

TASK:
Provide immediate, actionable feedback on the athlete's current exercise performance.

Your feedback should include:
1. What they're doing well
2. One specific adjustment to improve form or effectiveness
3. A motivational cue to maintain energy and focus
4. A safety tip if relevant

Return your response as a JSON object with the following structure:
{
  "positiveFeedback": "What they're doing well",
  "adjustment": "Specific form correction or technique adjustment",
  "motivationalCue": "Short motivational phrase",
  "safetyTip": "Important safety consideration if needed",
  "overallAssessment": "Brief overall assessment of performance"
}

Keep your feedback concise - this is meant for real-time guidance during a workout.
`;
    const client = await getOpenAIClient();
    const response = await client.chat.completions.create({
      model: "gpt-4o",
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
      messages: [
        {
          role: "system",
          content: "You are an expert athletic trainer providing real-time workout feedback."
        },
        {
          role: "user",
          content: feedbackPrompt
        }
      ],
      response_format: { type: "json_object" }
    });
    const feedback = JSON.parse(response.choices[0].message.content || "{}");
    return feedback;
  } catch (error) {
    console.error("Error generating real-time workout feedback:", error);
    throw new Error(`Failed to generate real-time workout feedback: ${error?.message || "Unknown error"}`);
  }
}
async function generatePersonalizedTrainingPlan(userId, goals = ["Overall Performance"], durationWeeks = 4, daysPerWeek = 3, focusAreas = []) {
  try {
    console.log(`Generating personalized training plan for user ${userId}`);
    const athleteProfile = await storage.getAthleteProfile(userId);
    if (!athleteProfile) {
      throw new Error("Athlete profile not found");
    }
    const playerProgress2 = await storage.getPlayerProgress(userId);
    const athleteLevel = playerProgress2 ? playerProgress2.currentLevel : 1;
    const athleteInfo = {
      age: athleteProfile.age || 18,
      height: athleteProfile.height || 175,
      weight: athleteProfile.weight || 70,
      sports: athleteProfile.sportsInterest || [],
      experience: "beginner",
      // Default to beginner since experienceLevel isn't in schema
      skillLevel: athleteLevel
    };
    const planPrompt = `
You are an expert athletic trainer creating a personalized training plan for a student athlete.

ATHLETE PROFILE:
${JSON.stringify(athleteInfo, null, 2)}

TRAINING PLAN PARAMETERS:
- Goals: ${goals.join(", ")}
- Duration: ${durationWeeks} weeks
- Frequency: ${daysPerWeek} days per week
- Focus Areas: ${focusAreas.length > 0 ? focusAreas.join(", ") : "General athletic development"}

TASK:
Create a comprehensive, progressive training plan that will help this athlete improve based on their profile, goals, and focus areas.

The training plan should include:
1. An overall description of the training approach
2. Weekly breakdown of workouts
3. Day-by-day exercise prescriptions
4. Progression scheme throughout the program
5. Key performance indicators to track

For each workout, include:
- Warm-up activities
- Main exercises with sets, reps, and rest periods
- Cool-down/recovery activities
- Training tips specific to that workout

Return your response as a JSON object with the following structure:
{
  "planTitle": "Name of the training plan",
  "planDescription": "Overall description and approach",
  "weeks": [
    {
      "weekNumber": 1,
      "focus": "Focus for this week",
      "progressionNotes": "How this week builds on previous training",
      "days": [
        {
          "dayNumber": 1,
          "type": "Type of training (e.g., Strength, Speed, Recovery)",
          "warmup": "Warm-up routine description",
          "exercises": [
            {
              "name": "Exercise name",
              "sets": number of sets,
              "reps": "reps description (e.g., '10 reps' or '30 seconds')",
              "rest": "rest period in seconds",
              "notes": "Form cues or important details",
              "progressionTip": "How to progress this exercise"
            },
            ...more exercises
          ],
          "cooldown": "Cool-down routine description",
          "tips": "Tips specific to this workout day"
        },
        ...more days
      ]
    },
    ...more weeks
  ],
  "keyPerformanceIndicators": [
    "KPI 1 to track progress",
    "KPI 2 to track progress",
    ...
  ],
  "nutritionTips": "General nutrition advice for this plan",
  "recoveryRecommendations": "Recovery recommendations during this program"
}

Make sure the plan is appropriate for their age (${athleteInfo.age}), experience level (${athleteInfo.experience}), and skill level (${athleteInfo.skillLevel}/10).
Focus on proper progression to prevent injuries while maximizing improvement.
If the athlete has specific sports interests, tailor exercises to improve sport-specific performance.
`;
    const client = await getOpenAIClient();
    const response = await client.chat.completions.create({
      model: "gpt-4o",
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
      messages: [
        {
          role: "system",
          content: "You are an expert athletic trainer and sports science specialist creating personalized training programs for athletes."
        },
        {
          role: "user",
          content: planPrompt
        }
      ],
      response_format: { type: "json_object" }
    });
    const trainingPlan = JSON.parse(response.choices[0].message.content || "{}");
    await storage.addXpToPlayer(
      userId,
      50,
      // Significant XP for getting a full training plan
      "training_plan",
      `Generated ${trainingPlan.planTitle || "personalized training plan"}`,
      void 0
    );
    return trainingPlan;
  } catch (error) {
    console.error("Error generating personalized training plan:", error);
    throw new Error(`Failed to generate personalized training plan: ${error?.message || "Unknown error"}`);
  }
}
function extractWorkoutTitle(content) {
  const titlePatterns = [
    /[#*]+\s*(.*?training plan.*?|.*?workout.*?|.*?program.*?)\s*[#*]*/i,
    /(?:^|\n)#+\s*(.*?training plan.*?|.*?workout.*?|.*?program.*?)\s*(?:\n|$)/i,
    /(?:^|\n)[A-Z][\w\s&-]+(?:TRAINING|WORKOUT|PROGRAM|PLAN)[\w\s&-]*(?:\n|$)/,
    /(?:^|\n)["']*([\w\s&-]+(?:Training|Workout|Program|Plan)[\w\s&-]*)["']*(?:\n|$)/i
  ];
  for (const pattern of titlePatterns) {
    const match = content.match(pattern);
    if (match && match[1]) {
      return match[1].trim();
    }
  }
  const firstLine = content.split("\n")[0].trim();
  return firstLine.length > 5 ? firstLine : "Personalized Training Plan";
}
function extractWorkoutItems(content) {
  const items = [];
  const patterns = [
    /(?:^|\n)[-*•]?\s*((?:Day|Week)\s+\d+:.*?)(?:\n|$)/g,
    /(?:^|\n)[-*•]?\s*((?:Strength|Cardio|HIIT|Speed|Agility|Recovery|Mobility).*?)(?:\n|$)/g,
    /(?:^|\n)[-*•]?\s*((?:\d+[x×]|\d+\s+sets).*?)(?:\n|$)/g,
    /(?:^|\n)[-*•]?\s*((?:\d+\s+reps|seconds).*?)(?:\n|$)/g
  ];
  for (const pattern of patterns) {
    let match;
    while ((match = pattern.exec(content)) !== null && items.length < 5) {
      if (match[1] && !items.includes(match[1].trim())) {
        items.push(match[1].trim());
      }
    }
  }
  if (items.length < 3) {
    const contentLower = content.toLowerCase();
    if (contentLower.includes("warm")) items.push("Proper warm-up included");
    if (contentLower.includes("strength") || contentLower.includes("weight")) items.push("Strength training components");
    if (contentLower.includes("cardio") || contentLower.includes("endurance")) items.push("Cardiovascular conditioning");
    if (contentLower.includes("mobility") || contentLower.includes("flexibility")) items.push("Mobility and flexibility work");
    if (contentLower.includes("recovery") || contentLower.includes("rest")) items.push("Recovery protocols included");
  }
  return items.slice(0, 5);
}
async function generateWeightRoomPlan(userId, equipmentList, level, goals = ["Strength", "Speed", "Endurance"]) {
  try {
    console.log(`Generating weight room plan for user ${userId} at level ${level}`);
    const playerProgress2 = await storage.getPlayerProgress(userId);
    if (!playerProgress2) {
      throw new Error("Player progress not found");
    }
    const playerEquipment2 = await storage.getPlayerEquipment(userId);
    const availableEquipment = equipmentList.filter((eq10) => {
      return playerEquipment2.some((pe) => pe.equipmentId === eq10.id);
    }).map((eq10) => ({
      name: eq10.name,
      category: eq10.equipmentType,
      // Use equipmentType as category
      id: eq10.id,
      difficultyLevel: eq10.difficultyLevel
    }));
    if (availableEquipment.length === 0) {
      const recommendedEquipment = equipmentList.filter((eq10) => eq10.unlockLevel <= playerProgress2.currentLevel).slice(0, 3).map((eq10) => ({
        name: eq10.name,
        category: eq10.equipmentType,
        // Use equipmentType as category
        id: eq10.id,
        unlockLevel: eq10.unlockLevel,
        difficultyLevel: eq10.difficultyLevel,
        description: eq10.description
      }));
      return {
        hasEquipment: false,
        playerLevel: playerProgress2.currentLevel,
        recommendedEquipment
      };
    }
    const workoutPrompt = `
You are an expert athletic trainer designing a personalized weight room workout plan for a student athlete.

ATHLETE PROFILE:
- Skill Level: ${level} out of 10
- Current XP Level: ${playerProgress2.currentLevel}
- Athletic Goals: ${goals.join(", ")}

AVAILABLE EQUIPMENT:
${JSON.stringify(availableEquipment, null, 2)}

TASK:
Create a personalized 30-minute weight room workout routine that will help this athlete improve based on their goals and available equipment.

The workout should include:
1. A 5-minute warm-up
2. 3-4 main exercises using their available equipment
3. A 3-minute cool-down

For each exercise, provide:
- Equipment to use (from their available list)
- Number of sets
- Number of reps per set
- Rest time between sets
- A form tip to help them perform the exercise correctly
- How this exercise contributes to their athletic goals

Return your response as a JSON object with the following structure:
{
  "warmup": {
    "duration": "5 minutes",
    "description": "Detailed warmup instructions"
  },
  "exercises": [
    {
      "name": "Exercise name",
      "equipmentId": equipment ID number,
      "sets": number of sets,
      "reps": number of reps per set,
      "rest": "rest time in seconds",
      "formTip": "Key form tip for proper execution",
      "benefit": "How this helps their athletic goals"
    },
    ...
  ],
  "cooldown": {
    "duration": "3 minutes",
    "description": "Detailed cooldown instructions"
  },
  "progressionTip": "Advice on how to progress to more advanced workouts",
  "expectedXpGain": number between 20-50
}

Make sure the exercises are appropriate for their skill level (${level}/10) and use only equipment from their available list.
Focus on proper form and technique to prevent injuries.
`;
    const client = await getOpenAIClient();
    const response = await client.chat.completions.create({
      model: "gpt-4o",
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
      messages: [
        {
          role: "system",
          content: "You are an expert athletic trainer and strength coach specializing in youth and collegiate athletic development."
        },
        {
          role: "user",
          content: workoutPrompt
        }
      ],
      response_format: { type: "json_object" }
    });
    const workoutPlan = JSON.parse(response.choices[0].message.content || "{}");
    return {
      hasEquipment: true,
      playerLevel: playerProgress2.currentLevel,
      workoutPlan
    };
  } catch (error) {
    console.error("Error generating weight room plan:", error);
    throw new Error(`Failed to generate weight room plan: ${error?.message || "Unknown error"}`);
  }
}
async function getFormFeedback(userId, equipmentId, formDescription) {
  try {
    console.log(`Generating form feedback for user ${userId} using equipment ${equipmentId}`);
    const equipment = await storage.getWeightRoomEquipmentById(equipmentId);
    if (!equipment) {
      throw new Error("Equipment not found");
    }
    const feedbackPrompt = `
You are a professional strength and conditioning coach providing feedback on a student athlete's weight room form.

EQUIPMENT BEING USED:
Name: ${equipment.name}
Category: ${equipment.equipmentType}
Difficulty Level: ${equipment.difficultyLevel}/10

ATHLETE'S FORM DESCRIPTION:
${formDescription}

TASK:
Provide detailed, constructive feedback on the athlete's form when using this equipment.

Your feedback should include:
1. Overall form quality assessment (on a scale of 1-10)
2. What they're doing correctly
3. 2-3 specific form corrections they should make
4. How proper form will improve their results and reduce injury risk
5. One advanced tip they can focus on once they master the basics

Return your response as a JSON object with the following structure:
{
  "formScore": number between 1-10,
  "strengths": ["What they're doing well", ...],
  "corrections": ["Specific correction 1", "Specific correction 2", ...],
  "safetyTip": "Important safety consideration",
  "advancedTip": "One advanced technique to focus on later",
  "overallFeedback": "Summary feedback paragraph"
}

Be encouraging but honest - this is a student athlete who wants to improve, not a professional.
`;
    const client = await getOpenAIClient();
    const response = await client.chat.completions.create({
      model: "gpt-4o",
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
      messages: [
        {
          role: "system",
          content: "You are an expert strength and conditioning coach specializing in proper form and technique for student athletes."
        },
        {
          role: "user",
          content: feedbackPrompt
        }
      ],
      response_format: { type: "json_object" }
    });
    const feedback = JSON.parse(response.choices[0].message.content || "{}");
    const xpAmount = Math.floor(10 + (feedback.formScore || 5) * 2);
    await storage.addXpToPlayer(
      userId,
      xpAmount,
      "form_feedback",
      `Form feedback for ${equipment.name}`,
      String(equipmentId)
    );
    return {
      equipment: {
        id: equipment.id,
        name: equipment.name,
        category: equipment.equipmentType
      },
      feedback,
      xpAwarded: xpAmount
    };
  } catch (error) {
    console.error("Error generating form feedback:", error);
    throw new Error(`Failed to generate form feedback: ${error?.message || "Unknown error"}`);
  }
}
async function verifyWorkoutVideo(verificationId, videoPath) {
  try {
    console.log(`Verifying workout video for verification ID: ${verificationId} at path: ${videoPath}`);
    const verification = await storage.getWorkoutVerification(verificationId);
    if (!verification) {
      throw new Error("Workout verification not found");
    }
    const checkpoints = await storage.getWorkoutVerificationCheckpoints(verificationId);
    if (!checkpoints || checkpoints.length === 0) {
      throw new Error("No checkpoints found for this verification");
    }
    const videoDescription = `The video shows an athlete performing a ${verification.title} workout. 
    The video lasts for ${verification.duration || "unknown"} minutes.
    The exercise being performed is ${checkpoints[0]?.exerciseName || "unknown"}.
    The target amount is ${checkpoints[0]?.targetAmount || "unknown"} reps.`;
    const messages2 = [
      {
        role: "system",
        content: `You are an AI sports coach that specializes in analyzing workout videos. 
        Your task is to count repetitions, analyze technique, measure distance and speed,
        and provide feedback on the workout. Be specific about what you observe and provide
        constructive feedback for improvement. You always return a JSON object with the following fields:
        - isCompleted: boolean indicating if the workout was completed successfully
        - completedAmount: number of reps completed or distance covered
        - targetAmount: target number of reps or distance
        - repAccuracy: number from 0-100 indicating the accuracy/quality of the reps
        - feedback: string with detailed feedback about form, technique, and suggestions
        - motionAnalysis: object with detailed analysis of the motion including:
          - posture: rating from 0-100
          - formConsistency: rating from 0-100
          - power: rating from 0-100
          - speed: rating from 0-100
          - keyIssues: array of strings describing key issues
          - strengths: array of strings describing key strengths
        `
      },
      {
        role: "user",
        content: `Please analyze this workout video: ${videoDescription}
        
        For this simulation, assume the athlete is performing ${checkpoints[0]?.exerciseName || "push-ups"} with 
        a target of ${checkpoints[0]?.targetAmount || "20"} repetitions.
        
        Generate a detailed analysis including rep counting, technique assessment, and feedback.`
      }
    ];
    const client = await getOpenAIClient();
    const completionResponse = await client.chat.completions.create({
      model: "gpt-4o",
      messages: messages2,
      temperature: 0.2,
      max_tokens: 1e3,
      response_format: { type: "json_object" }
    });
    const responseContent = completionResponse.choices[0]?.message?.content || "{}";
    console.log(`OpenAI response for workout verification: ${responseContent}`);
    try {
      const analysis = JSON.parse(responseContent);
      return {
        isCompleted: analysis.isCompleted || false,
        completedAmount: analysis.completedAmount || 0,
        targetAmount: analysis.targetAmount || 0,
        repAccuracy: analysis.repAccuracy || 0,
        feedback: analysis.feedback || "Unable to provide detailed feedback",
        motionAnalysis: analysis.motionAnalysis || {
          posture: 0,
          formConsistency: 0,
          power: 0,
          speed: 0,
          keyIssues: ["Unable to analyze motion"],
          strengths: []
        }
      };
    } catch (error) {
      console.error("Error parsing OpenAI response:", error);
      return {
        isCompleted: false,
        completedAmount: 0,
        targetAmount: checkpoints[0]?.targetAmount || 0,
        repAccuracy: 0,
        feedback: "Error analyzing workout video. Please try again or contact support.",
        motionAnalysis: {
          posture: 0,
          formConsistency: 0,
          power: 0,
          speed: 0,
          keyIssues: ["Error in analysis"],
          strengths: []
        }
      };
    }
  } catch (error) {
    console.error("Error in verifyWorkoutVideo:", error);
    throw new Error("Failed to verify workout video");
  }
}
var openai;
var init_openai = __esm({
  "server/openai.ts"() {
    "use strict";
    init_storage();
    init_openai_service();
    console.log("Using OpenAI service for all OpenAI API calls");
    (async () => {
      try {
        openai = await getOpenAIClient();
      } catch (error) {
        console.error("Failed to initialize OpenAI client:", error);
        openai = new OpenAI2({ apiKey: "dummy_key_for_initialization" });
      }
    })();
  }
});

// server/utils.ts
function generateSlug(text2) {
  return text2.toString().toLowerCase().trim().replace(/\s+/g, "-").replace(/&/g, "-and-").replace(/[^\w\-]+/g, "").replace(/\-\-+/g, "-").replace(/^-+/, "").replace(/-+$/, "");
}
var init_utils = __esm({
  "server/utils.ts"() {
    "use strict";
  }
});

// server/services/image-search-service.ts
import axios2 from "axios";
var ImageSearchService, imageSearchService;
var init_image_search_service = __esm({
  "server/services/image-search-service.ts"() {
    "use strict";
    ImageSearchService = class {
      unsplashApiKey = null;
      pixabayApiKey = null;
      pexelsApiKey = null;
      constructor() {
        this.initializeApiKeys();
      }
      /**
       * Initialize API keys from database
       */
      async initializeApiKeys() {
        try {
          this.unsplashApiKey = null;
          this.pixabayApiKey = null;
          this.pexelsApiKey = null;
        } catch (error) {
          console.error("Failed to load image API keys:", error);
        }
      }
      /**
       * Get a sports-related image URL based on search terms
       * Tries multiple free image APIs and falls back as needed
       * 
       * @param searchTerms Terms to search for (e.g. "football quarterback")
       * @returns URL of a relevant image or null if none found
       */
      async getSportsImage(searchTerms) {
        const sportsSearchTerms = `sports ${searchTerms}`;
        if (this.unsplashApiKey) {
          try {
            const image = await this.searchUnsplash(sportsSearchTerms);
            if (image) return image;
          } catch (error) {
            console.error("Unsplash search failed:", error);
          }
        }
        if (this.pixabayApiKey) {
          try {
            const image = await this.searchPixabay(sportsSearchTerms);
            if (image) return image;
          } catch (error) {
            console.error("Pixabay search failed:", error);
          }
        }
        if (this.pexelsApiKey) {
          try {
            const image = await this.searchPexels(sportsSearchTerms);
            if (image) return image;
          } catch (error) {
            console.error("Pexels search failed:", error);
          }
        }
        return this.getSportsPlaceholder();
      }
      /**
       * Search Unsplash for an image
       * 
       * @param query Search terms
       * @returns Image URL or null
       */
      async searchUnsplash(query) {
        const response = await axios2.get("https://api.unsplash.com/search/photos", {
          params: {
            query,
            per_page: 1,
            orientation: "landscape"
          },
          headers: {
            Authorization: `Client-ID ${this.unsplashApiKey}`
          }
        });
        if (response.data.results && response.data.results.length > 0) {
          return response.data.results[0].urls.regular;
        }
        return null;
      }
      /**
       * Search Pixabay for an image
       * 
       * @param query Search terms
       * @returns Image URL or null
       */
      async searchPixabay(query) {
        const response = await axios2.get("https://pixabay.com/api/", {
          params: {
            key: this.pixabayApiKey,
            q: query,
            image_type: "photo",
            orientation: "horizontal",
            per_page: 1
          }
        });
        if (response.data.hits && response.data.hits.length > 0) {
          return response.data.hits[0].webformatURL;
        }
        return null;
      }
      /**
       * Search Pexels for an image
       * 
       * @param query Search terms
       * @returns Image URL or null
       */
      async searchPexels(query) {
        const response = await axios2.get("https://api.pexels.com/v1/search", {
          params: {
            query,
            per_page: 1,
            orientation: "landscape"
          },
          headers: {
            Authorization: this.pexelsApiKey
          }
        });
        if (response.data.photos && response.data.photos.length > 0) {
          return response.data.photos[0].src.large;
        }
        return null;
      }
      /**
       * Get a generic sports placeholder image
       * Uses free sports images from public sources
       * 
       * @returns URL to a generic sports image
       */
      getSportsPlaceholder() {
        const placeholders = [
          "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=800",
          // Stadium
          "https://images.unsplash.com/photo-1535131749006-b7f58c99034b?w=800",
          // Basketball
          "https://images.unsplash.com/photo-1560272564-c83b66b1ad12?w=800",
          // Running
          "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=800",
          // Football
          "https://images.unsplash.com/photo-1614632537190-23e4146777db?w=800"
          // Soccer
        ];
        return placeholders[Math.floor(Math.random() * placeholders.length)];
      }
    };
    imageSearchService = new ImageSearchService();
  }
});

// server/blog-generator.ts
var blog_generator_exports = {};
__export(blog_generator_exports, {
  createAIBlogPost: () => createAIBlogPost,
  generateBlogPost: () => generateBlogPost,
  initializeBlogGeneration: () => initializeBlogGeneration,
  scheduleDailyBlogPosts: () => scheduleDailyBlogPosts
});
import { OpenAI as OpenAI3 } from "openai";
import { eq as eq5 } from "drizzle-orm";
import cron from "node-cron";
import axios3 from "axios";
async function getOpenAIClient2() {
  try {
    return await openAIService.getClient();
  } catch (error) {
    console.error("Error getting OpenAI client:", error);
    return new OpenAI3({
      apiKey: process.env.OPENAI_API_KEY || ""
    });
  }
}
async function fetchTwitterTrends() {
  try {
    if (!TWITTER_BEARER_TOKEN) {
      console.log("Twitter API token not configured, skipping Twitter trends");
      return [];
    }
    const response = await axios3.get("https://api.twitter.com/2/trends/place?id=1", {
      headers: {
        "Authorization": `Bearer ${TWITTER_BEARER_TOKEN}`
      }
    });
    const trends = [];
    const sportKeywords = SPORTS_TO_TRACK.map((sport) => sport.toLowerCase());
    if (response.data && response.data[0] && response.data[0].trends) {
      response.data[0].trends.forEach((trend) => {
        const trendName = trend.name.toLowerCase();
        const isSportsRelated = sportKeywords.some(
          (keyword) => trendName.includes(keyword)
        );
        if (isSportsRelated) {
          trends.push({
            topic: trend.name,
            volume: trend.tweet_volume || 0,
            source: "twitter"
          });
        }
      });
    }
    return trends.slice(0, 5);
  } catch (error) {
    console.error("Error fetching Twitter trends:", error);
    return [];
  }
}
async function fetchRedditTrends() {
  try {
    if (!REDDIT_CLIENT_ID || !REDDIT_CLIENT_SECRET) {
      console.log("Reddit API credentials not configured, skipping Reddit trends");
      return [];
    }
    const tokenResponse = await axios3.post(
      "https://www.reddit.com/api/v1/access_token",
      `grant_type=client_credentials`,
      {
        auth: {
          username: REDDIT_CLIENT_ID,
          password: REDDIT_CLIENT_SECRET
        },
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        }
      }
    );
    const accessToken = tokenResponse.data.access_token;
    const sportsSubreddits = [
      "sports",
      "basketball",
      "football",
      "soccer",
      "baseball",
      "volleyball",
      "trackandfield",
      "swimming",
      // Additional soccer subreddits
      "MLS",
      "ussoccer",
      "MLSNextPro",
      "NWSL",
      "collegesoccer",
      // Recruiting and college sports
      "CFB",
      "CollegeBasketball",
      "recruiting",
      "NCAAW",
      // Transfer portal related
      "CollegeFootballRisk",
      "CFBTransfers"
    ];
    const trendingTopics = [];
    for (const subreddit of sportsSubreddits) {
      const response = await axios3.get(
        `https://oauth.reddit.com/r/${subreddit}/hot?limit=5`,
        {
          headers: {
            "Authorization": `Bearer ${accessToken}`,
            "User-Agent": "NextUpAI/1.0.0"
          }
        }
      );
      if (response.data && response.data.data && response.data.data.children) {
        response.data.data.children.forEach((post) => {
          trendingTopics.push({
            topic: post.data.title,
            volume: post.data.score || 0,
            source: `reddit/${subreddit}`
          });
        });
      }
    }
    return trendingTopics.sort((a, b) => b.volume - a.volume).slice(0, 10);
  } catch (error) {
    console.error("Error fetching Reddit trends:", error);
    return [];
  }
}
async function fetchSportsNews() {
  try {
    console.log("Fetching headlines from sports news sites...");
    const currentHeadlines = [
      // ESPN headlines
      { topic: "Top 5-Star Recruits Announce College Decisions", volume: 950, source: "ESPN" },
      { topic: "Transfer Portal Activity Heats Up After Spring Games", volume: 850, source: "ESPN" },
      // Sports Illustrated
      { topic: "Rising Soccer Stars Making Waves in MLS Youth Academies", volume: 780, source: "Sports Illustrated" },
      { topic: "How NIL is Changing the Game for High School Athletes", volume: 920, source: "Sports Illustrated" },
      // 247Sports
      { topic: "Breaking Down the Latest Football Recruiting Rankings", volume: 830, source: "247Sports" },
      { topic: "Basketball Recruiting: Summer Circuit Preview", volume: 760, source: "247Sports" },
      // Rivals
      { topic: "Under-the-Radar Prospects Gaining Attention", volume: 710, source: "Rivals" },
      { topic: "Top Performers from Regional Combines", volume: 680, source: "Rivals" },
      // Transfer Portal
      { topic: "Impact Transfers to Watch This Season", volume: 890, source: "Transfer Portal" },
      { topic: "Portal Deadline Approaches: Who's Still Available", volume: 800, source: "Transfer Portal" },
      // Soccer coverage
      { topic: "Youth Soccer Development Pathways Expanding in US", volume: 730, source: "Soccer America" },
      { topic: "MLS Next Pro Creating New Opportunities for Young Players", volume: 770, source: "MLS" },
      { topic: "International Soccer Academies Recruiting American Talent", volume: 820, source: "Goal.com" }
    ];
    return currentHeadlines;
  } catch (error) {
    console.error("Error fetching sports news headlines:", error);
    return [];
  }
}
async function getTrendingSportsTopics() {
  try {
    console.log("Fetching trending topics from social media and news sites...");
    const [twitterTrends, redditTrends, sportsNews] = await Promise.all([
      fetchTwitterTrends(),
      fetchRedditTrends(),
      fetchSportsNews()
    ]);
    const allTrends = [...twitterTrends, ...redditTrends, ...sportsNews];
    const topTrends = allTrends.sort((a, b) => b.volume - a.volume).slice(0, 20);
    console.log(`Found ${topTrends.length} trending sports topics`);
    return topTrends.map((trend) => trend.topic);
  } catch (error) {
    console.error("Error getting trending sports topics:", error);
    return [];
  }
}
async function generateBlogPost() {
  try {
    const trendingTopics = await getTrendingSportsTopics();
    const randomTopic = BLOG_TOPICS[Math.floor(Math.random() * BLOG_TOPICS.length)];
    const randomCategory = BLOG_CATEGORIES[Math.floor(Math.random() * BLOG_CATEGORIES.length)];
    console.log(`Generating blog post about: ${randomTopic} (${randomCategory})`);
    const blogRequest = {
      title: randomTopic,
      category: randomCategory,
      trendingTopics: trendingTopics.length > 0 ? trendingTopics : void 0
    };
    let userPrompt = `Write a blog post about "${blogRequest.title}" for the category "${blogRequest.category}".`;
    if (blogRequest.trendingTopics && blogRequest.trendingTopics.length > 0) {
      userPrompt += `

Incorporate some of these current trending topics if relevant:
      ${blogRequest.trendingTopics.slice(0, 5).map((topic) => `- ${topic}`).join("\n")}`;
    }
    userPrompt += `

Format your response as a JSON object with the following structure:
                    {
                      "title": "An engaging title for the blog post",
                      "content": "Full blog post content with proper formatting (at least 500 words)",
                      "summary": "A brief summary (about 50 words)",
                      "tags": ["tag1", "tag2", "tag3"]
                    }
                    Make the content informative, engaging, and professional.`;
    const openai4 = await getOpenAIClient2();
    const completion = await openai4.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: `You are an expert sports journalist specializing in youth and collegiate athletics. 
                    Write high-quality, informative content for young athletes, coaches, and parents.
                    Focus on providing actionable advice, insights, and analysis.
                    Stay current with the latest trends and developments in sports.
                    Your articles should feel relevant and timely.`
        },
        {
          role: "user",
          content: userPrompt
        }
      ],
      temperature: 0.7,
      max_tokens: 2e3
    });
    const responseContent = completion.choices[0]?.message?.content || "";
    try {
      const jsonMatch = responseContent.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const jsonContent = JSON.parse(jsonMatch[0]);
        return {
          title: jsonContent.title,
          content: jsonContent.content,
          summary: jsonContent.summary,
          category: blogRequest.category,
          tags: jsonContent.tags
        };
      }
    } catch (error) {
      console.error("Error parsing AI response:", error);
      console.log("Raw response:", responseContent);
    }
    return null;
  } catch (error) {
    console.error("Error generating blog post:", error);
    return null;
  }
}
async function createAIBlogPost(authorId) {
  try {
    try {
      await openAIService.hasValidApiKey();
    } catch (error) {
      console.error("OpenAI API key not available:", error);
      return false;
    }
    const blogContent = await generateBlogPost();
    if (!blogContent) {
      console.error("Failed to generate blog content");
      return false;
    }
    const slug = generateSlug(blogContent.title);
    let coverImage;
    try {
      console.log(`Finding image for blog post: "${blogContent.title}"`);
      const searchTerms = `${blogContent.category} ${blogContent.tags.slice(0, 3).join(" ")}`;
      coverImage = await imageSearchService.getSportsImage(searchTerms);
      console.log(`Found image URL: ${coverImage}`);
    } catch (error) {
      console.error("Error finding blog image:", error);
      coverImage = null;
    }
    const blogData = {
      title: blogContent.title,
      content: blogContent.content,
      summary: blogContent.summary,
      slug,
      category: blogContent.category,
      authorId,
      publishDate: /* @__PURE__ */ new Date(),
      featured: Math.random() > 0.8,
      // 20% chance of being featured
      tags: blogContent.tags,
      coverImage
    };
    const validatedData = insertBlogPostSchema.parse(blogData);
    await db.insert(blogPosts).values(validatedData);
    console.log(`Created new AI blog post: "${blogContent.title}"`);
    return true;
  } catch (error) {
    console.error("Error creating AI blog post:", error);
    return false;
  }
}
function scheduleDailyBlogPosts(adminUserId) {
  cron.schedule("0 8 * * *", async () => {
    try {
      console.log("Running scheduled blog post generation...");
      await createAIBlogPost(adminUserId);
    } catch (error) {
      console.error("Error in scheduled blog post generation:", error);
    }
  });
  console.log("Daily blog post generation scheduled successfully");
}
async function initializeBlogGeneration() {
  try {
    const adminUsersResult = await db.select().from(users).where(eq5(users.role, "admin")).limit(1);
    if (!adminUsersResult || adminUsersResult.length === 0) {
      console.error("No admin user found to use as blog author");
      return;
    }
    const adminUserId = adminUsersResult[0].id;
    await createAIBlogPost(adminUserId);
    scheduleDailyBlogPosts(adminUserId);
  } catch (error) {
    console.error("Error initializing blog generation:", error);
  }
}
var TWITTER_BEARER_TOKEN, REDDIT_CLIENT_ID, REDDIT_CLIENT_SECRET, BLOG_CATEGORIES, BLOG_TOPICS, SPORTS_TO_TRACK;
var init_blog_generator = __esm({
  "server/blog-generator.ts"() {
    "use strict";
    init_db();
    init_schema();
    init_utils();
    init_openai_service();
    init_image_search_service();
    TWITTER_BEARER_TOKEN = process.env.TWITTER_API_KEY || "";
    REDDIT_CLIENT_ID = process.env.REDDIT_CLIENT_ID || "";
    REDDIT_CLIENT_SECRET = process.env.REDDIT_CLIENT_SECRET || "";
    BLOG_CATEGORIES = [
      "training",
      "recruiting",
      "nutrition",
      "mental-training",
      "technology",
      "nextup",
      "analysis",
      "combine",
      "tips",
      "ncaa"
    ];
    BLOG_TOPICS = [
      // General athletic development
      "Latest training techniques for high school athletes",
      "How college recruiters are using AI to find talent",
      "Nutrition plans for young athletes in development",
      "Mental preparation strategies for big games",
      "Using technology to improve athletic performance",
      "Rising stars in high school sports to watch",
      "Technical analysis of sport-specific skills",
      "How to prepare for sports combines",
      "Tips for balancing academics and athletics",
      "Navigating NCAA eligibility requirements",
      "Injury prevention strategies for young athletes",
      "The psychology of athletic development",
      "How to create a highlight reel that gets noticed",
      "The role of parents in youth sports development",
      "Sport-specific training programs for off-season",
      "Recovery techniques for high-intensity training",
      "Recruiting timelines for different sports",
      "Social media strategies for athlete visibility",
      "Strength training for different sports and positions",
      "The impact of specialization vs. multi-sport participation",
      // Soccer specific topics
      "Soccer skills development for youth players",
      "College soccer recruiting: What coaches look for",
      "MLS academies and pathways to professional soccer",
      "International soccer opportunities for American youth players",
      "Soccer position-specific training for midfielders",
      "Goalkeeper training and development programs",
      "Soccer speed and agility drills for forwards",
      "Defensive tactics and training for youth soccer",
      "Soccer IQ: Developing game intelligence in young players",
      // Recruiting and transfer portal
      "Understanding the transfer portal: Benefits and challenges",
      "How college coaches evaluate recruits from social media",
      "NIL opportunities for high school athletes",
      "Standing out in the recruiting process: Beyond stats",
      "Comparing scholarship offers across different programs",
      "Recruiting red flags: What to watch out for",
      "Maximizing exposure at showcases and combines",
      "Building relationships with college coaches",
      "Navigating the recruiting journey as a parent",
      // Additional sports topics from major outlets
      "ESPN top prospects to watch this season",
      "Sports Illustrated youth athlete development model",
      "247Sports recruiting rankings: What they mean for athletes",
      "Rivals analysis of underrated recruits",
      "Transfer portal trends reshaping college sports"
    ];
    SPORTS_TO_TRACK = [
      "basketball",
      "football",
      "soccer",
      "baseball",
      "volleyball",
      "track",
      "swimming",
      "tennis",
      "golf",
      "wrestling",
      "gymnastics",
      "lacrosse",
      // Additional soccer-specific terms
      "mls",
      "premier league",
      "fifa",
      "uefa",
      "champions league",
      "world cup",
      "concacaf",
      "midfielder",
      "striker",
      "goalkeeper",
      "forward",
      "defender",
      // Transfer portal related
      "transfer portal",
      "recruit",
      "commitment",
      "signing day",
      "prospect",
      "five-star",
      "four-star",
      "rankings"
    ];
  }
});

// server/generate-athlete-profiles.ts
var generate_athlete_profiles_exports = {};
__export(generate_athlete_profiles_exports, {
  generateProfiles: () => generateProfiles
});
import fs6 from "fs";
import path7 from "path";
import { v4 as uuidv44 } from "uuid";
import { eq as eq6 } from "drizzle-orm";
async function generateProfiles() {
  try {
    console.log("Starting athlete profile generation...");
    const existingProfiles = await db.select().from(athleteStarProfiles);
    if (existingProfiles.length > 0) {
      console.log(`Found ${existingProfiles.length} existing athlete profiles. Skipping generation.`);
      return existingProfiles;
    }
    const extractDir = path7.join(process.cwd(), "..", "temp_extract");
    if (!fs6.existsSync(extractDir)) {
      console.error("Extract directory not found. Please unzip the athlete profiles first.");
      return [];
    }
    console.log(`Using extract directory: ${extractDir}`);
    const files = fs6.readdirSync(extractDir).filter((file) => file.endsWith(".json"));
    console.log(`Found ${files.length} athlete profile JSON files to process.`);
    const batchSize = 5;
    const generatedProfiles = [];
    for (let i = 0; i < files.length; i += batchSize) {
      const batch = files.slice(i, i + batchSize);
      console.log(`Processing batch ${Math.floor(i / batchSize) + 1} of ${Math.ceil(files.length / batchSize)}...`);
      const batchPromises = batch.map(async (filename) => {
        const filePath = path7.join(extractDir, filename);
        const profileData = JSON.parse(fs6.readFileSync(filePath, "utf8"));
        const username = `${profileData.sport.toLowerCase().substring(0, 3)}_${profileData.position.toLowerCase().substring(0, 3)}_${profileData.star_level}star_${uuidv44().substring(0, 4)}`;
        const email = `${username}@athlete.getverified.com`;
        const password = await hashPassword("Password123!");
        const [user] = await db.insert(users).values({
          username,
          password,
          email,
          name: profileData.name,
          role: "athlete",
          bio: `${profileData.star_level}-star ${profileData.position} in ${profileData.sport}. ${profileData.rank || ""}`
        }).returning();
        console.log(`Created user account for ${profileData.name}`);
        const avatarPath = `/uploads/default_avatar_${Math.floor(Math.random() * 5) + 1}.png`;
        console.log(`Using default avatar for ${profileData.name}`);
        await db.update(users).set({ profileImage: avatarPath }).where(eq6(users.id, user.id));
        const [profile] = await db.insert(athleteStarProfiles).values({
          profileId: profileData.id,
          userId: user.id,
          name: profileData.name,
          starLevel: profileData.star_level,
          sport: profileData.sport,
          position: profileData.position,
          ageGroup: profileData.age_group,
          metrics: profileData.metrics,
          traits: profileData.traits,
          filmExpectations: profileData.film_expectations,
          trainingFocus: profileData.training_focus,
          avatar: avatarPath,
          rank: profileData.rank,
          xpLevel: profileData.xp_level,
          active: true
        }).returning();
        console.log(`Created athlete star profile for ${profileData.name}`);
        return profile;
      });
      const batchResults = await Promise.all(batchPromises);
      generatedProfiles.push(...batchResults);
      if (i + batchSize < files.length) {
        console.log("Waiting 2 seconds before processing next batch...");
        await new Promise((resolve) => setTimeout(resolve, 2e3));
      }
    }
    console.log(`Successfully generated ${generatedProfiles.length} athlete profiles with default avatars.`);
    return generatedProfiles;
  } catch (error) {
    console.error("Error generating athlete profiles:", error);
    throw error;
  }
}
var init_generate_athlete_profiles = __esm({
  "server/generate-athlete-profiles.ts"() {
    "use strict";
    init_db();
    init_schema();
    init_auth();
    generateProfiles().then(() => {
      console.log("Athlete profile generation completed.");
      process.exit(0);
    }).catch((error) => {
      console.error("Athlete profile generation failed:", error);
      process.exit(1);
    });
  }
});

// server/index.ts
import express2 from "express";

// server/routes.ts
init_storage();
import { createServer } from "http";

// server/file-upload.ts
import multer from "multer";
import fs4 from "fs";
import path5 from "path";
import { v4 as uuidv42 } from "uuid";
var storage2 = multer.diskStorage({
  destination: (req, file, cb) => {
    const category = req.body.category || "default";
    const categoryPath = path5.join(process.cwd(), "uploads", category);
    if (!fs4.existsSync(categoryPath)) {
      fs4.mkdirSync(categoryPath, { recursive: true });
    }
    cb(null, categoryPath);
  },
  filename: (req, file, cb) => {
    const uniqueFilename = `${Date.now()}-${uuidv42()}${path5.extname(file.originalname)}`;
    cb(null, uniqueFilename);
  }
});
var imageFileFilter = (req, file, cb) => {
  if (file.mimetype.startsWith("image/")) {
    cb(null, true);
  } else {
    cb(new Error("Only image files are allowed"));
  }
};
var videoFileFilter = (req, file, cb) => {
  if (file.mimetype.startsWith("video/")) {
    cb(null, true);
  } else {
    cb(new Error("Only video files are allowed"));
  }
};
var fileUpload = multer({
  storage: storage2,
  limits: {
    fileSize: 500 * 1024 * 1024
    // 500MB limit for videos
  }
});
var videoUpload = multer({
  storage: storage2,
  fileFilter: videoFileFilter,
  limits: {
    fileSize: 500 * 1024 * 1024
    // 500MB limit for videos
  }
});
var imageUpload = multer({
  storage: storage2,
  fileFilter: imageFileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024
    // 5MB limit for images
  }
});
var getUploadedImages = (category) => {
  return new Promise((resolve, reject) => {
    try {
      const uploadsDir2 = path5.join(process.cwd(), "uploads");
      let categories;
      if (category) {
        categories = [category];
      } else {
        categories = fs4.readdirSync(uploadsDir2).filter((item) => {
          const itemPath = path5.join(uploadsDir2, item);
          return fs4.statSync(itemPath).isDirectory();
        });
      }
      const allImages = categories.flatMap((cat) => {
        const categoryPath = path5.join(uploadsDir2, cat);
        if (!fs4.existsSync(categoryPath)) {
          return [];
        }
        return fs4.readdirSync(categoryPath).filter((file) => {
          const extension = path5.extname(file).toLowerCase();
          return [".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".svg"].includes(extension);
        }).map((file) => {
          const filePath = `${cat}/${file}`;
          return {
            path: filePath,
            url: `/uploads/${filePath}`,
            filename: file,
            category: cat
          };
        });
      });
      resolve(allImages);
    } catch (error) {
      reject(error);
    }
  });
};
var deleteImage = (imagePath) => {
  return new Promise((resolve, reject) => {
    try {
      const fullPath = path5.join(process.cwd(), "uploads", imagePath);
      if (!fs4.existsSync(fullPath)) {
        reject(new Error("Image does not exist"));
        return;
      }
      fs4.unlink(fullPath, (err) => {
        if (err) {
          reject(err);
          return;
        }
        resolve(true);
      });
    } catch (error) {
      reject(error);
    }
  });
};

// server/routes.ts
init_openai();
import fs7 from "fs";

// server/active-network.ts
init_db();
init_schema();
import axios from "axios";
import { eq as eq4 } from "drizzle-orm";
var ActiveNetworkService = class {
  config;
  axios;
  constructor(config) {
    this.config = config;
    this.axios = axios.create({
      baseURL: config.baseUrl,
      headers: {
        "Authorization": `Bearer ${config.apiKey}`,
        "Content-Type": "application/json",
        "X-Organization-Id": config.orgId
      }
    });
  }
  /**
   * Create an event in Active Network
   * @param eventData Event details
   * @returns Created event data from Active Network
   */
  async createEvent(eventData) {
    try {
      return {
        id: `active-event-${Date.now()}`,
        name: eventData.name,
        status: "active",
        registrationUrl: `https://www.active.com/register/${eventData.name.toLowerCase().replace(/\s+/g, "-")}`
      };
    } catch (error) {
      console.error("Error creating event in Active Network:", error);
      throw error;
    }
  }
  /**
   * Get registration URL for a specific event
   * @param eventId The ID of the event in our system
   * @returns Registration URL from Active Network
   */
  async getRegistrationUrl(eventId) {
    try {
      const [event] = await db.select().from(combineTourEvents).where(eq4(combineTourEvents.id, eventId));
      if (!event) {
        throw new Error(`Event with ID ${eventId} not found`);
      }
      if (event.activeNetworkId) {
        return {
          registrationUrl: event.registrationUrl || `https://www.active.com/register/${event.slug}`,
          activeNetworkId: event.activeNetworkId
        };
      }
      return {
        registrationUrl: `https://www.active.com/register/${event.slug}`,
        activeNetworkId: `active-event-${Date.now()}`
      };
    } catch (error) {
      console.error("Error getting registration URL from Active Network:", error);
      throw error;
    }
  }
  /**
   * Check registration status for a user
   * @param userId The user ID
   * @param eventId The event ID
   * @returns Registration status
   */
  async checkRegistrationStatus(userId, eventId) {
    try {
      const [registration] = await db.select().from(registrations).where(eq4(registrations.userId, userId) && eq4(registrations.eventId, eventId));
      return {
        registered: !!registration,
        registrationId: registration?.id,
        status: registration?.status || "not_registered",
        paymentStatus: registration?.paymentStatus || "unpaid"
      };
    } catch (error) {
      console.error("Error checking registration status:", error);
      throw error;
    }
  }
  /**
   * Process a webhook from Active Network (for payment confirmations, etc.)
   * @param webhookData Data received from Active Network webhook
   * @returns Processing result
   */
  async processWebhook(webhookData) {
    try {
      const { event, data } = webhookData;
      switch (event) {
        case "registration.completed":
          await this.updateRegistrationStatus(data);
          break;
        case "payment.completed":
          await this.updatePaymentStatus(data);
          break;
        default:
          console.log(`Unhandled webhook event: ${event}`);
      }
      return { success: true, event };
    } catch (error) {
      console.error("Error processing Active Network webhook:", error);
      throw error;
    }
  }
  /**
   * Update registration status in our database
   * @param data Registration data from Active Network
   */
  async updateRegistrationStatus(data) {
    const { registrationId, status, userId, eventId } = data;
    const [existingRegistration] = await db.select().from(registrations).where(eq4(registrations.externalId, registrationId));
    if (existingRegistration) {
      await db.update(registrations).set({ status }).where(eq4(registrations.id, existingRegistration.id));
    } else {
      await db.insert(registrations).values({
        userId,
        eventId,
        status,
        externalId: registrationId,
        registeredAt: /* @__PURE__ */ new Date(),
        paymentStatus: "pending"
      });
    }
  }
  /**
   * Update payment status in our database
   * @param data Payment data from Active Network
   */
  async updatePaymentStatus(data) {
    const { registrationId, paymentId, amount, status } = data;
    const [registration] = await db.select().from(registrations).where(eq4(registrations.externalId, registrationId));
    if (!registration) {
      throw new Error(`Registration with external ID ${registrationId} not found`);
    }
    await db.update(registrations).set({ paymentStatus: status }).where(eq4(registrations.id, registration.id));
    await db.insert(payments).values({
      registrationId: registration.id,
      amount,
      externalId: paymentId,
      status,
      processedAt: /* @__PURE__ */ new Date()
    });
  }
  /**
   * Get details about an Active Network event
   * @param activeNetworkId The ID of the event in Active Network
   * @returns Event details
   */
  async getEventDetails(activeNetworkId) {
    try {
      return {
        id: activeNetworkId,
        name: "Combine Tour Event",
        description: "Basketball combine event for high school athletes",
        location: "Main Sports Complex, Los Angeles",
        startDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1e3),
        // 7 days from now
        endDate: new Date(Date.now() + 8 * 24 * 60 * 60 * 1e3),
        // 8 days from now
        status: "active",
        capacity: 100,
        registeredCount: 45,
        fee: 99.99,
        registrationDeadline: new Date(Date.now() + 5 * 24 * 60 * 60 * 1e3)
        // 5 days from now
      };
    } catch (error) {
      console.error("Error fetching event details from Active Network:", error);
      throw error;
    }
  }
};
var activeNetworkService = new ActiveNetworkService({
  apiKey: process.env.ACTIVE_NETWORK_API_KEY || "demo-api-key",
  orgId: process.env.ACTIVE_NETWORK_ORG_ID || "demo-org-id",
  baseUrl: process.env.ACTIVE_NETWORK_BASE_URL || "https://api.active.com/v1"
});
var active_network_default = activeNetworkService;

// server/routes.ts
init_db();
init_auth();
import { eq as eq7 } from "drizzle-orm";
import multer2 from "multer";
import path8 from "path";
import { WebSocketServer } from "ws";
import passport2 from "passport";

// server/api-keys.ts
init_storage();
import { z as z2 } from "zod";
var apiKeySchema = z2.object({
  keyType: z2.enum(["openai", "stripe", "sendgrid", "twilio", "google", "aws", "active", "twitter", "reddit_client_id", "reddit_client_secret"]),
  keyValue: z2.string().min(5)
});
var openaiKeyValidator = (key) => {
  return key.startsWith("sk-") && key.length > 20;
};
var setEnvironmentVariable = (key, value) => {
  process.env[key] = value;
  console.log(`Environment variable ${key} has been set.`);
};
var getEnvKeyName = (keyType) => {
  const keyMap = {
    openai: "OPENAI_API_KEY",
    stripe: "STRIPE_SECRET_KEY",
    sendgrid: "SENDGRID_API_KEY",
    twilio: "TWILIO_AUTH_TOKEN"
  };
  return keyMap[keyType] || keyType.toUpperCase() + "_API_KEY";
};
var saveApiKey = async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    const result = apiKeySchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({
        message: "Invalid request data",
        errors: result.error.format()
      });
    }
    const { keyType, keyValue } = result.data;
    if (keyType === "openai" && !openaiKeyValidator(keyValue)) {
      return res.status(400).json({
        message: "Invalid OpenAI API key format. OpenAI keys should start with 'sk-'"
      });
    }
    await storage.saveApiKey({
      keyType,
      keyValue,
      isActive: true
    });
    const envKey = getEnvKeyName(keyType);
    setEnvironmentVariable(envKey, keyValue);
    return res.status(200).json({ message: `${keyType} API key saved successfully` });
  } catch (error) {
    console.error("Error saving API key:", error);
    return res.status(500).json({ message: "Error saving API key" });
  }
};
var getApiKeyStatus = async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    const keyStatus = await storage.getApiKeyStatus();
    return res.status(200).json(keyStatus);
  } catch (error) {
    console.error("Error getting API key status:", error);
    return res.status(500).json({ message: "Error getting API key status" });
  }
};

// server/services/football-coach-service.ts
init_openai_service();
init_storage();
var FootballCoachService = class {
  openai = null;
  constructor() {
    console.log("Football Coach Service initialized");
  }
  /**
   * Analyze a football game film comparison
   * @param comparisonId The ID of the film comparison to analyze
   * @returns The updated analysis object with football-specific insights
   */
  async analyzeFootballFilm(comparisonId) {
    try {
      const comparison = await storage.getFilmComparison(comparisonId);
      if (!comparison) {
        throw new Error("Film comparison not found");
      }
      const videos3 = await storage.getComparisonVideos(comparisonId);
      if (!videos3 || videos3.length === 0) {
        throw new Error("No videos found for this comparison");
      }
      let analysis = await storage.getComparisonAnalysis(comparisonId);
      if (!analysis) {
        analysis = await storage.createComparisonAnalysis({
          comparisonId,
          aiGeneratedNotes: "Analyzing football film...",
          similarityScore: 0,
          recommendations: []
        });
      }
      const openai4 = await openAIService.getClient();
      const videoDetails = videos3.map((video) => ({
        id: video.id,
        type: video.videoType || "Unknown",
        notes: video.notes || "",
        athleteName: video.athleteName || "Unknown athlete",
        videoUrl: video.externalVideoUrl || null
      }));
      const analysisResult = await this.generateFootballAnalysis(comparison, videoDetails);
      const updatedAnalysis = await storage.updateComparisonAnalysis(analysis.id, {
        aiGeneratedNotes: analysisResult.aiGeneratedNotes,
        similarityScore: analysisResult.similarityScore || 0,
        recommendations: analysisResult.recommendations || [],
        techniqueBreakdown: analysisResult.techniqueBreakdown || {},
        // Football coach specific fields
        playAssignments: analysisResult.playAssignments || {},
        assignmentGrades: analysisResult.assignmentGrades || {},
        bustedCoverage: analysisResult.bustedCoverage || false,
        bustedCoverageDetails: analysisResult.bustedCoverageDetails || {},
        playerComparisons: analysisResult.playerComparisons || {},
        performanceRating: analysisResult.performanceRating || {},
        recommendedExamples: analysisResult.recommendedExamples || {},
        defenseAnalysis: analysisResult.defenseAnalysis || {}
      });
      await storage.updateFilmComparison(comparisonId, {
        status: "completed"
      });
      return updatedAnalysis;
    } catch (error) {
      console.error("Error analyzing football film:", error);
      return null;
    }
  }
  /**
   * Generate football-specific analysis using OpenAI
   */
  async generateFootballAnalysis(comparison, videos3) {
    try {
      const openai4 = await openAIService.getClient();
      const videoDescriptions = videos3.map(
        (video) => `Video ${video.id} (${video.type}) - Athlete: ${video.athleteName || "Unknown athlete"}
         Notes: ${video.notes || "No notes provided"}
         URL: ${video.externalVideoUrl || "No URL provided"}`
      ).join("\n\n");
      const prompt = `You are an expert football coach analyzing game film. Analyze this film comparison:
      
Title: ${comparison.title}
Description: ${comparison.description || "No description provided"}
Type: ${comparison.comparisonType} comparison
Tags: ${comparison.tags ? comparison.tags.join(", ") : "None"}

Videos:
${videoDescriptions}

Provide a comprehensive football analysis including:

1. Breakdown of player assignments on each play
2. Evaluation of coverage and identify any busted coverages
3. Detailed assessment of whether players fulfilled their assignments
4. Physical comparison of players (size, speed, etc.)
5. Evaluation of competition level
6. True performance rating based on technique and execution
7. Technical improvement recommendations with specific drills
8. Identify similar examples of good technique from professional players

Format your response as a structured JSON object with the following fields:
- aiGeneratedNotes: A comprehensive narrative analysis
- similarityScore: A number from 0 to 1 indicating technique similarity
- recommendations: An array of specific recommendations for improvement
- techniqueBreakdown: An object with technique aspects and scores
- playAssignments: An object describing expected assignments for each player position
- assignmentGrades: An object with scores (0-100) for how well each player executed their assignment
- bustedCoverage: Boolean indicating if there was a busted coverage
- bustedCoverageDetails: Object with details about any coverage breakdowns
- playerComparisons: Object with size, speed, and competition level comparisons
- performanceRating: Object with ratings based on performance metrics
- recommendedExamples: Object with URLs to recommended technique examples from professional players
- defenseAnalysis: Object with analysis of defensive scheme and execution

Keep the JSON valid and properly formatted.`;
      const response = await openai4.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are a professional football coach specializing in player development and film analysis."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.3,
        max_tokens: 2500,
        response_format: { type: "json_object" }
      });
      const content = response.choices[0]?.message?.content || "{}";
      const analysis = JSON.parse(content);
      const enhancedAnalysis = await this.enhanceWithExamples(analysis);
      return enhancedAnalysis;
    } catch (error) {
      console.error("Error generating football analysis:", error);
      return {
        aiGeneratedNotes: "We encountered an error analyzing this football film. Please try again later.",
        similarityScore: 0.5,
        recommendations: ["Review the film manually", "Try uploading clearer video"],
        techniqueBreakdown: {
          "Overall Technique": 0.5
        }
      };
    }
  }
  /**
   * Enhance the analysis with real examples from professional players
   */
  async enhanceWithExamples(analysis) {
    try {
      const enhancedAnalysis = { ...analysis };
      const techniques = Object.keys(analysis.techniqueBreakdown || {});
      enhancedAnalysis.recommendedExamples = enhancedAnalysis.recommendedExamples || {};
      for (const technique of techniques) {
        enhancedAnalysis.recommendedExamples[technique] = {
          title: `Professional ${technique} Example`,
          description: `Watch how professional players execute ${technique.toLowerCase()}`,
          url: `https://example.com/technique/${technique.toLowerCase().replace(/\s+/g, "-")}`,
          playerName: "Professional Athlete",
          // In a real implementation, these would be actual video URLs
          sourceType: "reference"
        };
      }
      return enhancedAnalysis;
    } catch (error) {
      console.error("Error enhancing analysis with examples:", error);
      return analysis;
    }
  }
  /**
   * Search for professional technique examples (would connect to external API)
   */
  async searchProfessionalTechniqueExamples(technique) {
    return [
      {
        title: `${technique} Example - Pro Level`,
        url: `https://example.com/technique/${technique.toLowerCase().replace(/\s+/g, "-")}`,
        playerName: "Professional Player",
        leagueLevel: "NFL"
      }
    ];
  }
};
var footballCoachService = new FootballCoachService();

// server/services/sms-service.ts
import twilio from "twilio";
var SMSService = class {
  client = null;
  defaultPhoneNumber = null;
  isConfigured = false;
  constructor() {
    this.initializeClient();
  }
  initializeClient() {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const phoneNumber = process.env.TWILIO_PHONE_NUMBER;
    if (accountSid && authToken) {
      this.client = twilio(accountSid, authToken);
      this.defaultPhoneNumber = phoneNumber || null;
      this.isConfigured = true;
      console.log("SMS service initialized successfully");
    } else {
      console.warn("SMS service not configured. Missing Twilio credentials.");
      this.isConfigured = false;
    }
  }
  /**
   * Send an SMS message
   * @param options SMS message options
   * @returns Promise resolving to success status and message data or error
   */
  async sendMessage(options) {
    if (!this.isConfigured || !this.client) {
      return {
        success: false,
        error: "SMS service not configured. Missing Twilio credentials."
      };
    }
    if (!options.to) {
      return {
        success: false,
        error: "Recipient phone number is required"
      };
    }
    if (!options.body) {
      return {
        success: false,
        error: "Message body is required"
      };
    }
    try {
      const to = options.to.startsWith("+") ? options.to : `+${options.to}`;
      const from = options.from || this.defaultPhoneNumber;
      if (!from) {
        return {
          success: false,
          error: "Sender phone number is required. Either provide it in options or set TWILIO_PHONE_NUMBER environment variable."
        };
      }
      const message = await this.client.messages.create({
        body: options.body,
        from,
        to
      });
      return {
        success: true,
        data: {
          sid: message.sid,
          status: message.status,
          to: message.to
        }
      };
    } catch (error) {
      console.error("Error sending SMS:", error);
      return {
        success: false,
        error: error.message || "Failed to send SMS"
      };
    }
  }
  /**
   * Check if the SMS service is properly configured
   * @returns boolean indicating if the service is ready to use
   */
  isReady() {
    return this.isConfigured && this.client !== null;
  }
  /**
   * Reinitialize the SMS client (useful if environment variables were updated)
   */
  reinitialize() {
    this.initializeClient();
  }
};
var smsService = new SMSService();
var sms_service_default = smsService;

// server/services/sms-routes.ts
import { z as z3 } from "zod";
var sendSmsSchema = z3.object({
  to: z3.string().min(10).max(15),
  body: z3.string().min(1).max(1600),
  from: z3.string().optional()
});
var sendSms = async (req, res) => {
  try {
    const validation = sendSmsSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        message: "Invalid request data",
        errors: validation.error.errors
      });
    }
    if (!sms_service_default.isReady()) {
      return res.status(503).json({
        success: false,
        message: "SMS service not configured. Missing Twilio credentials."
      });
    }
    const { to, body, from } = validation.data;
    const result = await sms_service_default.sendMessage({ to, body, from });
    if (result.success) {
      return res.status(200).json({
        success: true,
        message: "SMS sent successfully",
        data: result.data
      });
    } else {
      return res.status(400).json({
        success: false,
        message: result.error || "Failed to send SMS"
      });
    }
  } catch (error) {
    console.error("Error sending SMS:", error);
    return res.status(500).json({
      success: false,
      message: error.message || "An error occurred while sending SMS"
    });
  }
};
var checkSmsStatus = async (req, res) => {
  const isServiceReady = sms_service_default.isReady();
  return res.status(200).json({
    success: true,
    ready: isServiceReady,
    message: isServiceReady ? "SMS service is configured and ready" : "SMS service is not configured. Missing Twilio credentials."
  });
};
var sendVerificationCode = async (req, res) => {
  try {
    const { phoneNumber } = req.body;
    if (!phoneNumber) {
      return res.status(400).json({
        success: false,
        message: "Phone number is required"
      });
    }
    if (!sms_service_default.isReady()) {
      return res.status(503).json({
        success: false,
        message: "SMS service not configured. Missing Twilio credentials."
      });
    }
    const verificationCode = Math.floor(1e5 + Math.random() * 9e5).toString();
    if (!req.session.verificationCodes) {
      req.session.verificationCodes = {};
    }
    req.session.verificationCodes[phoneNumber] = {
      code: verificationCode,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    const result = await sms_service_default.sendMessage({
      to: phoneNumber,
      body: `Your MyPlayer verification code is: ${verificationCode}. This code will expire in 10 minutes.`
    });
    if (result.success) {
      return res.status(200).json({
        success: true,
        message: "Verification code sent successfully"
      });
    } else {
      return res.status(400).json({
        success: false,
        message: result.error || "Failed to send verification code"
      });
    }
  } catch (error) {
    console.error("Error sending verification code:", error);
    return res.status(500).json({
      success: false,
      message: error.message || "An error occurred while sending verification code"
    });
  }
};
var verifyCode = async (req, res) => {
  try {
    const { phoneNumber, code } = req.body;
    if (!phoneNumber || !code) {
      return res.status(400).json({
        success: false,
        message: "Phone number and verification code are required"
      });
    }
    if (!req.session.verificationCodes || !req.session.verificationCodes[phoneNumber]) {
      return res.status(400).json({
        success: false,
        message: "No verification code found for this phone number"
      });
    }
    const storedVerification = req.session.verificationCodes[phoneNumber];
    if (storedVerification.code !== code) {
      return res.status(400).json({
        success: false,
        message: "Invalid verification code"
      });
    }
    const createdAt = new Date(storedVerification.createdAt);
    const expirationTime = new Date(createdAt.getTime() + 10 * 60 * 1e3);
    if (/* @__PURE__ */ new Date() > expirationTime) {
      delete req.session.verificationCodes[phoneNumber];
      return res.status(400).json({
        success: false,
        message: "Verification code has expired"
      });
    }
    delete req.session.verificationCodes[phoneNumber];
    if (req.user) {
      const userId = req.user.id;
    }
    return res.status(200).json({
      success: true,
      message: "Phone number verified successfully"
    });
  } catch (error) {
    console.error("Error verifying code:", error);
    return res.status(500).json({
      success: false,
      message: error.message || "An error occurred while verifying code"
    });
  }
};
var sendNotification = async (req, res) => {
  try {
    const { userId, message } = req.body;
    if (!userId || !message) {
      return res.status(400).json({
        success: false,
        message: "User ID and notification message are required"
      });
    }
    if (!sms_service_default.isReady()) {
      return res.status(503).json({
        success: false,
        message: "SMS service not configured. Missing Twilio credentials."
      });
    }
    const { storage: storage3 } = (init_storage(), __toCommonJS(storage_exports));
    const user = await storage3.getUser(userId);
    if (!user || !user.phoneNumber) {
      return res.status(400).json({
        success: false,
        message: "User does not have a registered phone number"
      });
    }
    const result = await sms_service_default.sendMessage({
      to: user.phoneNumber,
      body: message
    });
    if (result.success) {
      return res.status(200).json({
        success: true,
        message: "Notification sent successfully"
      });
    } else {
      return res.status(400).json({
        success: false,
        message: result.error || "Failed to send notification"
      });
    }
  } catch (error) {
    console.error("Error sending notification:", error);
    return res.status(500).json({
      success: false,
      message: error.message || "An error occurred while sending notification"
    });
  }
};

// server/routes.ts
init_schema();
var upload = multer2({
  dest: path8.join(process.cwd(), "uploads"),
  limits: {
    fileSize: 50 * 1024 * 1024
    // 50MB limit
  }
});
async function registerRoutes(app2) {
  const server = createServer(app2);
  const wss = new WebSocketServer({
    server,
    path: "/ws",
    perMessageDeflate: false
  });
  const clients = /* @__PURE__ */ new Map();
  wss.on("connection", (ws) => {
    console.log("WebSocket connection established");
    ws.on("message", async (message) => {
      try {
        const data = JSON.parse(message.toString());
        if (data.type === "auth") {
          const userId = data.userId;
          const user = await storage.getUser(userId);
          if (!user) {
            console.log(`WebSocket authentication failed for user ID: ${userId}`);
            ws.send(JSON.stringify({ type: "error", message: "Authentication failed" }));
            return;
          }
          clients.set(ws, {
            userId: user.id,
            username: user.username,
            role: user.role
          });
          console.log(`WebSocket authenticated for user: ${user.username}`);
          ws.send(JSON.stringify({
            type: "auth_success",
            message: "Authentication successful"
          }));
          const messages2 = await storage.getMessages(userId);
          const unreadMessages = messages2.filter((msg) => !msg.isRead && msg.recipientId === userId);
          if (unreadMessages.length > 0) {
            ws.send(JSON.stringify({
              type: "unread_messages",
              count: unreadMessages.length,
              messages: unreadMessages.map((msg) => ({
                id: msg.id,
                senderId: msg.senderId,
                recipientId: msg.recipientId,
                content: msg.content,
                createdAt: msg.createdAt,
                isRead: msg.isRead
              }))
            }));
          }
          return;
        }
        if (data.type === "chat_message") {
          const { content, recipientId, senderId, timestamp: timestamp2 } = data;
          const clientInfo = clients.get(ws);
          if (!clientInfo || clientInfo.userId !== senderId) {
            ws.send(JSON.stringify({
              type: "error",
              message: "Unauthorized message sender"
            }));
            return;
          }
          const sender = await storage.getUser(senderId);
          if (!sender) {
            ws.send(JSON.stringify({
              type: "error",
              message: "Sender not found"
            }));
            return;
          }
          const outgoingMessage = {
            type: "chat_message",
            senderId,
            senderName: sender.name,
            content,
            timestamp: timestamp2,
            recipientId: recipientId || null
          };
          try {
            await storage.createMessage({
              senderId,
              recipientId: recipientId || null,
              content,
              isRead: false
            });
          } catch (dbError) {
            console.error("Error storing chat message:", dbError);
          }
          if (recipientId > 0) {
            for (const [client, info] of clients.entries()) {
              if (info.userId === recipientId) {
                client.send(JSON.stringify(outgoingMessage));
                break;
              }
            }
            ws.send(JSON.stringify({
              type: "message_sent",
              recipientId,
              timestamp: timestamp2
            }));
          } else {
            for (const [client, info] of clients.entries()) {
              if (client !== ws) {
                client.send(JSON.stringify(outgoingMessage));
              }
            }
          }
          return;
        }
      } catch (error) {
        console.error("Error processing WebSocket message:", error);
      }
    });
    ws.on("close", () => {
      clients.delete(ws);
      console.log("WebSocket client disconnected");
    });
    ws.send(JSON.stringify({ type: "connected" }));
  });
  app2.get("/api/highlights/featured", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit) : 10;
      const highlights = await storage.getFeaturedVideoHighlights(limit);
      return res.json(highlights);
    } catch (error) {
      console.error("Error fetching featured highlights:", error);
      return res.status(500).json({ message: "Error fetching featured highlights" });
    }
  });
  app2.post("/api/public/user-agreements", async (req, res) => {
    try {
      const ipAddress = req.headers["x-forwarded-for"] || req.socket.remoteAddress;
      const userAgent = req.headers["user-agent"];
      console.log(`Guest agreement accepted from IP: ${ipAddress}, UA: ${userAgent}`);
      return res.status(200).json({ success: true });
    } catch (error) {
      console.error("Error processing guest agreement:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  setupAuth(app2);
  app2.post("/api/auth/login", (req, res, next) => {
    passport2.authenticate("local", (err, user, info) => {
      if (err) {
        console.error("Login error:", err);
        return next(err);
      }
      if (!user) {
        console.log("Authentication failed:", info);
        return res.status(401).json({ message: "Invalid username or password" });
      }
      console.log(`User authenticated: ${user.username}, ID: ${user.id}`);
      req.login(user, (loginErr) => {
        if (loginErr) {
          console.error("Session login error:", loginErr);
          return next(loginErr);
        }
        console.log("Session created:", req.sessionID);
        console.log("Session data:", req.session);
        return res.status(200).json({ user });
      });
    })(req, res, next);
  });
  app2.post("/api/auth/register", async (req, res, next) => {
    try {
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      const user = await storage.createUser({
        ...req.body,
        password: await hashPassword(req.body.password)
      });
      req.login(user, (err) => {
        if (err) return next(err);
        res.status(201).json({ user });
      });
    } catch (error) {
      next(error);
    }
  });
  app2.post("/api/auth/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });
  app2.get("/api/auth/me", (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
    res.json({ user: req.user });
  });
  const isAuthenticated = (req, res, next) => {
    if (req.isAuthenticated()) {
      return next();
    }
    return res.status(401).json({ message: "Not authenticated" });
  };
  const isAdmin = (req, res, next) => {
    if (req.isAuthenticated() && req.user.role === "admin") {
      return next();
    }
    return res.status(403).json({ message: "Not authorized" });
  };
  app2.get("/api/user-agreements/:userId", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const requestUser = req.user;
      if (userId !== requestUser.id && requestUser.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to view this agreement" });
      }
      const agreement = await storage.getUserAgreement(userId);
      if (!agreement) {
        return res.status(404).json({ message: "No agreement found for this user" });
      }
      return res.json(agreement);
    } catch (error) {
      console.error("Error fetching user agreement:", error);
      return res.status(500).json({ message: "Error fetching user agreement" });
    }
  });
  app2.post("/api/user-agreements", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const agreement = insertUserAgreementSchema.parse({
        ...req.body,
        userId: user.id
      });
      const ipAddress = req.headers["x-forwarded-for"] || req.socket.remoteAddress;
      const userAgent = req.headers["user-agent"];
      const newAgreement = await storage.createUserAgreement({
        ...agreement,
        ipAddress: ipAddress ? String(ipAddress) : null,
        userAgent: userAgent ? String(userAgent) : null
      });
      return res.status(201).json(newAgreement);
    } catch (error) {
      console.error("Error creating user agreement:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.get("/api/athletes/list", isAuthenticated, async (req, res) => {
    try {
      const athletes = await storage.getAllAthletes();
      return res.json(athletes.map((athlete) => ({
        id: athlete.id,
        name: athlete.name,
        username: athlete.username,
        profileImage: athlete.profileImage,
        role: athlete.role
      })));
    } catch (error) {
      console.error("Error fetching athletes list:", error);
      return res.status(500).json({ message: "Error fetching athletes list" });
    }
  });
  app2.get("/api/coaches/list", isAuthenticated, async (req, res) => {
    try {
      const coaches = await storage.getAllCoaches();
      return res.json(coaches.map((coach) => ({
        id: coach.id,
        name: coach.name,
        username: coach.username,
        profileImage: coach.profileImage,
        role: coach.role
      })));
    } catch (error) {
      console.error("Error fetching coaches list:", error);
      return res.status(500).json({ message: "Error fetching coaches list" });
    }
  });
  app2.get("/api/athletes/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      if (!user || user.role !== "athlete") {
        return res.status(404).json({ message: "Athlete not found" });
      }
      const profile = await storage.getAthleteProfile(userId);
      return res.json({
        id: user.id,
        username: user.username,
        name: user.name,
        email: user.email,
        profileImage: user.profileImage,
        bio: user.bio,
        profile
      });
    } catch (error) {
      console.error("Error fetching athlete:", error);
      return res.status(500).json({ message: "Error fetching athlete data" });
    }
  });
  app2.get("/api/coaches/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      if (!user || user.role !== "coach") {
        return res.status(404).json({ message: "Coach not found" });
      }
      const profile = await storage.getCoachProfile(userId);
      return res.json({
        id: user.id,
        username: user.username,
        name: user.name,
        email: user.email,
        profileImage: user.profileImage,
        bio: user.bio,
        profile
      });
    } catch (error) {
      console.error("Error fetching coach:", error);
      return res.status(500).json({ message: "Error fetching coach data" });
    }
  });
  app2.get("/api/athletes/:id/profile", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const requestUser = req.user;
      if (userId !== requestUser.id && requestUser.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to view this profile" });
      }
      const profile = await storage.getAthleteProfile(userId);
      if (!profile) {
        return res.status(404).json({ message: "Athlete profile not found" });
      }
      return res.json(profile);
    } catch (error) {
      console.error("Error fetching athlete profile:", error);
      return res.status(500).json({ message: "Error fetching athlete profile data" });
    }
  });
  app2.put("/api/athletes/:id/profile", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = req.user;
      if (userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to update this profile" });
      }
      const profileData = insertAthleteProfileSchema.parse(req.body);
      let profile = await storage.getAthleteProfile(userId);
      if (!profile) {
        profile = await storage.createAthleteProfile({
          userId,
          ...profileData
        });
        return res.status(201).json(profile);
      }
      const updatedProfile = await storage.updateAthleteProfile(userId, profileData);
      if (!updatedProfile) {
        return res.status(500).json({ message: "Failed to update athlete profile" });
      }
      return res.json(updatedProfile);
    } catch (error) {
      console.error("Error updating athlete profile:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.put("/api/coaches/:id/profile", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = req.user;
      if (userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to update this profile" });
      }
      const profileData = insertCoachProfileSchema.parse(req.body);
      const updatedProfile = await storage.updateCoachProfile(userId, profileData);
      if (!updatedProfile) {
        return res.status(404).json({ message: "Coach profile not found" });
      }
      return res.json(updatedProfile);
    } catch (error) {
      console.error("Error updating coach profile:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.get("/api/videos", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const videos3 = await storage.getVideosByUser(user.id);
      return res.json(videos3);
    } catch (error) {
      console.error("Error fetching videos:", error);
      return res.status(500).json({ message: "Error fetching videos" });
    }
  });
  app2.get("/api/videos/:id", isAuthenticated, async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const video = await storage.getVideo(videoId);
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }
      const user = req.user;
      if (video.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to view this video" });
      }
      return res.json(video);
    } catch (error) {
      console.error("Error fetching video:", error);
      return res.status(500).json({ message: "Error fetching video" });
    }
  });
  app2.post("/api/videos/upload", isAuthenticated, videoUpload.single("video"), async (req, res) => {
    try {
      console.log("Video upload received:", req.file ? "File present" : "No file");
      console.log("Request body:", req.body);
      console.log("User:", req.user ? `ID: ${req.user.id}, Role: ${req.user.role}` : "No user");
      if (!req.file) {
        return res.status(400).json({ message: "No video file uploaded" });
      }
      const user = req.user;
      const { title, description, sportType } = req.body;
      const uploadsDir2 = path8.join(process.cwd(), "uploads", "videos");
      if (!fs7.existsSync(uploadsDir2)) {
        fs7.mkdirSync(uploadsDir2, { recursive: true });
      }
      const filename = `${Date.now()}-${path8.basename(req.file.originalname)}`;
      const filePath = path8.join(uploadsDir2, filename);
      fs7.renameSync(req.file.path, filePath);
      const videoData = insertVideoWithFileSchema.parse({
        userId: user.id,
        title,
        description,
        filePath: `/uploads/videos/${filename}`,
        sportType,
        thumbnailPath: ""
        // Will be updated after processing
      });
      const video = await storage.createVideo(videoData);
      analyzeVideo(video.id, filePath).then(async (analysisResult) => {
        await storage.updateVideo(video.id, { analyzed: true });
        await storage.updateVideo(video.id, {
          thumbnailPath: `https://images.unsplash.com/photo-1546519638-68e109498ffc?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80`
        });
        await storage.createVideoAnalysis({
          videoId: video.id,
          motionData: analysisResult.motionData,
          overallScore: analysisResult.overallScore,
          feedback: analysisResult.feedback,
          improvementTips: analysisResult.improvementTips,
          keyFrameTimestamps: analysisResult.keyFrameTimestamps
        });
        const athleteProfile = await storage.getAthleteProfile(user.id);
        if (athleteProfile) {
          const recommendations = await generateSportRecommendations(
            user.id,
            analysisResult.motionData,
            athleteProfile
          );
          for (const rec of recommendations) {
            await storage.createSportRecommendation({
              userId: user.id,
              sport: rec.sport,
              matchPercentage: rec.matchPercentage,
              positionRecommendation: rec.positionRecommendation,
              potentialLevel: rec.potentialLevel,
              reasonForMatch: rec.reasonForMatch
            });
          }
        }
        const userVideos = await storage.getVideosByUser(user.id);
        if (userVideos.length === 1) {
          await storage.createAchievement({
            userId: user.id,
            title: "First Video Analysis",
            description: "Completed your first video motion analysis",
            achievementType: "video",
            iconType: "trophy"
          });
        }
      }).catch((error) => {
        console.error("Video analysis error:", error);
      });
      return res.status(201).json(video);
    } catch (error) {
      console.error("Error uploading video:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.get("/api/videos/:id/analysis", isAuthenticated, async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const video = await storage.getVideo(videoId);
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }
      const user = req.user;
      if (video.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to view this analysis" });
      }
      const analysis = await storage.getVideoAnalysisByVideoId(videoId);
      if (!analysis) {
        return res.status(404).json({ message: "Analysis not found for this video" });
      }
      return res.json(analysis);
    } catch (error) {
      console.error("Error fetching video analysis:", error);
      return res.status(500).json({ message: "Error fetching video analysis" });
    }
  });
  app2.get("/api/videos/:id/highlights", isAuthenticated, async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const video = await storage.getVideo(videoId);
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }
      const user = req.user;
      if (video.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to view these highlights" });
      }
      const highlights = await storage.getVideoHighlights(videoId);
      return res.json(highlights);
    } catch (error) {
      console.error("Error fetching video highlights:", error);
      return res.status(500).json({ message: "Error fetching video highlights" });
    }
  });
  app2.get("/api/highlights/:id", isAuthenticated, async (req, res) => {
    try {
      const highlightId = parseInt(req.params.id);
      const highlight = await storage.getVideoHighlight(highlightId);
      if (!highlight) {
        return res.status(404).json({ message: "Highlight not found" });
      }
      const video = await storage.getVideo(highlight.videoId);
      if (!video) {
        return res.status(404).json({ message: "Original video not found" });
      }
      const user = req.user;
      if (video.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to view this highlight" });
      }
      return res.json(highlight);
    } catch (error) {
      console.error("Error fetching highlight:", error);
      return res.status(500).json({ message: "Error fetching highlight" });
    }
  });
  app2.post("/api/videos/:id/highlights", isAuthenticated, async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const video = await storage.getVideo(videoId);
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }
      const user = req.user;
      if (video.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to create highlights for this video" });
      }
      const highlightData = insertVideoHighlightSchema.parse({
        ...req.body,
        videoId,
        userId: user.id
      });
      const highlight = await storage.createVideoHighlight(highlightData);
      return res.status(201).json(highlight);
    } catch (error) {
      console.error("Error creating video highlight:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.put("/api/highlights/:id", isAuthenticated, async (req, res) => {
    try {
      const highlightId = parseInt(req.params.id);
      const highlight = await storage.getVideoHighlight(highlightId);
      if (!highlight) {
        return res.status(404).json({ message: "Highlight not found" });
      }
      const video = await storage.getVideo(highlight.videoId);
      if (!video) {
        return res.status(404).json({ message: "Original video not found" });
      }
      const user = req.user;
      if (video.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to update this highlight" });
      }
      const updatedHighlight = await storage.updateVideoHighlight(highlightId, req.body);
      if (!updatedHighlight) {
        return res.status(500).json({ message: "Failed to update highlight" });
      }
      return res.json(updatedHighlight);
    } catch (error) {
      console.error("Error updating highlight:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.delete("/api/highlights/:id", isAuthenticated, async (req, res) => {
    try {
      const highlightId = parseInt(req.params.id);
      const highlight = await storage.getVideoHighlight(highlightId);
      if (!highlight) {
        return res.status(404).json({ message: "Highlight not found" });
      }
      const video = await storage.getVideo(highlight.videoId);
      if (!video) {
        return res.status(404).json({ message: "Original video not found" });
      }
      const user = req.user;
      if (video.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to delete this highlight" });
      }
      const result = await storage.deleteVideoHighlight(highlightId);
      if (!result) {
        return res.status(500).json({ message: "Failed to delete highlight" });
      }
      return res.json({ success: true });
    } catch (error) {
      console.error("Error deleting highlight:", error);
      return res.status(500).json({ message: "Error deleting highlight" });
    }
  });
  app2.get("/api/highlights/featured", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit) : 10;
      const highlights = await storage.getFeaturedVideoHighlights(limit);
      return res.json(highlights);
    } catch (error) {
      console.error("Error fetching featured highlights:", error);
      return res.status(500).json({ message: "Error fetching featured highlights" });
    }
  });
  app2.post("/api/videos/:id/generate-highlight", isAuthenticated, async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const video = await storage.getVideo(videoId);
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }
      const user = req.user;
      if (video.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to generate highlights for this video" });
      }
      const { startTime, endTime, title, description } = req.body;
      if (typeof startTime !== "number" || typeof endTime !== "number" || startTime >= endTime) {
        return res.status(400).json({ message: "Invalid start or end time" });
      }
      const highlight = await storage.generateVideoHighlight(videoId, {
        startTime,
        endTime,
        title,
        description,
        userId: user.id,
        aiGenerated: true
      });
      return res.status(201).json(highlight);
    } catch (error) {
      console.error("Error generating video highlight:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.get("/api/highlight-generator/configs", isAuthenticated, async (req, res) => {
    try {
      const configs = await db.select().from(highlightGeneratorConfigs2).orderBy(highlightGeneratorConfigs2.createdAt);
      return res.json(configs);
    } catch (error) {
      console.error("Error fetching highlight generator configs:", error);
      return res.status(500).json({ message: "Error fetching highlight generator configurations" });
    }
  });
  app2.get("/api/highlight-generator/configs/:id", isAuthenticated, async (req, res) => {
    try {
      const configId = parseInt(req.params.id);
      const [config] = await db.select().from(highlightGeneratorConfigs2).where(eq7(highlightGeneratorConfigs2.id, configId));
      if (!config) {
        return res.status(404).json({ message: "Highlight generator configuration not found" });
      }
      return res.json(config);
    } catch (error) {
      console.error("Error fetching highlight generator config:", error);
      return res.status(500).json({ message: "Error fetching highlight generator configuration" });
    }
  });
  app2.post("/api/highlight-generator/configs", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only admins can create highlight generator configurations" });
      }
      const configData = insertHighlightGeneratorConfigSchema.parse({
        ...req.body,
        createdBy: user.id
      });
      const [newConfig] = await db.insert(highlightGeneratorConfigs2).values(configData).returning();
      return res.status(201).json(newConfig);
    } catch (error) {
      console.error("Error creating highlight generator config:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.put("/api/highlight-generator/configs/:id", isAuthenticated, async (req, res) => {
    try {
      const configId = parseInt(req.params.id);
      const user = req.user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only admins can update highlight generator configurations" });
      }
      const [existingConfig] = await db.select().from(highlightGeneratorConfigs2).where(eq7(highlightGeneratorConfigs2.id, configId));
      if (!existingConfig) {
        return res.status(404).json({ message: "Highlight generator configuration not found" });
      }
      const [updatedConfig] = await db.update(highlightGeneratorConfigs2).set(req.body).where(eq7(highlightGeneratorConfigs2.id, configId)).returning();
      return res.json(updatedConfig);
    } catch (error) {
      console.error("Error updating highlight generator config:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.delete("/api/highlight-generator/configs/:id", isAuthenticated, async (req, res) => {
    try {
      const configId = parseInt(req.params.id);
      const user = req.user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only admins can delete highlight generator configurations" });
      }
      const [existingConfig] = await db.select().from(highlightGeneratorConfigs2).where(eq7(highlightGeneratorConfigs2.id, configId));
      if (!existingConfig) {
        return res.status(404).json({ message: "Highlight generator configuration not found" });
      }
      await db.delete(highlightGeneratorConfigs2).where(eq7(highlightGeneratorConfigs2.id, configId));
      return res.json({ success: true });
    } catch (error) {
      console.error("Error deleting highlight generator config:", error);
      return res.status(500).json({ message: "Error deleting highlight generator configuration" });
    }
  });
  app2.post("/api/highlight-generator/run/:videoId/:configId", isAuthenticated, async (req, res) => {
    try {
      const videoId = parseInt(req.params.videoId);
      const configId = parseInt(req.params.configId);
      const user = req.user;
      const video = await storage.getVideo(videoId);
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }
      if (video.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to generate highlights for this video" });
      }
      const [config] = await db.select().from(highlightGeneratorConfigs2).where(eq7(highlightGeneratorConfigs2.id, configId));
      if (!config) {
        return res.status(404).json({ message: "Highlight generator configuration not found" });
      }
      if (!config.active) {
        return res.status(400).json({ message: "This highlight generator configuration is not active" });
      }
      const videoDuration = video.duration || 300;
      const detectableEvents = config.detectableEvents || {};
      const detectedHighlights = [];
      const numHighlights = Math.min(
        Math.floor(Math.random() * 3) + 1,
        config.maxHighlightsPerVideo || 3
      );
      for (let i = 0; i < numHighlights; i++) {
        const highlightDuration = Math.floor(
          Math.random() * (config.maxDuration - config.minDuration) + config.minDuration
        );
        const maxStartTime = Math.max(0, videoDuration - highlightDuration - 1);
        const startTime = Math.floor(Math.random() * maxStartTime);
        const endTime = startTime + highlightDuration;
        const qualityScore = Math.floor(
          Math.random() * (100 - config.qualityThreshold) + config.qualityThreshold
        );
        const primarySkill = config.highlightTypes && config.highlightTypes.length > 0 ? config.highlightTypes[Math.floor(Math.random() * config.highlightTypes.length)] : "general play";
        const skillLevel = Math.floor(Math.random() * 45) + 50;
        const aiAnalysisNotes = `Detected ${primarySkill} with confidence ${qualityScore}%. Skill level rated ${skillLevel}/100.`;
        const highlight = {
          videoId,
          title: `${video.title} - ${primarySkill} Highlight`,
          description: `AI-generated highlight showing ${primarySkill} from ${video.title}`,
          startTime,
          endTime,
          highlightPath: video.filePath,
          // In real implementation, this would be a new file
          thumbnailPath: video.thumbnailPath,
          createdBy: user.id,
          aiGenerated: true,
          tags: [config.sportType, primarySkill],
          qualityScore,
          primarySkill,
          skillLevel,
          gameContext: "practice",
          aiAnalysisNotes
        };
        const [createdHighlight] = await db.insert(videoHighlights).values(highlight).returning();
        detectedHighlights.push(createdHighlight);
      }
      await db.update(highlightGeneratorConfigs2).set({ lastRun: /* @__PURE__ */ new Date() }).where(eq7(highlightGeneratorConfigs2.id, configId));
      return res.status(201).json({
        message: `Generated ${detectedHighlights.length} highlights`,
        highlights: detectedHighlights
      });
    } catch (error) {
      console.error("Error running highlight generator:", error);
      return res.status(500).json({ message: "Error running highlight generator" });
    }
  });
  app2.get("/api/athletes/:id/recommendations", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = req.user;
      if (userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to view these recommendations" });
      }
      const recommendations = await storage.getSportRecommendations(userId);
      return res.json(recommendations);
    } catch (error) {
      console.error("Error fetching sport recommendations:", error);
      return res.status(500).json({ message: "Error fetching sport recommendations" });
    }
  });
  app2.get("/api/athletes/:id/ncaa-eligibility", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = req.user;
      if (userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to view this eligibility" });
      }
      const eligibility = await storage.getNcaaEligibility(userId);
      if (!eligibility) {
        return res.status(404).json({ message: "NCAA eligibility not found" });
      }
      return res.json(eligibility);
    } catch (error) {
      console.error("Error fetching NCAA eligibility:", error);
      return res.status(500).json({ message: "Error fetching NCAA eligibility" });
    }
  });
  app2.put("/api/athletes/:id/ncaa-eligibility", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = req.user;
      if (userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to update this eligibility" });
      }
      const eligibilityData = insertNcaaEligibilitySchema.parse(req.body);
      const updatedEligibility = await storage.updateNcaaEligibility(userId, eligibilityData);
      if (!updatedEligibility) {
        return res.status(404).json({ message: "NCAA eligibility not found" });
      }
      return res.json(updatedEligibility);
    } catch (error) {
      console.error("Error updating NCAA eligibility:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.get("/api/connections", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const connections = await storage.getCoachConnections(user.id, user.role);
      const enhancedConnections = await Promise.all(
        connections.map(async (connection2) => {
          const otherUserId = user.role === "coach" ? connection2.athleteId : connection2.coachId;
          const otherUser = await storage.getUser(otherUserId);
          return {
            ...connection2,
            otherUser: {
              id: otherUser.id,
              name: otherUser.name,
              username: otherUser.username,
              profileImage: otherUser.profileImage,
              role: otherUser.role
            }
          };
        })
      );
      return res.json(enhancedConnections);
    } catch (error) {
      console.error("Error fetching connections:", error);
      return res.status(500).json({ message: "Error fetching connections" });
    }
  });
  app2.post("/api/connections", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const { coachId, athleteId, notes } = req.body;
      if (user.role === "coach" && coachId !== user.id) {
        return res.status(400).json({ message: "Invalid coach ID for current user" });
      }
      if (user.role === "athlete" && athleteId !== user.id) {
        return res.status(400).json({ message: "Invalid athlete ID for current user" });
      }
      const connectionData = insertCoachConnectionSchema.parse({
        coachId: coachId || user.id,
        athleteId: athleteId || user.id,
        connectionStatus: "pending",
        notes: notes || ""
      });
      const connection2 = await storage.createCoachConnection(connectionData);
      return res.status(201).json(connection2);
    } catch (error) {
      console.error("Error creating connection:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.put("/api/connections/:id", isAuthenticated, async (req, res) => {
    try {
      const connectionId = parseInt(req.params.id);
      const user = req.user;
      const { connectionStatus } = req.body;
      const connection2 = await storage.getCoachConnections(user.id, user.role).then(
        (connections) => connections.find((c) => c.id === connectionId)
      );
      if (!connection2) {
        return res.status(404).json({ message: "Connection not found or not authorized" });
      }
      const updatedConnection = await storage.updateCoachConnection(connectionId, {
        connectionStatus,
        lastContact: /* @__PURE__ */ new Date()
      });
      if (connectionStatus === "accepted") {
        const userConnections = await storage.getCoachConnections(user.id, user.role);
        const acceptedConnections = userConnections.filter((c) => c.connectionStatus === "accepted");
        if (acceptedConnections.length === 1) {
          await storage.createAchievement({
            userId: user.role === "athlete" ? user.id : connection2.athleteId,
            title: "Connected with Coach",
            description: "Made your first connection with a college coach",
            achievementType: "connection",
            iconType: "handshake"
          });
        }
      }
      return res.json(updatedConnection);
    } catch (error) {
      console.error("Error updating connection:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.get("/api/athletes/:id/achievements", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = req.user;
      if (userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to view these achievements" });
      }
      const achievements2 = await storage.getAchievements(userId);
      return res.json(achievements2);
    } catch (error) {
      console.error("Error fetching achievements:", error);
      return res.status(500).json({ message: "Error fetching achievements" });
    }
  });
  app2.get("/api/messages", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const messages2 = await storage.getMessages(user.id);
      const enhancedMessages = await Promise.all(
        messages2.map(async (message) => {
          const senderId = message.senderId;
          const sender = await storage.getUser(senderId);
          return {
            ...message,
            sender: {
              id: sender.id,
              name: sender.name,
              username: sender.username,
              profileImage: sender.profileImage,
              role: sender.role
            }
          };
        })
      );
      return res.json(enhancedMessages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      return res.status(500).json({ message: "Error fetching messages" });
    }
  });
  app2.post("/api/messages", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const { recipientId, content } = req.body;
      const messageData = insertMessageSchema.parse({
        senderId: user.id,
        recipientId,
        content
      });
      const message = await storage.createMessage(messageData);
      return res.status(201).json(message);
    } catch (error) {
      console.error("Error sending message:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.patch("/api/messages/:id/read", isAuthenticated, async (req, res) => {
    try {
      const messageId = parseInt(req.params.id);
      const user = req.user;
      const messages2 = await storage.getMessages(user.id);
      const message = messages2.find((m) => m.id === messageId);
      if (!message) {
        return res.status(404).json({ message: "Message not found" });
      }
      if (message.recipientId !== user.id) {
        return res.status(403).json({ message: "Not authorized to mark this message as read" });
      }
      const updatedMessage = await storage.markMessageAsRead(messageId);
      return res.json(updatedMessage);
    } catch (error) {
      console.error("Error marking message as read:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.get("/api/admin/users", isAdmin, async (req, res) => {
    try {
      const users3 = await storage.getAllUsers();
      return res.json(users3);
    } catch (error) {
      console.error("Error fetching users:", error);
      return res.status(500).json({ message: "Error fetching users" });
    }
  });
  app2.get("/api/admin/athletes", isAdmin, async (req, res) => {
    try {
      const athletes = await storage.getAllAthletes();
      return res.json(athletes);
    } catch (error) {
      console.error("Error fetching athletes:", error);
      return res.status(500).json({ message: "Error fetching athletes" });
    }
  });
  app2.get("/api/admin/coaches", isAdmin, async (req, res) => {
    try {
      const coaches = await storage.getAllCoaches();
      return res.json(coaches);
    } catch (error) {
      console.error("Error fetching coaches:", error);
      return res.status(500).json({ message: "Error fetching coaches" });
    }
  });
  app2.get("/api/admin/videos", isAdmin, async (req, res) => {
    try {
      const videos3 = await storage.getAllVideos();
      return res.json(videos3);
    } catch (error) {
      console.error("Error fetching videos:", error);
      return res.status(500).json({ message: "Error fetching videos" });
    }
  });
  app2.get("/api/admin/stats", isAdmin, async (req, res) => {
    try {
      const stats = await storage.getSystemStats();
      return res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      return res.status(500).json({ message: "Error fetching stats" });
    }
  });
  app2.get("/api/player/skills", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const skills2 = await storage.getUserSkills(user.id);
      return res.json(skills2);
    } catch (error) {
      console.error("Error fetching skills:", error);
      return res.status(500).json({ message: "Error fetching skills" });
    }
  });
  app2.post("/api/player/skills", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const skillData = insertSkillSchema.parse({
        ...req.body,
        userId: user.id
      });
      const skill = await storage.createSkill(skillData);
      return res.status(201).json(skill);
    } catch (error) {
      console.error("Error creating skill:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.put("/api/player/skills/:id", isAuthenticated, async (req, res) => {
    try {
      const skillId = parseInt(req.params.id);
      const user = req.user;
      const skill = await storage.getSkill(skillId);
      if (!skill) {
        return res.status(404).json({ message: "Skill not found" });
      }
      if (skill.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to update this skill" });
      }
      const updatedSkill = await storage.updateSkill(skillId, req.body);
      return res.json(updatedSkill);
    } catch (error) {
      console.error("Error updating skill:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.get("/api/player/progress", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      let progress = await storage.getPlayerProgress(user.id);
      if (!progress) {
        progress = await storage.createPlayerProgress({
          userId: user.id,
          currentLevel: 1,
          totalXp: 0,
          levelXp: 0,
          xpToNextLevel: 100,
          streakDays: 0,
          lastActive: (/* @__PURE__ */ new Date()).toISOString()
        });
      } else {
        const lastActive = new Date(progress.lastActive);
        const now = /* @__PURE__ */ new Date();
        const daysSinceLastActive = Math.floor((now.getTime() - lastActive.getTime()) / (1e3 * 60 * 60 * 24));
        if (daysSinceLastActive === 1) {
          await storage.updatePlayerProgress(user.id, {
            streakDays: progress.streakDays + 1,
            lastActive: now.toISOString()
          });
          progress.streakDays += 1;
          progress.lastActive = now.toISOString();
        } else if (daysSinceLastActive > 1) {
          await storage.updatePlayerProgress(user.id, {
            streakDays: 1,
            lastActive: now.toISOString()
          });
          progress.streakDays = 1;
          progress.lastActive = now.toISOString();
        } else if (daysSinceLastActive === 0) {
          await storage.updatePlayerProgress(user.id, {
            lastActive: now.toISOString()
          });
          progress.lastActive = now.toISOString();
        }
      }
      return res.json(progress);
    } catch (error) {
      console.error("Error fetching player progress:", error);
      return res.status(500).json({ message: "Error fetching player progress" });
    }
  });
  app2.get("/api/player/xp/transactions", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const transactions = await storage.getXpTransactions(user.id);
      return res.json(transactions);
    } catch (error) {
      console.error("Error fetching XP transactions:", error);
      return res.status(500).json({ message: "Error fetching XP transactions" });
    }
  });
  app2.post("/api/player/xp/add", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const { amount, type, description } = req.body;
      if (!amount || !type || !description) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      const xpTransaction = await storage.addXpToPlayer(user.id, amount, type, description);
      return res.status(201).json(xpTransaction);
    } catch (error) {
      console.error("Error adding XP:", error);
      return res.status(500).json({ message: "Error adding XP" });
    }
  });
  app2.post("/api/player/xp/daily-login", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const progress = await storage.getPlayerProgress(user.id);
      if (!progress) {
        return res.status(404).json({ message: "Player progress not found" });
      }
      const lastActive = new Date(progress.lastActive);
      const now = /* @__PURE__ */ new Date();
      const isSameDay = lastActive.getDate() === now.getDate() && lastActive.getMonth() === now.getMonth() && lastActive.getFullYear() === now.getFullYear();
      if (isSameDay && progress.dailyLoginClaimed) {
        return res.status(400).json({ message: "Daily login bonus already claimed today" });
      }
      const baseXp = 50;
      const streakBonus = Math.min(progress.streakDays * 10, 100);
      const totalBonus = baseXp + streakBonus;
      const xpTransaction = await storage.addXpToPlayer(
        user.id,
        totalBonus,
        "login",
        `Daily login streak bonus (${progress.streakDays} days)`
      );
      await storage.updatePlayerProgress(user.id, {
        dailyLoginClaimed: true
      });
      return res.status(201).json({
        transaction: xpTransaction,
        message: `Claimed ${totalBonus} XP for daily login`
      });
    } catch (error) {
      console.error("Error claiming daily login bonus:", error);
      return res.status(500).json({ message: "Error claiming daily login bonus" });
    }
  });
  app2.get("/api/player/challenges", isAuthenticated, async (req, res) => {
    try {
      const challenges2 = await storage.getChallenges();
      return res.json(challenges2);
    } catch (error) {
      console.error("Error fetching challenges:", error);
      return res.status(500).json({ message: "Error fetching challenges" });
    }
  });
  app2.get("/api/player/challenges/active", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const userChallenges = await storage.getAthleteChallenges(user.id);
      const activeChallenges = await Promise.all(
        userChallenges.map(async (userChallenge) => {
          const challenge = await storage.getChallenge(userChallenge.challengeId);
          return {
            ...userChallenge,
            challenge
          };
        })
      );
      return res.json(activeChallenges);
    } catch (error) {
      console.error("Error fetching active challenges:", error);
      return res.status(500).json({ message: "Error fetching active challenges" });
    }
  });
  app2.post("/api/player/challenges/:id/accept", isAuthenticated, async (req, res) => {
    try {
      const challengeId = parseInt(req.params.id);
      const user = req.user;
      const challenge = await storage.getChallenge(challengeId);
      if (!challenge) {
        return res.status(404).json({ message: "Challenge not found" });
      }
      const existingChallenge = await storage.getAthleteChallengeByUserAndChallenge(user.id, challengeId);
      if (existingChallenge) {
        return res.status(400).json({ message: "Challenge already accepted" });
      }
      const athleteChallenge = await storage.createAthleteChallenge({
        userId: user.id,
        challengeId,
        status: "in-progress",
        startedAt: /* @__PURE__ */ new Date(),
        completedAt: null,
        proofUrl: null
      });
      return res.status(201).json(athleteChallenge);
    } catch (error) {
      console.error("Error accepting challenge:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.put("/api/player/challenges/:id/complete", isAuthenticated, async (req, res) => {
    try {
      const challengeId = parseInt(req.params.id);
      const user = req.user;
      const athleteChallenge = await storage.getAthleteChallengeByUserAndChallenge(user.id, challengeId);
      if (!athleteChallenge) {
        return res.status(404).json({ message: "Challenge not found or not accepted" });
      }
      if (athleteChallenge.status === "completed") {
        return res.status(400).json({ message: "Challenge already completed" });
      }
      const updatedChallenge = await storage.updateAthleteChallenge(athleteChallenge.id, {
        status: "completed",
        completedAt: /* @__PURE__ */ new Date(),
        proofUrl: req.body.proofUrl || null
      });
      const challenge = await storage.getChallenge(challengeId);
      if (challenge) {
        const skills2 = await storage.getUserSkills(user.id);
        const matchingSkill = skills2.find((skill) => skill.skillCategory.toLowerCase() === challenge.category.toLowerCase());
        if (matchingSkill) {
          const newXpPoints = matchingSkill.xpPoints + challenge.xpReward;
          let newLevel = matchingSkill.skillLevel;
          if (newXpPoints >= matchingSkill.nextLevelXp && matchingSkill.skillLevel < matchingSkill.maxLevel) {
            newLevel += 1;
          }
          await storage.updateSkill(matchingSkill.id, {
            xpPoints: newXpPoints,
            skillLevel: newLevel
          });
          const completedChallenges = await storage.getCompletedChallengesByUser(user.id);
          if (completedChallenges.length === 1) {
            await storage.createAchievement({
              userId: user.id,
              title: "First Challenge Completed",
              description: "Completed your first training challenge",
              achievementType: "challenge",
              iconType: "award",
              earnedDate: /* @__PURE__ */ new Date()
            });
          }
        }
      }
      return res.json(updatedChallenge);
    } catch (error) {
      console.error("Error completing challenge:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.get("/api/player/recovery", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const recoveryLogs2 = await storage.getRecoveryLogs(user.id);
      return res.json(recoveryLogs2);
    } catch (error) {
      console.error("Error fetching recovery logs:", error);
      return res.status(500).json({ message: "Error fetching recovery logs" });
    }
  });
  app2.post("/api/player/recovery", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const logData = insertRecoveryLogSchema.parse({
        ...req.body,
        userId: user.id,
        logDate: /* @__PURE__ */ new Date()
      });
      const log2 = await storage.createRecoveryLog(logData);
      const userLogs = await storage.getRecoveryLogs(user.id);
      if (userLogs.length === 1) {
        await storage.createAchievement({
          userId: user.id,
          title: "Recovery Tracking Started",
          description: "Started tracking your recovery and wellness",
          achievementType: "recovery",
          iconType: "heart",
          earnedDate: /* @__PURE__ */ new Date()
        });
      }
      return res.status(201).json(log2);
    } catch (error) {
      console.error("Error creating recovery log:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.get("/api/player/fan-club", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const followers = await storage.getFanClubFollowers(user.id);
      return res.json(followers);
    } catch (error) {
      console.error("Error fetching fan club followers:", error);
      return res.status(500).json({ message: "Error fetching fan club followers" });
    }
  });
  app2.post("/api/player/fan-club", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const athlete = await storage.getAthleteProfile(user.id);
      if (!athlete) {
        return res.status(403).json({ message: "Only athletes can have fan clubs" });
      }
      const followerData = insertFanClubFollowerSchema.parse({
        ...req.body,
        athleteId: user.id,
        followDate: /* @__PURE__ */ new Date()
      });
      const follower = await storage.createFanClubFollower(followerData);
      const followers = await storage.getFanClubFollowers(user.id);
      if (followers.length === 1) {
        await storage.createAchievement({
          userId: user.id,
          title: "First Fan",
          description: "Someone is following your athletic journey",
          achievementType: "fanclub",
          iconType: "users",
          earnedDate: /* @__PURE__ */ new Date()
        });
      } else if (followers.length === 10) {
        await storage.createAchievement({
          userId: user.id,
          title: "Rising Star",
          description: "Your fan club has reached 10 followers",
          achievementType: "fanclub",
          iconType: "star",
          earnedDate: /* @__PURE__ */ new Date()
        });
      } else if (followers.length === 50) {
        await storage.createAchievement({
          userId: user.id,
          title: "Local Celebrity",
          description: "Your fan club has reached 50 followers",
          achievementType: "fanclub",
          iconType: "award",
          earnedDate: /* @__PURE__ */ new Date()
        });
      }
      return res.status(201).json(follower);
    } catch (error) {
      console.error("Error creating fan club follower:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.get("/api/player/leaderboard/:category", isAuthenticated, async (req, res) => {
    try {
      const category = req.params.category;
      const entries = await storage.getLeaderboardEntries(category);
      return res.json(entries);
    } catch (error) {
      console.error("Error fetching leaderboard entries:", error);
      return res.status(500).json({ message: "Error fetching leaderboard entries" });
    }
  });
  app2.get("/api/player/leaderboard", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const entries = await storage.getLeaderboardEntriesByUser(user.id);
      return res.json(entries);
    } catch (error) {
      console.error("Error fetching user leaderboard entries:", error);
      return res.status(500).json({ message: "Error fetching user leaderboard entries" });
    }
  });
  app2.post("/api/player/leaderboard", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const entryData = insertLeaderboardEntrySchema.parse({
        ...req.body,
        userId: user.id,
        updatedAt: /* @__PURE__ */ new Date()
      });
      const existingEntry = await storage.getUserLeaderboardEntry(user.id, entryData.category);
      let entry;
      if (existingEntry) {
        if (entryData.score > existingEntry.score) {
          entry = await storage.updateLeaderboardEntry(existingEntry.id, {
            score: entryData.score,
            rankPosition: entryData.rankPosition,
            updatedAt: /* @__PURE__ */ new Date()
          });
        } else {
          entry = existingEntry;
        }
      } else {
        entry = await storage.createLeaderboardEntry(entryData);
      }
      await storage.recalculateLeaderboardRanks(entryData.category);
      return res.status(201).json(entry);
    } catch (error) {
      console.error("Error creating/updating leaderboard entry:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.get("/api/player/achievements", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const achievements2 = await storage.getAchievementsByUser(user.id);
      return res.json(achievements2);
    } catch (error) {
      console.error("Error fetching achievements:", error);
      return res.status(500).json({ message: "Error fetching achievements" });
    }
  });
  app2.get("/api/film-comparisons", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const comparisons = await storage.getFilmComparisons(user.id);
      return res.json(comparisons);
    } catch (error) {
      console.error("Error fetching film comparisons:", error);
      return res.status(500).json({ message: "Error fetching film comparisons" });
    }
  });
  app2.get("/api/film-comparisons/:id", isAuthenticated, async (req, res) => {
    try {
      const comparisonId = parseInt(req.params.id);
      const comparison = await storage.getFilmComparison(comparisonId);
      if (!comparison) {
        return res.status(404).json({ message: "Film comparison not found" });
      }
      const user = req.user;
      if (comparison.userId !== user.id && !comparison.isPublic && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to view this comparison" });
      }
      const videos3 = await storage.getComparisonVideos(comparisonId);
      const analysis = await storage.getComparisonAnalysis(comparisonId);
      return res.json({
        comparison,
        videos: videos3,
        analysis
      });
    } catch (error) {
      console.error("Error fetching film comparison:", error);
      return res.status(500).json({ message: "Error fetching film comparison" });
    }
  });
  app2.post("/api/film-comparisons", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const comparisonData = {
        ...req.body,
        userId: user.id
      };
      const comparison = await storage.createFilmComparison(comparisonData);
      return res.status(201).json(comparison);
    } catch (error) {
      console.error("Error creating film comparison:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.put("/api/film-comparisons/:id", isAuthenticated, async (req, res) => {
    try {
      const comparisonId = parseInt(req.params.id);
      const comparison = await storage.getFilmComparison(comparisonId);
      if (!comparison) {
        return res.status(404).json({ message: "Film comparison not found" });
      }
      const user = req.user;
      if (comparison.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to update this comparison" });
      }
      const updatedComparison = await storage.updateFilmComparison(comparisonId, req.body);
      return res.json(updatedComparison);
    } catch (error) {
      console.error("Error updating film comparison:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.delete("/api/film-comparisons/:id", isAuthenticated, async (req, res) => {
    try {
      const comparisonId = parseInt(req.params.id);
      const comparison = await storage.getFilmComparison(comparisonId);
      if (!comparison) {
        return res.status(404).json({ message: "Film comparison not found" });
      }
      const user = req.user;
      if (comparison.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to delete this comparison" });
      }
      const success = await storage.deleteFilmComparison(comparisonId);
      if (success) {
        return res.json({ message: "Film comparison deleted successfully" });
      } else {
        return res.status(500).json({ message: "Error deleting film comparison" });
      }
    } catch (error) {
      console.error("Error deleting film comparison:", error);
      return res.status(500).json({ message: "Error deleting film comparison" });
    }
  });
  app2.post("/api/film-comparisons/:id/videos", isAuthenticated, upload.single("video"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No video file uploaded" });
      }
      const comparisonId = parseInt(req.params.id);
      const comparison = await storage.getFilmComparison(comparisonId);
      if (!comparison) {
        return res.status(404).json({ message: "Film comparison not found" });
      }
      const user = req.user;
      if (comparison.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to add videos to this comparison" });
      }
      const uploadsDir2 = path8.join(process.cwd(), "uploads", "comparisons");
      if (!fs7.existsSync(uploadsDir2)) {
        fs7.mkdirSync(uploadsDir2, { recursive: true });
      }
      const filename = `${Date.now()}-${path8.basename(req.file.originalname)}`;
      const filePath = path8.join(uploadsDir2, filename);
      fs7.renameSync(req.file.path, filePath);
      const videoData = {
        comparisonId,
        title: req.body.title || "Untitled Video",
        description: req.body.description || "",
        filePath: `/uploads/comparisons/${filename}`,
        videoType: req.body.videoType || "reference",
        athlete: req.body.athlete || "",
        order: parseInt(req.body.order) || 1
      };
      const video = await storage.createComparisonVideo(videoData);
      return res.status(201).json(video);
    } catch (error) {
      console.error("Error adding comparison video:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.delete("/api/comparison-videos/:id", isAuthenticated, async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const video = await storage.getComparisonVideo(videoId);
      if (!video) {
        return res.status(404).json({ message: "Comparison video not found" });
      }
      const comparison = await storage.getFilmComparison(video.comparisonId);
      if (!comparison) {
        return res.status(404).json({ message: "Film comparison not found" });
      }
      const user = req.user;
      if (comparison.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to delete videos from this comparison" });
      }
      const success = await storage.deleteComparisonVideo(videoId);
      if (success) {
        return res.json({ message: "Comparison video deleted successfully" });
      } else {
        return res.status(500).json({ message: "Error deleting comparison video" });
      }
    } catch (error) {
      console.error("Error deleting comparison video:", error);
      return res.status(500).json({ message: "Error deleting comparison video" });
    }
  });
  app2.post("/api/film-comparisons/:id/analyze", isAuthenticated, async (req, res) => {
    try {
      const comparisonId = parseInt(req.params.id);
      const comparison = await storage.getFilmComparison(comparisonId);
      if (!comparison) {
        return res.status(404).json({ message: "Film comparison not found" });
      }
      const user = req.user;
      if (comparison.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to analyze this comparison" });
      }
      const videos3 = await storage.getComparisonVideos(comparisonId);
      if (videos3.length < 2) {
        return res.status(400).json({ message: "At least two videos are required for comparison analysis" });
      }
      await storage.updateFilmComparison(comparisonId, { status: "processing" });
      let analysis;
      if (comparison.sport === "football") {
        analysis = await footballCoachService.analyzeFootballFilm(comparisonId);
        if (!analysis) {
          return res.status(500).json({ message: "Error performing football film analysis" });
        }
      } else {
        const generalAnalysis = {
          comparisonId,
          findings: "Both videos show similar technique, with some differences in posture and follow-through.",
          improvementAreas: ["Body positioning", "Follow-through", "Timing"],
          overallScore: 78,
          techniqueSimilarity: 0.82,
          recommendations: "Focus on improving follow-through and timing to better match the reference example."
        };
        const existingAnalysis = await storage.getComparisonAnalysis(comparisonId);
        if (existingAnalysis) {
          analysis = await storage.updateComparisonAnalysis(existingAnalysis.id, generalAnalysis);
        } else {
          analysis = await storage.createComparisonAnalysis(generalAnalysis);
        }
      }
      await storage.updateFilmComparison(comparisonId, { status: "completed" });
      return res.json(analysis);
    } catch (error) {
      console.error("Error analyzing film comparison:", error);
      try {
        const comparisonId = parseInt(req.params.id);
        await storage.updateFilmComparison(comparisonId, { status: "failed" });
      } catch (updateError) {
        console.error("Error updating comparison status:", updateError);
      }
      return res.status(500).json({ message: "Error analyzing film comparison" });
    }
  });
  app2.get("/api/spotlight-profiles", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit) : void 0;
      const offset = req.query.offset ? parseInt(req.query.offset) : void 0;
      const category = req.query.category;
      let profiles;
      if (category) {
        profiles = await storage.getSpotlightProfilesByCategory(category, limit);
      } else {
        profiles = await storage.getSpotlightProfiles(limit, offset);
      }
      return res.json(profiles);
    } catch (error) {
      console.error("Error fetching spotlight profiles:", error);
      return res.status(500).json({ message: "Error fetching spotlight profiles" });
    }
  });
  app2.get("/api/spotlight-profiles/featured", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit) : void 0;
      const profiles = await storage.getFeaturedSpotlightProfiles(limit);
      return res.json(profiles);
    } catch (error) {
      console.error("Error fetching featured spotlight profiles:", error);
      return res.status(500).json({ message: "Error fetching featured spotlight profiles" });
    }
  });
  app2.get("/api/spotlight-profiles/:id", async (req, res) => {
    try {
      const profileId = parseInt(req.params.id);
      const profile = await storage.getSpotlightProfile(profileId);
      if (!profile) {
        return res.status(404).json({ message: "Spotlight profile not found" });
      }
      await storage.incrementSpotlightViews(profileId);
      const user = await storage.getUser(profile.userId);
      if (!user) {
        return res.status(404).json({ message: "Profile user not found" });
      }
      return res.json({
        ...profile,
        user: {
          id: user.id,
          username: user.username,
          name: user.name,
          profileImage: user.profileImage
        }
      });
    } catch (error) {
      console.error("Error fetching spotlight profile:", error);
      return res.status(500).json({ message: "Error fetching spotlight profile" });
    }
  });
  app2.post("/api/spotlight-profiles/:id/like", isAuthenticated, async (req, res) => {
    try {
      const profileId = parseInt(req.params.id);
      const profile = await storage.getSpotlightProfile(profileId);
      if (!profile) {
        return res.status(404).json({ message: "Spotlight profile not found" });
      }
      const updatedProfile = await storage.likeSpotlightProfile(profileId);
      return res.json(updatedProfile);
    } catch (error) {
      console.error("Error liking spotlight profile:", error);
      return res.status(500).json({ message: "Error liking spotlight profile" });
    }
  });
  app2.post("/api/spotlight-profiles", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const existingProfile = await storage.getSpotlightProfileByUserId(user.id);
      if (existingProfile) {
        return res.status(400).json({ message: "User already has a spotlight profile" });
      }
      const profileData = {
        ...req.body,
        userId: user.id
      };
      const profile = await storage.createSpotlightProfile(profileData);
      return res.status(201).json(profile);
    } catch (error) {
      console.error("Error creating spotlight profile:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.put("/api/spotlight-profiles/:id", isAuthenticated, async (req, res) => {
    try {
      const profileId = parseInt(req.params.id);
      const profile = await storage.getSpotlightProfile(profileId);
      if (!profile) {
        return res.status(404).json({ message: "Spotlight profile not found" });
      }
      const user = req.user;
      if (profile.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to update this profile" });
      }
      const updatedProfile = await storage.updateSpotlightProfile(profileId, req.body);
      return res.json(updatedProfile);
    } catch (error) {
      console.error("Error updating spotlight profile:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.delete("/api/spotlight-profiles/:id", isAuthenticated, async (req, res) => {
    try {
      const profileId = parseInt(req.params.id);
      const profile = await storage.getSpotlightProfile(profileId);
      if (!profile) {
        return res.status(404).json({ message: "Spotlight profile not found" });
      }
      const user = req.user;
      if (profile.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to delete this profile" });
      }
      const success = await storage.deleteSpotlightProfile(profileId);
      if (success) {
        return res.json({ message: "Spotlight profile deleted successfully" });
      } else {
        return res.status(500).json({ message: "Error deleting spotlight profile" });
      }
    } catch (error) {
      console.error("Error deleting spotlight profile:", error);
      return res.status(500).json({ message: "Error deleting spotlight profile" });
    }
  });
  app2.get("/api/player/progress", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const progress = await storage.getPlayerProgress(user.id);
      if (!progress) {
        const newProgress = await storage.createPlayerProgress({
          userId: user.id,
          level: 1,
          totalXp: 0,
          currentLevelXp: 0,
          nextLevelXp: 100,
          streak: 0
        });
        return res.json(newProgress);
      }
      return res.json(progress);
    } catch (error) {
      console.error("Error fetching player progress:", error);
      return res.status(500).json({ message: "Error fetching player progress" });
    }
  });
  app2.get("/api/player/xp/transactions", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const limit = req.query.limit ? parseInt(req.query.limit) : void 0;
      const transactions = await storage.getXpTransactions(user.id, limit);
      return res.json(transactions);
    } catch (error) {
      console.error("Error fetching XP transactions:", error);
      return res.status(500).json({ message: "Error fetching XP transactions" });
    }
  });
  app2.post("/api/player/xp/award", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      if (user.role !== "admin" && user.role !== "coach") {
        return res.status(403).json({ message: "Not authorized to award XP" });
      }
      const { userId, amount, type, description, sourceId } = req.body;
      if (!userId || !amount || !type || !description) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      const result = await storage.addXpToPlayer(userId, amount, type, description, sourceId);
      return res.json(result);
    } catch (error) {
      console.error("Error awarding XP:", error);
      return res.status(500).json({ message: "Error awarding XP" });
    }
  });
  app2.post("/api/player/xp/daily-login", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const today = /* @__PURE__ */ new Date();
      today.setHours(0, 0, 0, 0);
      const recentTransactions = await storage.getXpTransactions(user.id, 10);
      const alreadyAwarded = recentTransactions.some((tx) => {
        const txDate = new Date(tx.awarded);
        txDate.setHours(0, 0, 0, 0);
        return txDate.getTime() === today.getTime() && tx.type === "daily_login";
      });
      if (alreadyAwarded) {
        return res.status(400).json({ message: "Already received daily login XP today" });
      }
      const result = await storage.addXpToPlayer(
        user.id,
        25,
        "daily_login",
        "Daily login bonus"
      );
      return res.json(result);
    } catch (error) {
      console.error("Error processing daily login XP:", error);
      return res.status(500).json({ message: "Error processing daily login XP" });
    }
  });
  app2.get("/api/player/badges", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const category = req.query.category;
      let badges;
      if (category) {
        badges = await storage.getPlayerBadgesByCategory(user.id, category);
      } else {
        badges = await storage.getPlayerBadges(user.id);
      }
      return res.json(badges);
    } catch (error) {
      console.error("Error fetching player badges:", error);
      return res.status(500).json({ message: "Error fetching player badges" });
    }
  });
  app2.post("/api/player/badges", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      if (user.role !== "admin" && user.role !== "coach") {
        return res.status(403).json({ message: "Not authorized to award badges" });
      }
      const badgeData = {
        ...req.body,
        userId: req.body.userId || user.id
      };
      const badge = await storage.createPlayerBadge(badgeData);
      await storage.addXpToPlayer(
        badgeData.userId,
        50,
        "badge_earned",
        `Earned ${badgeData.name} badge`,
        String(badge.id)
      );
      return res.status(201).json(badge);
    } catch (error) {
      console.error("Error creating player badge:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.get("/api/workout-verifications", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const verifications = await storage.getWorkoutVerifications(user.id);
      return res.json(verifications);
    } catch (error) {
      console.error("Error fetching workout verifications:", error);
      return res.status(500).json({ message: "Error fetching workout verifications" });
    }
  });
  app2.get("/api/workout-verifications/pending", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      if (user.role !== "coach" && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to view all pending verifications" });
      }
      const verifications = await storage.getPendingWorkoutVerifications();
      return res.json(verifications);
    } catch (error) {
      console.error("Error fetching pending workout verifications:", error);
      return res.status(500).json({ message: "Error fetching pending workout verifications" });
    }
  });
  app2.get("/api/workout-verifications/:id", isAuthenticated, async (req, res) => {
    try {
      const verificationId = parseInt(req.params.id);
      const verification = await storage.getWorkoutVerification(verificationId);
      if (!verification) {
        return res.status(404).json({ message: "Workout verification not found" });
      }
      const user = req.user;
      if (verification.userId !== user.id && user.role !== "coach" && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to view this verification" });
      }
      const checkpoints = await storage.getWorkoutVerificationCheckpoints(verificationId);
      return res.json({
        verification,
        checkpoints
      });
    } catch (error) {
      console.error("Error fetching workout verification:", error);
      return res.status(500).json({ message: "Error fetching workout verification" });
    }
  });
  app2.post("/api/workout-verifications", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      console.log("Workout verification request:", {
        user: user ? { id: user.id, role: user.role } : "No user",
        bodyKeys: Object.keys(req.body),
        mediaUrls: req.body.mediaUrls ? "Present" : "Not present"
      });
      let mediaUrls = [];
      if (req.body.mediaUrls) {
        if (Array.isArray(req.body.mediaUrls)) {
          mediaUrls = req.body.mediaUrls;
        } else if (typeof req.body.mediaUrls === "string") {
          try {
            mediaUrls = JSON.parse(req.body.mediaUrls);
          } catch (e) {
            console.error("Error parsing mediaUrls:", e);
          }
        }
      }
      const verificationData = {
        userId: user.id,
        title: req.body.workoutTitle || req.body.title,
        // Support both field names for robustness
        verificationStatus: "pending",
        duration: parseInt(req.body.duration) || 0,
        proofType: "video",
        // We're using video for verification
        proofData: mediaUrls.length > 0 ? mediaUrls[0] : "",
        // Use the first video URL
        notes: req.body.description || "",
        verificationMethod: "AI"
        // Using AI for verification
      };
      const verification = await storage.createWorkoutVerification(verificationData);
      if (req.body.checkpoints) {
        let checkpoints;
        try {
          checkpoints = JSON.parse(req.body.checkpoints);
        } catch (e) {
          return res.status(400).json({ message: "Invalid checkpoints data format" });
        }
        if (Array.isArray(checkpoints)) {
          for (const checkpoint of checkpoints) {
            await storage.createWorkoutVerificationCheckpoint({
              verificationId: verification.id,
              exerciseName: checkpoint.exerciseName,
              isCompleted: checkpoint.isCompleted || false,
              completedAmount: checkpoint.completedAmount,
              targetAmount: checkpoint.targetAmount,
              feedback: checkpoint.feedback || "",
              mediaProof: checkpoint.mediaProof || "",
              checkpointOrder: checkpoint.checkpointOrder || 0
            });
          }
        }
      }
      return res.status(201).json(verification);
    } catch (error) {
      console.error("Error creating workout verification:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.post("/api/workout-verifications/:id/verify", isAuthenticated, async (req, res) => {
    try {
      const verificationId = parseInt(req.params.id);
      const verification = await storage.getWorkoutVerification(verificationId);
      if (!verification) {
        return res.status(404).json({ message: "Workout verification not found" });
      }
      const user = req.user;
      if (user.role !== "coach" && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to verify workouts" });
      }
      const { status, notes } = req.body;
      if (!status || status !== "approved" && status !== "rejected") {
        return res.status(400).json({ message: "Invalid status value" });
      }
      const updatedVerification = await storage.verifyWorkout(
        verificationId,
        user.id,
        status,
        notes
      );
      return res.json(updatedVerification);
    } catch (error) {
      console.error("Error verifying workout:", error);
      return res.status(500).json({ message: "Error verifying workout" });
    }
  });
  app2.post("/api/workout-verifications/:id/analyze", isAuthenticated, async (req, res) => {
    try {
      const verificationId = parseInt(req.params.id);
      const { videoPath, checkpointId } = req.body;
      if (!videoPath) {
        return res.status(400).json({ message: "Video path is required" });
      }
      const verification = await storage.getWorkoutVerification(verificationId);
      if (!verification) {
        return res.status(404).json({ message: "Workout verification not found" });
      }
      const user = req.user;
      if (verification.userId !== user.id && user.role !== "coach" && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to analyze this workout" });
      }
      const { analyzeWorkoutVerification: analyzeWorkoutVerification2 } = await Promise.resolve().then(() => (init_openai(), openai_exports));
      const analysis = await analyzeWorkoutVerification2(verificationId, videoPath);
      if (checkpointId) {
        await storage.updateWorkoutVerificationCheckpoint(parseInt(checkpointId), {
          isCompleted: analysis.isCompleted,
          completedAmount: analysis.completedAmount,
          feedback: analysis.feedback,
          mediaProof: videoPath
        });
      }
      if (analysis.isCompleted) {
        const checkpoints = await storage.getWorkoutVerificationCheckpoints(verificationId);
        const allCompleted = checkpoints.every((c) => c.isCompleted);
        if (allCompleted) {
          const baseXp = Math.round(analysis.completedAmount * (analysis.repAccuracy / 100) * 10);
          const xpEarned = Math.max(50, baseXp);
          await storage.verifyWorkout(
            verificationId,
            user.id,
            "approved",
            xpEarned,
            "Automatically verified by AI analysis"
          );
          analysis.xpEarned = xpEarned;
        }
      }
      res.json(analysis);
    } catch (error) {
      console.error("Error analyzing workout video:", error);
      res.status(500).json({ message: "Failed to analyze workout video" });
    }
  });
  app2.get("/api/weight-room/equipment", async (req, res) => {
    try {
      const category = req.query.category;
      const equipment = await storage.getWeightRoomEquipment(category);
      return res.json(equipment);
    } catch (error) {
      console.error("Error fetching weight room equipment:", error);
      return res.status(500).json({ message: "Error fetching weight room equipment" });
    }
  });
  app2.get("/api/weight-room/equipment/:id", async (req, res) => {
    try {
      const equipmentId = parseInt(req.params.id);
      const equipment = await storage.getWeightRoomEquipmentById(equipmentId);
      if (!equipment) {
        return res.status(404).json({ message: "Equipment not found" });
      }
      return res.json(equipment);
    } catch (error) {
      console.error("Error fetching weight room equipment:", error);
      return res.status(500).json({ message: "Error fetching weight room equipment" });
    }
  });
  app2.get("/api/weight-room/ai-coach/workout-plan", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.id;
      const skillLevel = parseInt(req.query.level) || 1;
      const goals = req.query.goals ? String(req.query.goals).split(",") : ["Strength", "Speed", "Endurance"];
      const equipmentList = await storage.getWeightRoomEquipment();
      const { generateWeightRoomPlan: generateWeightRoomPlan2 } = await Promise.resolve().then(() => (init_openai(), openai_exports));
      const workoutPlan = await generateWeightRoomPlan2(userId, equipmentList, skillLevel, goals);
      return res.json(workoutPlan);
    } catch (error) {
      console.error("Error generating AI workout plan:", error);
      return res.status(500).json({ message: "Error generating AI workout plan" });
    }
  });
  app2.post("/api/weight-room/ai-coach/form-feedback", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.id;
      const { equipmentId, formDescription } = req.body;
      if (!equipmentId || !formDescription) {
        return res.status(400).json({ message: "Equipment ID and form description are required" });
      }
      const { getFormFeedback: getFormFeedback2 } = await Promise.resolve().then(() => (init_openai(), openai_exports));
      const feedback = await getFormFeedback2(userId, equipmentId, formDescription);
      return res.json(feedback);
    } catch (error) {
      console.error("Error generating form feedback:", error);
      return res.status(500).json({ message: "Error generating form feedback" });
    }
  });
  app2.get("/api/player/equipment", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const equipment = await storage.getPlayerEquipment(user.id);
      return res.json(equipment);
    } catch (error) {
      console.error("Error fetching player equipment:", error);
      return res.status(500).json({ message: "Error fetching player equipment" });
    }
  });
  app2.get("/api/player/ai-coach/state", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const coachState = {
        personality: "Supportive and motivational",
        specialization: "Performance Development",
        activeTab: "chat",
        knowledgeAreas: ["Technique Analysis", "Training Programs", "Recovery", "Nutrition", "Sports Psychology"],
        experienceLevel: "intermediate",
        lastInteraction: /* @__PURE__ */ new Date()
      };
      return res.json(coachState);
    } catch (error) {
      console.error("Error fetching AI coach state:", error);
      return res.status(500).json({ message: "Error fetching AI coach state" });
    }
  });
  app2.get("/api/player/ai-coach/messages", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const messages2 = [
        {
          id: "1",
          role: "coach",
          content: "Hey there! I'm your AI Coach. I'm here to help you improve your performance, analyze your technique, and create personalized training plans.",
          timestamp: new Date(Date.now() - 864e5),
          type: "text"
        },
        {
          id: "2",
          role: "coach",
          content: "What would you like to work on today?",
          timestamp: new Date(Date.now() - 864e5),
          type: "text"
        }
      ];
      return res.json(messages2);
    } catch (error) {
      console.error("Error fetching AI coach messages:", error);
      return res.status(500).json({ message: "Error fetching AI coach messages" });
    }
  });
  app2.post("/api/player/ai-coach/messages", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const { content } = req.body;
      if (!content) {
        return res.status(400).json({ message: "Message content is required" });
      }
      const previousMessages = [];
      const { generateAICoachResponse: generateAICoachResponse2 } = await Promise.resolve().then(() => (init_openai(), openai_exports));
      const response = await generateAICoachResponse2(user.id, content, previousMessages);
      const userMessage = {
        id: Date.now().toString(),
        role: "user",
        content,
        timestamp: /* @__PURE__ */ new Date(),
        type: "text"
      };
      const coachMessage = {
        id: (Date.now() + 1).toString(),
        role: "coach",
        content: response.content,
        timestamp: /* @__PURE__ */ new Date(),
        type: response.metadata ? "workout" : "text",
        metadata: response.metadata
      };
      return res.json([userMessage, coachMessage]);
    } catch (error) {
      console.error("Error generating AI coach response:", error);
      return res.status(500).json({ message: "Error generating AI coach response" });
    }
  });
  app2.post("/api/player/ai-coach/messages/:messageId/rate", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const messageId = req.params.messageId;
      const { isHelpful } = req.body;
      if (typeof isHelpful !== "boolean") {
        return res.status(400).json({ message: "Rating must be true or false" });
      }
      return res.json({ success: true, messageId });
    } catch (error) {
      console.error("Error rating AI coach message:", error);
      return res.status(500).json({ message: "Error rating AI coach message" });
    }
  });
  app2.post("/api/player/ai-coach/realtime-feedback", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const { exerciseType, performanceData } = req.body;
      if (!exerciseType || !performanceData) {
        return res.status(400).json({ message: "Exercise type and performance data are required" });
      }
      const { generateRealTimeWorkoutFeedback: generateRealTimeWorkoutFeedback2 } = await Promise.resolve().then(() => (init_openai(), openai_exports));
      const feedback = await generateRealTimeWorkoutFeedback2(user.id, exerciseType, performanceData);
      return res.json(feedback);
    } catch (error) {
      console.error("Error generating real-time feedback:", error);
      return res.status(500).json({ message: "Error generating real-time feedback" });
    }
  });
  app2.post("/api/player/ai-coach/training-plan", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const { goals, durationWeeks, daysPerWeek, focusAreas } = req.body;
      const { generatePersonalizedTrainingPlan: generatePersonalizedTrainingPlan2 } = await Promise.resolve().then(() => (init_openai(), openai_exports));
      const trainingPlan = await generatePersonalizedTrainingPlan2(
        user.id,
        goals || ["Overall Performance"],
        durationWeeks || 4,
        daysPerWeek || 3,
        focusAreas || []
      );
      return res.json(trainingPlan);
    } catch (error) {
      console.error("Error generating training plan:", error);
      return res.status(500).json({ message: "Error generating training plan" });
    }
  });
  app2.post("/api/player/equipment", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const { equipmentId } = req.body;
      if (!equipmentId) {
        return res.status(400).json({ message: "Equipment ID is required" });
      }
      const equipment = await storage.getWeightRoomEquipmentById(equipmentId);
      if (!equipment) {
        return res.status(404).json({ message: "Equipment not found" });
      }
      const playerEquipment2 = await storage.getPlayerEquipment(user.id);
      const alreadyOwned = playerEquipment2.some((item) => item.equipmentId === equipmentId);
      if (alreadyOwned) {
        return res.status(400).json({ message: "Player already owns this equipment" });
      }
      const progress = await storage.getPlayerProgress(user.id);
      if (!progress) {
        return res.status(400).json({ message: "Player progress not found" });
      }
      if (progress.currentLevel < equipment.unlockLevel) {
        return res.status(400).json({
          message: `Player must reach level ${equipment.unlockLevel} to unlock this equipment`
        });
      }
      const newPlayerEquipment = await storage.createPlayerEquipment({
        userId: user.id,
        equipmentId: equipment.id,
        isFavorite: false
      });
      return res.status(201).json(newPlayerEquipment);
    } catch (error) {
      console.error("Error acquiring equipment:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.put("/api/player/equipment/:id/activate", isAuthenticated, async (req, res) => {
    try {
      const equipmentId = parseInt(req.params.id);
      const user = req.user;
      const playerEquipment2 = await storage.getPlayerEquipmentById(equipmentId);
      if (!playerEquipment2) {
        return res.status(404).json({ message: "Player equipment not found" });
      }
      if (playerEquipment2.userId !== user.id) {
        return res.status(403).json({ message: "Not authorized to activate this equipment" });
      }
      const updatedEquipment = await storage.updatePlayerEquipment(equipmentId, { isFavorite: true });
      await storage.incrementEquipmentUsage(equipmentId);
      if ((playerEquipment2.timesUsed || 0) === 0) {
        await storage.addXpToPlayer(
          user.id,
          15,
          "equipment_use",
          `First time using ${equipmentId}`,
          String(equipmentId)
        );
      }
      return res.json(updatedEquipment);
    } catch (error) {
      console.error("Error activating equipment:", error);
      return res.status(500).json({ message: "Error activating equipment" });
    }
  });
  app2.put("/api/player/equipment/:id/deactivate", isAuthenticated, async (req, res) => {
    try {
      const equipmentId = parseInt(req.params.id);
      const user = req.user;
      const playerEquipment2 = await storage.getPlayerEquipmentById(equipmentId);
      if (!playerEquipment2) {
        return res.status(404).json({ message: "Player equipment not found" });
      }
      if (playerEquipment2.userId !== user.id) {
        return res.status(403).json({ message: "Not authorized to deactivate this equipment" });
      }
      const updatedEquipment = await storage.updatePlayerEquipment(equipmentId, { isFavorite: false });
      return res.json(updatedEquipment);
    } catch (error) {
      console.error("Error deactivating equipment:", error);
      return res.status(500).json({ message: "Error deactivating equipment" });
    }
  });
  app2.get("/api/combine-tour/events", async (req, res) => {
    try {
      const events = await storage.getCombineTourEvents();
      return res.json(events);
    } catch (error) {
      console.error("Error fetching combine tour events:", error);
      return res.status(500).json({ message: "Error fetching combine tour events" });
    }
  });
  app2.get("/api/combine-tour/events/:id", async (req, res) => {
    try {
      const eventId = parseInt(req.params.id);
      const event = await storage.getCombineTourEvent(eventId);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      return res.json(event);
    } catch (error) {
      console.error("Error fetching combine tour event:", error);
      return res.status(500).json({ message: "Error fetching combine tour event" });
    }
  });
  app2.post("/api/combine-tour/events", isAdmin, async (req, res) => {
    try {
      const eventData = req.body;
      const activeNetworkEvent = await active_network_default.createEvent({
        name: eventData.name,
        description: eventData.description,
        location: eventData.location,
        startDate: eventData.startDate,
        endDate: eventData.endDate,
        capacity: eventData.capacity,
        fee: eventData.price
      });
      const event = await storage.createCombineTourEvent({
        ...eventData,
        activeNetworkId: activeNetworkEvent.id,
        registrationUrl: activeNetworkEvent.registrationUrl,
        slug: eventData.name.toLowerCase().replace(/\s+/g, "-")
      });
      return res.status(201).json(event);
    } catch (error) {
      console.error("Error creating combine tour event:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.put("/api/combine-tour/events/:id", isAdmin, async (req, res) => {
    try {
      const eventId = parseInt(req.params.id);
      const eventData = req.body;
      const currentEvent = await storage.getCombineTourEvent(eventId);
      if (!currentEvent) {
        return res.status(404).json({ message: "Event not found" });
      }
      const updatedEvent = await storage.updateCombineTourEvent(eventId, eventData);
      return res.json(updatedEvent);
    } catch (error) {
      console.error("Error updating combine tour event:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.get("/api/combine-tour/events/:id/register", isAuthenticated, async (req, res) => {
    try {
      const eventId = parseInt(req.params.id);
      const registrationInfo = await active_network_default.getRegistrationUrl(eventId);
      return res.json({
        registrationUrl: registrationInfo.registrationUrl,
        eventId,
        activeNetworkId: registrationInfo.activeNetworkId
      });
    } catch (error) {
      console.error("Error getting registration URL:", error);
      return res.status(500).json({ message: "Error getting registration URL" });
    }
  });
  app2.get("/api/combine-tour/registration-status", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const eventId = parseInt(req.query.eventId);
      if (!eventId) {
        return res.status(400).json({ message: "Event ID is required" });
      }
      const status = await active_network_default.checkRegistrationStatus(user.id, eventId);
      return res.json(status);
    } catch (error) {
      console.error("Error checking registration status:", error);
      return res.status(500).json({ message: "Error checking registration status" });
    }
  });
  app2.post("/api/combine-tour/webhook", async (req, res) => {
    try {
      const result = await active_network_default.processWebhook(req.body);
      return res.json(result);
    } catch (error) {
      console.error("Error processing webhook:", error);
      return res.status(400).json({ message: error.message });
    }
  });
  app2.get("/api/blog-posts", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit) || 20;
      const offset = parseInt(req.query.offset) || 0;
      const blogPosts3 = await storage.getBlogPosts(limit, offset);
      res.json(blogPosts3);
    } catch (error) {
      console.error("Error fetching blog posts:", error);
      res.status(500).json({ message: "Error fetching blog posts" });
    }
  });
  app2.get("/api/blog-posts/featured", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit) || 5;
      const featuredPosts = await storage.getFeaturedBlogPosts(limit);
      res.json(featuredPosts);
    } catch (error) {
      console.error("Error fetching featured blog posts:", error);
      res.status(500).json({ message: "Error fetching featured blog posts" });
    }
  });
  app2.get("/api/blog-posts/category/:category", async (req, res) => {
    try {
      const category = req.params.category;
      const limit = parseInt(req.query.limit) || 10;
      const posts = await storage.getBlogPostsByCategory(category, limit);
      res.json(posts);
    } catch (error) {
      console.error("Error fetching blog posts by category:", error);
      res.status(500).json({ message: "Error fetching blog posts by category" });
    }
  });
  app2.get("/api/blog-posts/:slug", async (req, res) => {
    try {
      const slug = req.params.slug;
      const post = await storage.getBlogPostBySlug(slug);
      if (!post) {
        return res.status(404).json({ message: "Blog post not found" });
      }
      res.json(post);
    } catch (error) {
      console.error("Error fetching blog post:", error);
      res.status(500).json({ message: "Error fetching blog post" });
    }
  });
  app2.post("/api/blog-posts", isAdmin, async (req, res) => {
    try {
      const postData = insertBlogPostSchema.parse(req.body);
      const post = await storage.createBlogPost(postData);
      res.status(201).json(post);
    } catch (error) {
      console.error("Error creating blog post:", error);
      res.status(400).json({ message: error.message });
    }
  });
  app2.put("/api/blog-posts/:id", isAdmin, async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const postData = insertBlogPostSchema.partial().parse(req.body);
      const updatedPost = await storage.updateBlogPost(postId, postData);
      if (!updatedPost) {
        return res.status(404).json({ message: "Blog post not found" });
      }
      res.json(updatedPost);
    } catch (error) {
      console.error("Error updating blog post:", error);
      res.status(400).json({ message: error.message });
    }
  });
  app2.delete("/api/blog-posts/:id", isAdmin, async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const success = await storage.deleteBlogPost(postId);
      if (!success) {
        return res.status(404).json({ message: "Blog post not found" });
      }
      res.json({ message: "Blog post deleted successfully" });
    } catch (error) {
      console.error("Error deleting blog post:", error);
      res.status(500).json({ message: "Error deleting blog post" });
    }
  });
  app2.post("/api/admin/blog-posts/generate", isAdmin, async (req, res) => {
    try {
      const { createAIBlogPost: createAIBlogPost2 } = await Promise.resolve().then(() => (init_blog_generator(), blog_generator_exports));
      const adminUserId = req.user.id;
      const success = await createAIBlogPost2(adminUserId);
      if (success) {
        res.status(201).json({
          success: true,
          message: "New AI blog post generated successfully"
        });
      } else {
        res.status(500).json({
          success: false,
          message: "Failed to generate blog post. Check OpenAI API key and server logs."
        });
      }
    } catch (error) {
      console.error("Error generating AI blog post:", error);
      res.status(500).json({
        success: false,
        message: "Error generating AI blog post",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  app2.get("/api/featured-athletes", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit) || 4;
      const athletes = await storage.getFeaturedAthletes(limit);
      const enrichedAthletes = await Promise.all(athletes.map(async (athlete) => {
        const user = await storage.getUser(athlete.userId);
        return {
          ...athlete,
          name: user?.name || "",
          username: user?.username || "",
          profileImage: user?.profileImage || athlete.coverImage
        };
      }));
      res.json(enrichedAthletes);
    } catch (error) {
      console.error("Error fetching featured athletes:", error);
      res.status(500).json({ message: "Error fetching featured athletes" });
    }
  });
  app2.get("/api/featured-athletes/:id", async (req, res) => {
    try {
      const athleteId = parseInt(req.params.id);
      const athlete = await storage.getFeaturedAthlete(athleteId);
      if (!athlete) {
        return res.status(404).json({ message: "Featured athlete not found" });
      }
      const user = await storage.getUser(athlete.userId);
      res.json({
        ...athlete,
        name: user?.name || "",
        username: user?.username || "",
        profileImage: user?.profileImage || athlete.coverImage
      });
    } catch (error) {
      console.error("Error fetching featured athlete:", error);
      res.status(500).json({ message: "Error fetching featured athlete" });
    }
  });
  app2.post("/api/featured-athletes", isAdmin, async (req, res) => {
    try {
      const athleteData = insertFeaturedAthleteSchema.parse(req.body);
      const athlete = await storage.createFeaturedAthlete(athleteData);
      res.status(201).json(athlete);
    } catch (error) {
      console.error("Error creating featured athlete:", error);
      res.status(400).json({ message: error.message });
    }
  });
  app2.put("/api/featured-athletes/:id", isAdmin, async (req, res) => {
    try {
      const athleteId = parseInt(req.params.id);
      const athleteData = insertFeaturedAthleteSchema.partial().parse(req.body);
      const updatedAthlete = await storage.updateFeaturedAthlete(athleteId, athleteData);
      if (!updatedAthlete) {
        return res.status(404).json({ message: "Featured athlete not found" });
      }
      res.json(updatedAthlete);
    } catch (error) {
      console.error("Error updating featured athlete:", error);
      res.status(400).json({ message: error.message });
    }
  });
  app2.delete("/api/featured-athletes/:id", isAdmin, async (req, res) => {
    try {
      const athleteId = parseInt(req.params.id);
      const success = await storage.deactivateFeaturedAthlete(athleteId);
      if (!success) {
        return res.status(404).json({ message: "Featured athlete not found" });
      }
      res.json({ message: "Featured athlete deactivated successfully" });
    } catch (error) {
      console.error("Error deactivating featured athlete:", error);
      res.status(500).json({ message: "Error deactivating featured athlete" });
    }
  });
  app2.get("/api/workout-playlists", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.id;
      const playlists = await storage.getWorkoutPlaylists(userId);
      res.json(playlists);
    } catch (error) {
      console.error("Error retrieving workout playlists:", error);
      res.status(500).json({ message: "Error retrieving workout playlists" });
    }
  });
  app2.get("/api/workout-playlists/public", async (req, res) => {
    try {
      const workoutType = req.query.workoutType;
      const intensityLevel = req.query.intensityLevel;
      const playlists = await storage.getPublicWorkoutPlaylists(workoutType, intensityLevel);
      res.json(playlists);
    } catch (error) {
      console.error("Error retrieving public workout playlists:", error);
      res.status(500).json({ message: "Error retrieving public workout playlists" });
    }
  });
  app2.get("/api/workout-playlists/:id", isAuthenticated, async (req, res) => {
    try {
      const playlistId = parseInt(req.params.id);
      const playlist = await storage.getWorkoutPlaylist(playlistId);
      if (!playlist) {
        return res.status(404).json({ message: "Workout playlist not found" });
      }
      if (!playlist.isPublic && playlist.userId !== req.user.id) {
        return res.status(403).json({ message: "You don't have permission to access this playlist" });
      }
      res.json(playlist);
    } catch (error) {
      console.error("Error retrieving workout playlist:", error);
      res.status(500).json({ message: "Error retrieving workout playlist" });
    }
  });
  app2.post("/api/workout-playlists", isAuthenticated, async (req, res) => {
    try {
      const playlistData = insertWorkoutPlaylistSchema.parse({
        ...req.body,
        userId: req.user.id
      });
      const newPlaylist = await storage.createWorkoutPlaylist(playlistData);
      res.status(201).json(newPlaylist);
    } catch (error) {
      console.error("Error creating workout playlist:", error);
      res.status(400).json({ message: error.message });
    }
  });
  app2.put("/api/workout-playlists/:id", isAuthenticated, async (req, res) => {
    try {
      const playlistId = parseInt(req.params.id);
      const existingPlaylist = await storage.getWorkoutPlaylist(playlistId);
      if (!existingPlaylist) {
        return res.status(404).json({ message: "Workout playlist not found" });
      }
      if (existingPlaylist.userId !== req.user.id) {
        return res.status(403).json({ message: "You don't have permission to update this playlist" });
      }
      const updatedPlaylist = await storage.updateWorkoutPlaylist(playlistId, req.body);
      res.json(updatedPlaylist);
    } catch (error) {
      console.error("Error updating workout playlist:", error);
      res.status(400).json({ message: error.message });
    }
  });
  app2.delete("/api/workout-playlists/:id", isAuthenticated, async (req, res) => {
    try {
      const playlistId = parseInt(req.params.id);
      const existingPlaylist = await storage.getWorkoutPlaylist(playlistId);
      if (!existingPlaylist) {
        return res.status(404).json({ message: "Workout playlist not found" });
      }
      if (existingPlaylist.userId !== req.user.id) {
        return res.status(403).json({ message: "You don't have permission to delete this playlist" });
      }
      const success = await storage.deleteWorkoutPlaylist(playlistId);
      if (!success) {
        return res.status(500).json({ message: "Failed to delete workout playlist" });
      }
      res.json({ message: "Workout playlist deleted successfully" });
    } catch (error) {
      console.error("Error deleting workout playlist:", error);
      res.status(500).json({ message: "Error deleting workout playlist" });
    }
  });
  app2.post("/api/workout-playlists/:id/use", isAuthenticated, async (req, res) => {
    try {
      const playlistId = parseInt(req.params.id);
      const existingPlaylist = await storage.getWorkoutPlaylist(playlistId);
      if (!existingPlaylist) {
        return res.status(404).json({ message: "Workout playlist not found" });
      }
      const updatedPlaylist = await storage.incrementPlaylistUsage(playlistId);
      res.json(updatedPlaylist);
    } catch (error) {
      console.error("Error updating playlist usage:", error);
      res.status(500).json({ message: "Error updating playlist usage" });
    }
  });
  app2.get("/api/workout-playlists/:id/exercises", isAuthenticated, async (req, res) => {
    try {
      const playlistId = parseInt(req.params.id);
      const playlist = await storage.getWorkoutPlaylist(playlistId);
      if (!playlist) {
        return res.status(404).json({ message: "Workout playlist not found" });
      }
      if (!playlist.isPublic && playlist.userId !== req.user.id) {
        return res.status(403).json({ message: "You don't have permission to access this playlist" });
      }
      const exercises = await storage.getWorkoutExercises(playlistId);
      res.json(exercises);
    } catch (error) {
      console.error("Error retrieving workout exercises:", error);
      res.status(500).json({ message: "Error retrieving workout exercises" });
    }
  });
  app2.post("/api/workout-playlists/:id/exercises", isAuthenticated, async (req, res) => {
    try {
      const playlistId = parseInt(req.params.id);
      const playlist = await storage.getWorkoutPlaylist(playlistId);
      if (!playlist) {
        return res.status(404).json({ message: "Workout playlist not found" });
      }
      if (playlist.userId !== req.user.id) {
        return res.status(403).json({ message: "You don't have permission to add exercises to this playlist" });
      }
      const exerciseData = insertWorkoutExerciseSchema.parse({
        ...req.body,
        playlistId
      });
      const newExercise = await storage.createWorkoutExercise(exerciseData);
      res.status(201).json(newExercise);
    } catch (error) {
      console.error("Error creating workout exercise:", error);
      res.status(400).json({ message: error.message });
    }
  });
  app2.put("/api/workout-exercises/:id", isAuthenticated, async (req, res) => {
    try {
      const exerciseId = parseInt(req.params.id);
      const exercise = await storage.getWorkoutExercises(exerciseId);
      if (!exercise) {
        return res.status(404).json({ message: "Workout exercise not found" });
      }
      const playlist = await storage.getWorkoutPlaylist(exercise.playlistId);
      if (!playlist || playlist.userId !== req.user.id) {
        return res.status(403).json({ message: "You don't have permission to update this exercise" });
      }
      const updatedExercise = await storage.updateWorkoutExercise(exerciseId, req.body);
      res.json(updatedExercise);
    } catch (error) {
      console.error("Error updating workout exercise:", error);
      res.status(400).json({ message: error.message });
    }
  });
  app2.delete("/api/workout-exercises/:id", isAuthenticated, async (req, res) => {
    try {
      const exerciseId = parseInt(req.params.id);
      const exercise = await storage.getWorkoutExercises(exerciseId);
      if (!exercise) {
        return res.status(404).json({ message: "Workout exercise not found" });
      }
      const playlist = await storage.getWorkoutPlaylist(exercise.playlistId);
      if (!playlist || playlist.userId !== req.user.id) {
        return res.status(403).json({ message: "You don't have permission to delete this exercise" });
      }
      const success = await storage.deleteWorkoutExercise(exerciseId);
      if (!success) {
        return res.status(500).json({ message: "Failed to delete workout exercise" });
      }
      res.json({ message: "Workout exercise deleted successfully" });
    } catch (error) {
      console.error("Error deleting workout exercise:", error);
      res.status(500).json({ message: "Error deleting workout exercise" });
    }
  });
  app2.post("/api/workout-playlists/generate", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.id;
      const { workoutType, intensityLevel, duration, targets } = req.body;
      if (!workoutType || !intensityLevel || !duration || !targets || !Array.isArray(targets) || targets.length === 0) {
        return res.status(400).json({ message: "Missing required fields. Please provide workoutType, intensityLevel, duration and targets array." });
      }
      const athleteProfile = await storage.getAthleteProfileByUserId(userId);
      const generatedPlaylist = await storage.generateAIWorkoutPlaylist(userId, {
        workoutType,
        intensityLevel,
        duration,
        targets,
        userProfile: athleteProfile
      });
      res.status(201).json(generatedPlaylist);
    } catch (error) {
      console.error("Error generating AI workout playlist:", error);
      res.status(500).json({ message: "Error generating AI workout playlist" });
    }
  });
  app2.get("/api/cms/images", isAuthenticated, async (req, res) => {
    try {
      const category = req.query.category;
      const images = await getUploadedImages(category);
      return res.json(images);
    } catch (error) {
      console.error("Error fetching images:", error);
      return res.status(500).json({ message: "Error fetching images" });
    }
  });
  app2.post("/api/cms/images/upload", isAuthenticated, imageUpload.single("image"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image file uploaded" });
      }
      const category = req.body.category || "images";
      const relativePath = path8.relative(process.cwd(), req.file.path);
      const url = `/${relativePath.split(path8.sep).join("/")}`;
      return res.status(201).json({
        url,
        path: relativePath,
        filename: req.file.filename,
        category,
        originalname: req.file.originalname,
        size: req.file.size
      });
    } catch (error) {
      console.error("Error uploading image:", error);
      return res.status(500).json({ message: "Error uploading image" });
    }
  });
  app2.delete("/api/cms/images/:path(*)", isAuthenticated, async (req, res) => {
    try {
      const imagePath = req.params.path;
      const success = await deleteImage(imagePath);
      if (!success) {
        return res.status(404).json({ message: "Image not found or could not be deleted" });
      }
      return res.json({ message: "Image deleted successfully" });
    } catch (error) {
      console.error("Error deleting image:", error);
      return res.status(500).json({ message: "Error deleting image" });
    }
  });
  app2.post("/api/users/:id/profile-image", isAuthenticated, imageUpload.single("image"), async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = req.user;
      if (userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to update this profile" });
      }
      if (!req.file) {
        return res.status(400).json({ message: "No image file uploaded" });
      }
      const relativePath = path8.relative(process.cwd(), req.file.path);
      const profileImageUrl = `/${relativePath.split(path8.sep).join("/")}`;
      const updatedUser = await storage.updateUser(userId, { profileImage: profileImageUrl });
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      return res.json({
        id: updatedUser.id,
        profileImage: updatedUser.profileImage
      });
    } catch (error) {
      console.error("Error updating profile image:", error);
      return res.status(500).json({ message: "Error updating profile image" });
    }
  });
  app2.get("/api/cms/status", isAuthenticated, async (req, res) => {
    try {
      const uploadsDir2 = path8.join(process.cwd(), "uploads");
      const dirExists = fs7.existsSync(uploadsDir2);
      return res.json({
        status: "operational",
        uploadsDirectoryExists: dirExists,
        categories: ["profiles", "blog", "featured", "banners"]
      });
    } catch (error) {
      console.error("Error checking CMS status:", error);
      return res.status(500).json({ message: "Error checking CMS status" });
    }
  });
  app2.get("/api/feed", async (req, res) => {
    try {
      const featuredPosts = await storage.getFeaturedBlogPosts(3);
      const featuredAthletes2 = await storage.getFeaturedAthletes(4);
      const enrichedAthletes = await Promise.all(featuredAthletes2.map(async (athlete) => {
        const user = await storage.getUser(athlete.userId);
        return {
          ...athlete,
          name: user?.name || "",
          username: user?.username || "",
          profileImage: user?.profileImage || athlete.coverImage
        };
      }));
      const latestPosts = await storage.getBlogPosts(5);
      res.json({
        featuredPosts,
        featuredAthletes: enrichedAthletes,
        latestPosts
      });
    } catch (error) {
      console.error("Error fetching home feed:", error);
      res.status(500).json({ message: "Error fetching home feed" });
    }
  });
  app2.get("/api/film-comparisons", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const comparisons = await storage.getFilmComparisons(user.id);
      res.json(comparisons);
    } catch (error) {
      console.error("Error fetching film comparisons:", error);
      res.status(500).json({ message: "Error fetching film comparisons" });
    }
  });
  app2.get("/api/film-comparisons/:id", isAuthenticated, async (req, res) => {
    try {
      const comparisonId = parseInt(req.params.id);
      const comparison = await storage.getFilmComparison(comparisonId);
      if (!comparison) {
        return res.status(404).json({ message: "Film comparison not found" });
      }
      const user = req.user;
      if (comparison.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to view this comparison" });
      }
      const videos3 = await storage.getComparisonVideos(comparisonId);
      const analysis = await storage.getComparisonAnalysis(comparisonId);
      return res.json({
        comparison,
        videos: videos3,
        analysis
      });
    } catch (error) {
      console.error("Error fetching film comparison:", error);
      res.status(500).json({ message: "Error fetching film comparison" });
    }
  });
  app2.post("/api/film-comparisons", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const comparisonData = insertFilmComparisonSchema.parse({
        ...req.body,
        userId: user.id
      });
      const comparison = await storage.createFilmComparison(comparisonData);
      res.status(201).json(comparison);
    } catch (error) {
      console.error("Error creating film comparison:", error);
      res.status(400).json({ message: error.message });
    }
  });
  app2.put("/api/film-comparisons/:id", isAuthenticated, async (req, res) => {
    try {
      const comparisonId = parseInt(req.params.id);
      const comparison = await storage.getFilmComparison(comparisonId);
      if (!comparison) {
        return res.status(404).json({ message: "Film comparison not found" });
      }
      const user = req.user;
      if (comparison.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to update this comparison" });
      }
      const updatedComparison = await storage.updateFilmComparison(comparisonId, req.body);
      res.json(updatedComparison);
    } catch (error) {
      console.error("Error updating film comparison:", error);
      res.status(400).json({ message: error.message });
    }
  });
  app2.delete("/api/film-comparisons/:id", isAuthenticated, async (req, res) => {
    try {
      const comparisonId = parseInt(req.params.id);
      const comparison = await storage.getFilmComparison(comparisonId);
      if (!comparison) {
        return res.status(404).json({ message: "Film comparison not found" });
      }
      const user = req.user;
      if (comparison.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to delete this comparison" });
      }
      const success = await storage.deleteFilmComparison(comparisonId);
      if (success) {
        res.status(200).json({ message: "Film comparison deleted successfully" });
      } else {
        res.status(500).json({ message: "Error deleting film comparison" });
      }
    } catch (error) {
      console.error("Error deleting film comparison:", error);
      res.status(500).json({ message: "Error deleting film comparison" });
    }
  });
  app2.post("/api/film-comparisons/:id/videos", isAuthenticated, async (req, res) => {
    try {
      const comparisonId = parseInt(req.params.id);
      const comparison = await storage.getFilmComparison(comparisonId);
      if (!comparison) {
        return res.status(404).json({ message: "Film comparison not found" });
      }
      const user = req.user;
      if (comparison.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to modify this comparison" });
      }
      const videoData = insertComparisonVideoSchema.parse({
        ...req.body,
        comparisonId
      });
      const video = await storage.createComparisonVideo(videoData);
      res.status(201).json(video);
    } catch (error) {
      console.error("Error adding comparison video:", error);
      res.status(400).json({ message: error.message });
    }
  });
  app2.put("/api/comparison-videos/:id", isAuthenticated, async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const video = await storage.getComparisonVideo(videoId);
      if (!video) {
        return res.status(404).json({ message: "Comparison video not found" });
      }
      const comparison = await storage.getFilmComparison(video.comparisonId);
      if (!comparison) {
        return res.status(404).json({ message: "Film comparison not found" });
      }
      const user = req.user;
      if (comparison.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to modify this comparison" });
      }
      const updatedVideo = await storage.updateComparisonVideo(videoId, req.body);
      res.json(updatedVideo);
    } catch (error) {
      console.error("Error updating comparison video:", error);
      res.status(400).json({ message: error.message });
    }
  });
  app2.delete("/api/comparison-videos/:id", isAuthenticated, async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const video = await storage.getComparisonVideo(videoId);
      if (!video) {
        return res.status(404).json({ message: "Comparison video not found" });
      }
      const comparison = await storage.getFilmComparison(video.comparisonId);
      if (!comparison) {
        return res.status(404).json({ message: "Film comparison not found" });
      }
      const user = req.user;
      if (comparison.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to modify this comparison" });
      }
      const success = await storage.deleteComparisonVideo(videoId);
      if (success) {
        res.status(200).json({ message: "Comparison video deleted successfully" });
      } else {
        res.status(500).json({ message: "Error deleting comparison video" });
      }
    } catch (error) {
      console.error("Error deleting comparison video:", error);
      res.status(500).json({ message: "Error deleting comparison video" });
    }
  });
  app2.post("/api/film-comparisons/:id/analysis", isAuthenticated, async (req, res) => {
    try {
      const comparisonId = parseInt(req.params.id);
      const comparison = await storage.getFilmComparison(comparisonId);
      if (!comparison) {
        return res.status(404).json({ message: "Film comparison not found" });
      }
      const user = req.user;
      if (comparison.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to modify this comparison" });
      }
      const existingAnalysis = await storage.getComparisonAnalysis(comparisonId);
      if (existingAnalysis) {
        return res.status(400).json({ message: "Analysis already exists for this comparison" });
      }
      const analysisData = insertComparisonAnalysisSchema.parse({
        ...req.body,
        comparisonId
      });
      const analysis = await storage.createComparisonAnalysis(analysisData);
      res.status(201).json(analysis);
    } catch (error) {
      console.error("Error creating comparison analysis:", error);
      res.status(400).json({ message: error.message });
    }
  });
  app2.put("/api/comparison-analyses/:id", isAuthenticated, async (req, res) => {
    try {
      const analysisId = parseInt(req.params.id);
      const analysis = await storage.getComparisonAnalysis(req.body.comparisonId);
      if (!analysis) {
        return res.status(404).json({ message: "Comparison analysis not found" });
      }
      const comparison = await storage.getFilmComparison(analysis.comparisonId);
      if (!comparison) {
        return res.status(404).json({ message: "Film comparison not found" });
      }
      const user = req.user;
      if (comparison.userId !== user.id && user.role !== "admin") {
        return res.status(403).json({ message: "Not authorized to modify this analysis" });
      }
      const updatedAnalysis = await storage.updateComparisonAnalysis(analysisId, req.body);
      res.json(updatedAnalysis);
    } catch (error) {
      console.error("Error updating comparison analysis:", error);
      res.status(400).json({ message: error.message });
    }
  });
  app2.get("/api/athlete-profiles/stars", isAuthenticated, async (req, res) => {
    try {
      const { sport, position, starLevel } = req.query;
      let query = db.select().from(athleteStarProfiles);
      if (sport) {
        query = query.where(eq7(athleteStarProfiles.sport, sport));
      }
      if (position) {
        query = query.where(eq7(athleteStarProfiles.position, position));
      }
      if (starLevel) {
        const level = parseInt(starLevel);
        if (!isNaN(level)) {
          query = query.where(eq7(athleteStarProfiles.starLevel, level));
        }
      }
      const profiles = await query;
      return res.json(profiles);
    } catch (error) {
      console.error("Error fetching athlete star profiles:", error);
      return res.status(500).json({ message: "Error fetching athlete star profiles" });
    }
  });
  app2.get("/api/athlete-profiles/stars/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const [profile] = await db.select().from(athleteStarProfiles).where(eq7(athleteStarProfiles.id, id));
      if (!profile) {
        return res.status(404).json({ message: "Athlete star profile not found" });
      }
      return res.json(profile);
    } catch (error) {
      console.error("Error fetching athlete star profile:", error);
      return res.status(500).json({ message: "Error fetching athlete star profile" });
    }
  });
  app2.post("/api/admin/athlete-profiles/generate", isAdmin, async (req, res) => {
    try {
      const { generateProfiles: generateProfiles2 } = await Promise.resolve().then(() => (init_generate_athlete_profiles(), generate_athlete_profiles_exports));
      const profiles = await generateProfiles2();
      return res.json({
        message: `Successfully generated ${profiles.length} athlete profiles.`,
        count: profiles.length
      });
    } catch (error) {
      console.error("Error generating athlete profiles:", error);
      return res.status(500).json({ message: "Error generating athlete profiles: " + error.message });
    }
  });
  app2.post("/api/settings/api-keys", isAuthenticated, saveApiKey);
  app2.get("/api/settings/api-keys/status", isAuthenticated, getApiKeyStatus);
  app2.post("/api/sms/send", isAuthenticated, sendSms);
  app2.get("/api/sms/status", isAuthenticated, checkSmsStatus);
  app2.post("/api/sms/verify-phone", isAuthenticated, sendVerificationCode);
  app2.post("/api/sms/verify-code", isAuthenticated, verifyCode);
  app2.post("/api/sms/notification", isAuthenticated, sendNotification);
  app2.get("/api/content-blocks", async (req, res) => {
    try {
      const section = req.query.section;
      const contentBlocks2 = await storage.getContentBlocks(section);
      res.json(contentBlocks2);
    } catch (error) {
      console.error("Error fetching content blocks:", error);
      res.status(500).json({ message: "Error fetching content blocks" });
    }
  });
  app2.get("/api/content-blocks/section/:section", async (req, res) => {
    try {
      const section = req.params.section;
      const contentBlocks2 = await storage.getContentBlocks(section);
      res.json(contentBlocks2);
    } catch (error) {
      console.error("Error fetching content blocks by section:", error);
      res.status(500).json({ message: "Error fetching content blocks by section" });
    }
  });
  app2.get("/api/content-blocks/identifier/:identifier", async (req, res) => {
    try {
      const identifier = req.params.identifier;
      const contentBlock = await storage.getContentBlocksByIdentifier(identifier);
      if (!contentBlock) {
        return res.status(404).json({ message: "Content block not found" });
      }
      res.json(contentBlock);
    } catch (error) {
      console.error("Error fetching content block by identifier:", error);
      res.status(500).json({ message: "Error fetching content block by identifier" });
    }
  });
  app2.get("/api/content-blocks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const contentBlock = await storage.getContentBlock(id);
      if (!contentBlock) {
        return res.status(404).json({ message: "Content block not found" });
      }
      res.json(contentBlock);
    } catch (error) {
      console.error("Error fetching content block:", error);
      res.status(500).json({ message: "Error fetching content block" });
    }
  });
  app2.post("/api/content-blocks", isAdmin, async (req, res) => {
    try {
      const user = req.user;
      const blockData = req.body;
      if (!blockData.identifier || !blockData.title || !blockData.content || !blockData.section) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      blockData.lastUpdatedBy = user.id;
      const contentBlock = await storage.createContentBlock(blockData);
      res.status(201).json(contentBlock);
    } catch (error) {
      console.error("Error creating content block:", error);
      res.status(500).json({ message: "Error creating content block" });
    }
  });
  app2.put("/api/content-blocks/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = req.user;
      const blockData = req.body;
      blockData.lastUpdatedBy = user.id;
      const contentBlock = await storage.updateContentBlock(id, blockData);
      if (!contentBlock) {
        return res.status(404).json({ message: "Content block not found" });
      }
      res.json(contentBlock);
    } catch (error) {
      console.error("Error updating content block:", error);
      res.status(500).json({ message: "Error updating content block" });
    }
  });
  app2.delete("/api/content-blocks/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteContentBlock(id);
      if (!success) {
        return res.status(404).json({ message: "Content block not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting content block:", error);
      res.status(500).json({ message: "Error deleting content block" });
    }
  });
  return server;
}

// server/index.ts
init_vite();
import fs8 from "fs";
import path9 from "path";

// server/create-schema.ts
init_db();
init_vite();
import { sql as sql2 } from "drizzle-orm";
async function createSchema() {
  try {
    log("Creating schema if tables do not exist...", "db");
    const tablesExist = await db.execute(sql2`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'workout_playlists'
      ) as exists;
    `);
    const exists = tablesExist[0]?.exists === true;
    if (!exists) {
      log("Creating workout_playlists table...", "db");
      await db.execute(sql2`
        CREATE TABLE IF NOT EXISTS workout_playlists (
          id SERIAL PRIMARY KEY,
          user_id INTEGER NOT NULL,
          title TEXT NOT NULL,
          description TEXT,
          workout_type TEXT NOT NULL,
          intensity_level TEXT NOT NULL,
          duration INTEGER NOT NULL,
          targets TEXT[],
          created_at TIMESTAMP DEFAULT NOW(),
          last_used TIMESTAMP,
          times_used INTEGER DEFAULT 0,
          is_custom BOOLEAN DEFAULT TRUE,
          is_public BOOLEAN DEFAULT FALSE
        )
      `);
    }
    await db.execute(sql2`
      CREATE TABLE IF NOT EXISTS film_comparisons (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        title TEXT NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT NOW(),
        is_public BOOLEAN DEFAULT FALSE,
        comparison_type TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'draft',
        tags TEXT[]
      )
    `);
    await db.execute(sql2`
      CREATE TABLE IF NOT EXISTS comparison_videos (
        id SERIAL PRIMARY KEY,
        comparison_id INTEGER NOT NULL REFERENCES film_comparisons(id),
        video_id INTEGER REFERENCES videos(id),
        external_video_url TEXT,
        athlete_name TEXT,
        video_type TEXT NOT NULL,
        "order" INTEGER DEFAULT 0,
        notes TEXT,
        key_points TEXT[],
        markups JSONB
      )
    `);
    await db.execute(sql2`
      CREATE TABLE IF NOT EXISTS comparison_analyses (
        id SERIAL PRIMARY KEY,
        comparison_id INTEGER NOT NULL REFERENCES film_comparisons(id),
        analysis_date TIMESTAMP DEFAULT NOW(),
        similarity_score INTEGER,
        differences JSONB,
        recommendations TEXT[],
        ai_generated_notes TEXT,
        technique_breakdown JSONB
      )
    `);
    await db.execute(sql2`
      CREATE TABLE IF NOT EXISTS spotlight_profiles (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        title TEXT NOT NULL,
        summary TEXT NOT NULL,
        story TEXT NOT NULL,
        cover_image TEXT NOT NULL,
        media_gallery TEXT[],
        spotlight_date TIMESTAMP DEFAULT NOW(),
        featured BOOLEAN DEFAULT FALSE,
        status TEXT NOT NULL DEFAULT 'pending',
        approved_by INTEGER REFERENCES users(id),
        views INTEGER DEFAULT 0,
        likes INTEGER DEFAULT 0,
        is_trending BOOLEAN DEFAULT FALSE,
        category TEXT NOT NULL
      )
    `);
    await db.execute(sql2`
      CREATE TABLE IF NOT EXISTS player_progress (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        current_level INTEGER NOT NULL DEFAULT 1,
        total_xp INTEGER NOT NULL DEFAULT 0,
        level_xp INTEGER NOT NULL DEFAULT 0,
        xp_to_next_level INTEGER NOT NULL DEFAULT 100,
        rank TEXT NOT NULL DEFAULT 'Rookie',
        lifetime_achievements INTEGER DEFAULT 0,
        streak_days INTEGER DEFAULT 0,
        last_active TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      )
    `);
    await db.execute(sql2`
      CREATE TABLE IF NOT EXISTS xp_transactions (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        amount INTEGER NOT NULL,
        transaction_type TEXT NOT NULL,
        source_id TEXT,
        description TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT NOW(),
        multiplier REAL DEFAULT 1.0
      )
    `);
    await db.execute(sql2`
      CREATE TABLE IF NOT EXISTS player_badges (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        badge_id TEXT NOT NULL,
        badge_name TEXT NOT NULL,
        description TEXT NOT NULL,
        category TEXT NOT NULL,
        tier TEXT NOT NULL DEFAULT 'bronze',
        is_active BOOLEAN DEFAULT TRUE,
        icon_path TEXT NOT NULL,
        earned_at TIMESTAMP DEFAULT NOW(),
        progress INTEGER DEFAULT 100
      )
    `);
    await db.execute(sql2`
      CREATE TABLE IF NOT EXISTS workout_exercises (
        id SERIAL PRIMARY KEY,
        playlist_id INTEGER NOT NULL REFERENCES workout_playlists(id),
        name TEXT NOT NULL,
        description TEXT,
        sets INTEGER,
        reps INTEGER,
        duration INTEGER,
        rest_period INTEGER,
        exercise_order INTEGER NOT NULL,
        video_url TEXT,
        image_url TEXT,
        notes TEXT,
        equipment_needed TEXT[]
      )
    `);
    await db.execute(sql2`
      CREATE TABLE IF NOT EXISTS workout_verifications (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        workout_id INTEGER REFERENCES workout_playlists(id),
        title TEXT NOT NULL,
        submission_date TIMESTAMP DEFAULT NOW(),
        verification_status TEXT NOT NULL DEFAULT 'pending',
        rejection_reason TEXT,
        verified_by INTEGER REFERENCES users(id),
        verification_date TIMESTAMP,
        workout_duration INTEGER,
        workout_type TEXT,
        intensity_level TEXT,
        location TEXT,
        notes TEXT,
        xp_earned INTEGER DEFAULT 0
      )
    `);
    await db.execute(sql2`
      CREATE TABLE IF NOT EXISTS workout_verification_checkpoints (
        id SERIAL PRIMARY KEY,
        verification_id INTEGER NOT NULL REFERENCES workout_verifications(id),
        checkpoint_time TIMESTAMP DEFAULT NOW(),
        checkpoint_type TEXT NOT NULL,
        data JSONB,
        media_url TEXT,
        notes TEXT,
        is_verified BOOLEAN DEFAULT FALSE
      )
    `);
    await db.execute(sql2`
      CREATE TABLE IF NOT EXISTS weight_room_equipment (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        equipment_type TEXT NOT NULL,
        difficulty_level TEXT NOT NULL,
        target_muscles TEXT[],
        base_xp INTEGER NOT NULL,
        icon_path TEXT NOT NULL,
        model_path TEXT,
        price INTEGER NOT NULL DEFAULT 0,
        unlock_level INTEGER NOT NULL DEFAULT 1,
        is_premium BOOLEAN DEFAULT FALSE
      )
    `);
    await db.execute(sql2`
      CREATE TABLE IF NOT EXISTS player_equipment (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        equipment_id INTEGER NOT NULL REFERENCES weight_room_equipment(id),
        acquired_date TIMESTAMP DEFAULT NOW(),
        level INTEGER NOT NULL DEFAULT 1,
        times_used INTEGER DEFAULT 0,
        last_used TIMESTAMP,
        is_favorite BOOLEAN DEFAULT FALSE,
        custom_name TEXT,
        usage_streak INTEGER DEFAULT 0
      )
    `);
    await db.execute(sql2`
      CREATE TABLE IF NOT EXISTS content_blocks (
        id SERIAL PRIMARY KEY,
        identifier TEXT NOT NULL UNIQUE,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        section TEXT NOT NULL,
        "order" INTEGER DEFAULT 0,
        active BOOLEAN DEFAULT TRUE,
        last_updated TIMESTAMP DEFAULT NOW(),
        last_updated_by INTEGER REFERENCES users(id),
        metadata JSONB
      )
    `);
    log("Schema creation completed", "db");
  } catch (error) {
    log(`Error creating schema: ${error}`, "db");
    throw error;
  }
}

// server/index.ts
init_storage();
init_blog_generator();
init_openai_service();
import cors from "cors";

// server/services/transfer-portal-service.ts
init_db();
init_schema();
import { eq as eq8, and as and2, sql as sql3 } from "drizzle-orm";
import OpenAI4 from "openai";
var openai2 = new OpenAI4({ apiKey: process.env.OPENAI_API_KEY });
var TransferPortalService = class {
  updateIntervals = {};
  constructor() {
    console.log("Transfer Portal Service initialized");
  }
  async initialize() {
    try {
      const activeMonitors = await db.select().from(transferPortalMonitors).where(eq8(transferPortalMonitors.active, true));
      for (const monitor of activeMonitors) {
        this.startMonitorUpdateCycle(monitor);
      }
      console.log(`Started ${activeMonitors.length} transfer portal monitors`);
      return true;
    } catch (error) {
      console.error("Failed to initialize transfer portal service:", error);
      return false;
    }
  }
  /**
   * Create a new transfer portal monitor
   */
  async createMonitor(name, description, sportType, monitorType, createdBy, options = {}) {
    try {
      const [newMonitor] = await db.insert(transferPortalMonitors).values({
        name,
        description,
        active: true,
        sportType,
        monitorType,
        createdBy,
        divisions: options.divisions || [],
        conferences: options.conferences || [],
        updateFrequency: options.updateFrequency || 360,
        // Default 6 minutes
        positionGroups: options.positionGroups || []
      }).returning();
      if (newMonitor) {
        this.startMonitorUpdateCycle(newMonitor);
        return newMonitor;
      }
      return null;
    } catch (error) {
      console.error("Failed to create transfer portal monitor:", error);
      return null;
    }
  }
  /**
   * Start the update cycle for a monitor based on its update frequency
   */
  startMonitorUpdateCycle(monitor) {
    if (this.updateIntervals[monitor.id]) {
      clearInterval(this.updateIntervals[monitor.id]);
    }
    this.updateIntervals[monitor.id] = setInterval(
      () => this.runMonitorUpdate(monitor.id),
      monitor.updateFrequency * 1e3
      // Convert seconds to milliseconds
    );
    this.runMonitorUpdate(monitor.id);
  }
  /**
   * Run an update cycle for a specific monitor
   */
  async runMonitorUpdate(monitorId) {
    try {
      const [monitor] = await db.select().from(transferPortalMonitors).where(eq8(transferPortalMonitors.id, monitorId));
      if (!monitor || !monitor.active) {
        if (this.updateIntervals[monitorId]) {
          clearInterval(this.updateIntervals[monitorId]);
          delete this.updateIntervals[monitorId];
        }
        return;
      }
      await db.update(transferPortalMonitors).set({ lastRunAt: /* @__PURE__ */ new Date() }).where(eq8(transferPortalMonitors.id, monitorId));
      switch (monitor.monitorType) {
        case "roster-changes":
          await this.updateTeamRosters(monitor);
          break;
        case "player-portal-entries":
          await this.updatePortalEntries(monitor);
          break;
        case "commitment-flips":
          await this.updateCommitmentFlips(monitor);
          break;
        default:
          console.warn(`Unknown monitor type: ${monitor.monitorType}`);
      }
    } catch (error) {
      console.error(`Error running monitor update for ID ${monitorId}:`, error);
    }
  }
  /**
   * Update team rosters for the specified monitor
   */
  async updateTeamRosters(monitor) {
    const teamRosters = await db.select().from(ncaaTeamRosters).where(
      and2(
        eq8(ncaaTeamRosters.sport, monitor.sportType)
        // Add more filters based on divisions and conferences if needed
      )
    );
    for (const roster of teamRosters) {
      const statusOptions = ["normal", "low", "overstocked"];
      const newStatus = statusOptions[Math.floor(Math.random() * statusOptions.length)];
      if (roster.rosterStatus !== newStatus) {
        await db.update(ncaaTeamRosters).set({
          rosterStatus: newStatus,
          lastUpdated: /* @__PURE__ */ new Date()
        }).where(eq8(ncaaTeamRosters.id, roster.id));
        if ((newStatus === "low" || newStatus === "overstocked") && monitor.notifyCoaches) {
          this.createRosterAlert(roster, newStatus);
        }
      }
    }
  }
  /**
   * Handle new players entering the transfer portal
   */
  async updatePortalEntries(monitor) {
    if (Math.random() > 0.7) {
      const newPlayer = await this.createSimulatedPortalEntry(monitor.sportType);
      if (newPlayer) {
        await db.update(transferPortalMonitors).set({
          transferCount: sql3`${transferPortalMonitors.transferCount} + 1`
        }).where(eq8(transferPortalMonitors.id, monitor.id));
        await this.generateBestFitSchools(newPlayer.id);
      }
    }
  }
  /**
   * Handle tracking commitment flips
   */
  async updateCommitmentFlips(monitor) {
    const committedPlayers = await db.select().from(transferPortalEntries).where(
      and2(
        eq8(transferPortalEntries.sport, monitor.sportType),
        eq8(transferPortalEntries.portalStatus, "committed")
      )
    );
    for (const player of committedPlayers) {
      if (Math.random() > 0.95) {
        const schools = ["Florida State", "Michigan", "USC", "Georgia", "Ohio State", "Alabama"];
        const newSchool = schools[Math.floor(Math.random() * schools.length)];
        if (player.committedTo !== newSchool) {
          await db.update(transferPortalEntries).set({
            committedTo: newSchool,
            commitDate: /* @__PURE__ */ new Date()
          }).where(eq8(transferPortalEntries.id, player.id));
          this.createCommitmentFlipAlert(player, newSchool);
        }
      }
    }
  }
  /**
   * Create a simulated player entry into the transfer portal
   * In production, this would be replaced with real data from NCAA API
   */
  async createSimulatedPortalEntry(sportType) {
    try {
      const firstNames = ["Michael", "James", "John", "Robert", "David", "William", "Mary", "Patricia", "Jennifer", "Linda", "Elizabeth", "Sarah"];
      const lastNames = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Miller", "Davis", "Garcia", "Rodriguez", "Wilson", "Martinez", "Anderson"];
      const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
      const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
      const playerName = `${firstName} ${lastName}`;
      const schools = ["Alabama", "Clemson", "Ohio State", "LSU", "Georgia", "Oklahoma", "Notre Dame", "Michigan", "Texas", "Florida", "Auburn", "Oregon"];
      const previousSchool = schools[Math.floor(Math.random() * schools.length)];
      let positions = [];
      if (sportType === "football") {
        positions = ["QB", "RB", "WR", "TE", "OL", "DL", "LB", "CB", "S", "K", "P"];
      } else if (sportType === "basketball") {
        positions = ["PG", "SG", "SF", "PF", "C"];
      } else {
        positions = ["Attacker", "Midfielder", "Defender", "Goalkeeper"];
      }
      const position = positions[Math.floor(Math.random() * positions.length)];
      const [playerEntry] = await db.insert(transferPortalEntries).values({
        playerName,
        previousSchool,
        sport: sportType,
        position,
        eligibilityRemaining: `${Math.floor(Math.random() * 4) + 1} years`,
        height: `${Math.floor(Math.random() * 12) + 66} inches`,
        // 5'6" to 6'6"
        weight: `${Math.floor(Math.random() * 100) + 160} lbs`,
        starRating: Math.floor(Math.random() * 5) + 1,
        portalEntryDate: /* @__PURE__ */ new Date(),
        portalStatus: "active"
        // Add more fields as needed
      }).returning();
      return playerEntry;
    } catch (error) {
      console.error("Error creating simulated player entry:", error);
      return null;
    }
  }
  /**
   * Use OpenAI to generate the best fit schools for a player in the portal
   */
  async generateBestFitSchools(playerId) {
    try {
      const [player] = await db.select().from(transferPortalEntries).where(eq8(transferPortalEntries.id, playerId));
      if (!player) return;
      const schoolRosters = await db.select().from(ncaaTeamRosters).where(eq8(ncaaTeamRosters.sport, player.sport)).limit(20);
      const playerData = {
        name: player.playerName,
        previousSchool: player.previousSchool,
        position: player.position,
        height: player.height,
        weight: player.weight,
        starRating: player.starRating,
        eligibilityRemaining: player.eligibilityRemaining
      };
      const schoolData = schoolRosters.map((s) => ({
        name: s.school,
        conference: s.conference,
        division: s.division,
        rosterStatus: s.rosterStatus,
        positionNeeds: s.positionNeeds
      }));
      const response = await openai2.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `You are an expert NCAA recruiting analyst. Based on the player data and school rosters provided, determine the top 5 best fitting schools for this transfer portal player. Focus on position needs, playing time opportunity, scheme fit, and geographic considerations. Return your analysis in JSON format with the following structure:
            {
              "bestFitSchools": ["School1", "School2", "School3", "School4", "School5"],
              "fitReasons": {
                "School1": "Detailed explanation of why this school is a good fit",
                "School2": "Detailed explanation of why this school is a good fit",
                ...
              },
              "transferRating": 85 // A number from 1-100 indicating the impact this player could have on their new team
            }`
          },
          {
            role: "user",
            content: JSON.stringify({
              player: playerData,
              schools: schoolData
            })
          }
        ],
        response_format: { type: "json_object" }
      });
      const result = JSON.parse(response.choices[0].message.content);
      await db.update(transferPortalEntries).set({
        bestFitSchools: result.bestFitSchools,
        fitReasons: result.fitReasons,
        transferRating: result.transferRating
      }).where(eq8(transferPortalEntries.id, playerId));
      return result;
    } catch (error) {
      console.error("Error generating best fit schools with AI:", error);
      return null;
    }
  }
  /**
   * Create an alert for roster status changes
   */
  async createRosterAlert(roster, newStatus) {
    console.log(`ALERT: ${roster.school} roster status changed to ${newStatus}`);
  }
  /**
   * Create an alert for commitment flips
   */
  async createCommitmentFlipAlert(player, newSchool) {
    console.log(
      `COMMITMENT FLIP ALERT: ${player.playerName} flipped from ${player.committedTo} to ${newSchool}`
    );
  }
};
var transferPortalService = new TransferPortalService();

// server/services/athlete-scout-service.ts
init_db();
init_schema();
import { eq as eq9, desc as desc3, sql as sql4 } from "drizzle-orm";
import OpenAI5 from "openai";
var openai3 = new OpenAI5({ apiKey: process.env.OPENAI_API_KEY });
var AthleteScoutService = class {
  scoutIntervals = {};
  constructor() {
    console.log("Athlete Scout Service initialized");
  }
  async initialize() {
    try {
      const activeScouts = await db.select().from(socialMediaScouts).where(eq9(socialMediaScouts.active, true));
      for (const scout of activeScouts) {
        this.startScoutDiscoveryCycle(scout);
      }
      const activeMediaScouts = await db.select().from(mediaPartnershipScouts).where(eq9(mediaPartnershipScouts.active, true));
      for (const scout of activeMediaScouts) {
        this.startMediaScoutDiscoveryCycle(scout);
      }
      const activeCityScouts = await db.select().from(cityInfluencerScouts).where(eq9(cityInfluencerScouts.active, true));
      for (const scout of activeCityScouts) {
        this.startCityInfluencerScoutCycle(scout);
      }
      console.log(
        `Started ${activeScouts.length} athlete scouts, ${activeMediaScouts.length} media scouts, and ${activeCityScouts.length} city influencer scouts`
      );
      return true;
    } catch (error) {
      console.error("Failed to initialize athlete scout service:", error);
      return false;
    }
  }
  /**
   * Create a new athlete scout
   */
  async createScout(name, description, createdBy, options = {}) {
    try {
      const [newScout] = await db.insert(socialMediaScouts).values({
        name,
        description,
        active: true,
        createdBy,
        sportFocus: options.sportFocus || [],
        locationFocus: options.locationFocus || [],
        keywordsToTrack: options.keywordsToTrack || [],
        platformsToSearch: options.platformsToSearch || ["instagram", "tiktok", "twitter"],
        ageRangeMin: options.ageRangeMin || 12,
        ageRangeMax: options.ageRangeMax || 18
      }).returning();
      if (newScout) {
        this.startScoutDiscoveryCycle(newScout);
        return newScout;
      }
      return null;
    } catch (error) {
      console.error("Failed to create athlete scout:", error);
      return null;
    }
  }
  /**
   * Create a new media partnership scout
   */
  async createMediaScout(name, description, createdBy, mediaTypes, sportFocus, options = {}) {
    try {
      const [newScout] = await db.insert(mediaPartnershipScouts).values({
        name,
        description,
        active: true,
        createdBy,
        mediaTypes,
        sportFocus,
        followerThreshold: options.followerThreshold || 1e4,
        locationFocus: options.locationFocus || [],
        keywordsToTrack: options.keywordsToTrack || [],
        exclusionTerms: options.exclusionTerms || []
      }).returning();
      if (newScout) {
        this.startMediaScoutDiscoveryCycle(newScout);
        return newScout;
      }
      return null;
    } catch (error) {
      console.error("Failed to create media partnership scout:", error);
      return null;
    }
  }
  /**
   * Create a new city influencer scout for combine events
   */
  async createCityInfluencerScout(name, description, city, state, sportFocus, createdBy, options = {}) {
    try {
      const [newScout] = await db.insert(cityInfluencerScouts).values({
        name,
        description,
        active: true,
        city,
        state,
        sportFocus,
        createdBy,
        platforms: options.platforms || ["instagram", "tiktok", "youtube"],
        minFollowers: options.minFollowers || 5e3,
        maxInfluencers: options.maxInfluencers || 10,
        combineEventId: options.combineEventId
      }).returning();
      if (newScout) {
        this.startCityInfluencerScoutCycle(newScout);
        return newScout;
      }
      return null;
    } catch (error) {
      console.error("Failed to create city influencer scout:", error);
      return null;
    }
  }
  /**
   * Start the discovery cycle for an athlete scout
   */
  startScoutDiscoveryCycle(scout) {
    if (this.scoutIntervals[scout.id]) {
      clearInterval(this.scoutIntervals[scout.id]);
    }
    this.scoutIntervals[scout.id] = setInterval(
      () => this.runAthleteDiscovery(scout.id),
      6 * 60 * 60 * 1e3
      // 6 hours
    );
    this.runAthleteDiscovery(scout.id);
  }
  /**
   * Start the discovery cycle for a media partnership scout
   */
  startMediaScoutDiscoveryCycle(scout) {
    const scoutKey = `media_${scout.id}`;
    if (this.scoutIntervals[scoutKey]) {
      clearInterval(this.scoutIntervals[scoutKey]);
    }
    this.scoutIntervals[scoutKey] = setInterval(
      () => this.runMediaPartnerDiscovery(scout.id),
      12 * 60 * 60 * 1e3
      // 12 hours
    );
    this.runMediaPartnerDiscovery(scout.id);
  }
  /**
   * Start the discovery cycle for a city influencer scout
   */
  startCityInfluencerScoutCycle(scout) {
    const scoutKey = `city_${scout.id}`;
    if (this.scoutIntervals[scoutKey]) {
      clearInterval(this.scoutIntervals[scoutKey]);
    }
    this.scoutIntervals[scoutKey] = setInterval(
      () => this.runCityInfluencerDiscovery(scout.id),
      24 * 60 * 60 * 1e3
      // 24 hours
    );
    this.runCityInfluencerDiscovery(scout.id);
  }
  /**
   * Run the athlete discovery process for a specific scout
   */
  async runAthleteDiscovery(scoutId) {
    try {
      const [scout] = await db.select().from(socialMediaScouts).where(eq9(socialMediaScouts.id, scoutId));
      if (!scout || !scout.active) {
        if (this.scoutIntervals[scoutId]) {
          clearInterval(this.scoutIntervals[scoutId]);
          delete this.scoutIntervals[scoutId];
        }
        return;
      }
      await db.update(socialMediaScouts).set({ lastRunAt: /* @__PURE__ */ new Date() }).where(eq9(socialMediaScouts.id, scoutId));
      const discoveryCount = Math.floor(Math.random() * 3) + 1;
      for (let i = 0; i < discoveryCount; i++) {
        const discovery = await this.simulateAthleteDiscovery(scout);
        if (discovery) {
          await db.update(socialMediaScouts).set({
            discoveryCount: sql4`${socialMediaScouts.discoveryCount} + 1`
          }).where(eq9(socialMediaScouts.id, scoutId));
        }
      }
    } catch (error) {
      console.error(`Error running athlete discovery for scout ID ${scoutId}:`, error);
    }
  }
  /**
   * Run the media partner discovery process for a specific scout
   */
  async runMediaPartnerDiscovery(scoutId) {
    try {
      const [scout] = await db.select().from(mediaPartnershipScouts).where(eq9(mediaPartnershipScouts.id, scoutId));
      if (!scout || !scout.active) {
        const scoutKey = `media_${scoutId}`;
        if (this.scoutIntervals[scoutKey]) {
          clearInterval(this.scoutIntervals[scoutKey]);
          delete this.scoutIntervals[scoutKey];
        }
        return;
      }
      await db.update(mediaPartnershipScouts).set({ lastRunAt: /* @__PURE__ */ new Date() }).where(eq9(mediaPartnershipScouts.id, scoutId));
      const discoveryCount = Math.floor(Math.random() * 2) + 1;
      for (let i = 0; i < discoveryCount; i++) {
        const discovery = await this.simulateMediaPartnerDiscovery(scout);
        if (discovery) {
          await db.update(mediaPartnershipScouts).set({
            discoveryCount: sql4`${mediaPartnershipScouts.discoveryCount} + 1`
          }).where(eq9(mediaPartnershipScouts.id, scoutId));
        }
      }
    } catch (error) {
      console.error(`Error running media partner discovery for scout ID ${scoutId}:`, error);
    }
  }
  /**
   * Run the city influencer discovery process for a specific scout
   */
  async runCityInfluencerDiscovery(scoutId) {
    try {
      const [scout] = await db.select().from(cityInfluencerScouts).where(eq9(cityInfluencerScouts.id, scoutId));
      if (!scout || !scout.active) {
        const scoutKey = `city_${scoutId}`;
        if (this.scoutIntervals[scoutKey]) {
          clearInterval(this.scoutIntervals[scoutKey]);
          delete this.scoutIntervals[scoutKey];
        }
        return;
      }
      await db.update(cityInfluencerScouts).set({
        lastRunAt: /* @__PURE__ */ new Date(),
        lastUpdated: /* @__PURE__ */ new Date()
      }).where(eq9(cityInfluencerScouts.id, scoutId));
      const existingCount = await db.select({ count: sql4`count(*)` }).from(cityInfluencerDiscoveries).where(eq9(cityInfluencerDiscoveries.scoutId, scoutId));
      const currentCount = existingCount[0]?.count || 0;
      if (currentCount < scout.maxInfluencers) {
        const toDiscover = Math.min(
          scout.maxInfluencers - currentCount,
          Math.floor(Math.random() * 2) + 1
        );
        for (let i = 0; i < toDiscover; i++) {
          const discovery = await this.simulateCityInfluencerDiscovery(scout, currentCount + i + 1);
          if (discovery) {
            await db.update(cityInfluencerScouts).set({
              discoveryCount: sql4`${cityInfluencerScouts.discoveryCount} + 1`
            }).where(eq9(cityInfluencerScouts.id, scoutId));
          }
        }
      }
    } catch (error) {
      console.error(`Error running city influencer discovery for scout ID ${scoutId}:`, error);
    }
  }
  /**
   * Simulate discovering an athlete on social media
   * In production, this would use real social media API data
   */
  async simulateAthleteDiscovery(scout) {
    try {
      const firstNames = ["Michael", "James", "John", "Robert", "David", "William", "Mary", "Patricia", "Jennifer", "Linda", "Elizabeth", "Sarah"];
      const lastNames = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Miller", "Davis", "Garcia", "Rodriguez", "Wilson", "Martinez", "Anderson"];
      const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
      const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
      const fullName = `${firstName} ${lastName}`;
      const username = `${firstName.toLowerCase()}${lastName.toLowerCase()}${Math.floor(Math.random() * 1e3)}`;
      const platforms = scout.platformsToSearch.length > 0 ? scout.platformsToSearch : ["instagram", "tiktok", "twitter"];
      const platform = platforms[Math.floor(Math.random() * platforms.length)];
      const sports = scout.sportFocus.length > 0 ? scout.sportFocus : ["basketball", "football", "soccer", "volleyball", "track"];
      const athleteSports = [];
      athleteSports.push(sports[Math.floor(Math.random() * sports.length)]);
      if (Math.random() > 0.7 && sports.length > 1) {
        let secondSport;
        do {
          secondSport = sports[Math.floor(Math.random() * sports.length)];
        } while (secondSport === athleteSports[0]);
        athleteSports.push(secondSport);
      }
      const positions = [];
      for (const sport of athleteSports) {
        if (sport === "basketball") {
          positions.push(["PG", "SG", "SF", "PF", "C"][Math.floor(Math.random() * 5)]);
        } else if (sport === "football") {
          positions.push(["QB", "RB", "WR", "TE", "OL", "DL", "LB", "CB", "S"][Math.floor(Math.random() * 9)]);
        } else if (sport === "soccer") {
          positions.push(["Forward", "Midfielder", "Defender", "Goalkeeper"][Math.floor(Math.random() * 4)]);
        } else if (sport === "volleyball") {
          positions.push(["Outside Hitter", "Middle Blocker", "Setter", "Libero"][Math.floor(Math.random() * 4)]);
        } else {
          positions.push(["Sprinter", "Distance", "Jumper", "Thrower"][Math.floor(Math.random() * 4)]);
        }
      }
      const currentYear = (/* @__PURE__ */ new Date()).getFullYear();
      const gradYear = currentYear + Math.floor(Math.random() * 4) + 1;
      const [discovery] = await db.insert(athleteDiscoveries).values({
        scoutId: scout.id,
        fullName,
        username,
        platform,
        profileUrl: `https://www.${platform}.com/${username}`,
        estimatedAge: Math.floor(Math.random() * (scout.ageRangeMax - scout.ageRangeMin + 1)) + scout.ageRangeMin,
        sports: athleteSports,
        positions,
        followerCount: Math.floor(Math.random() * 1e4) + 500,
        postCount: Math.floor(Math.random() * 100) + 10,
        graduationYear: gradYear,
        potentialRating: Math.floor(Math.random() * 5) + 1,
        email: `${username}@example.com`
        // Add more fields as needed
      }).returning();
      return discovery;
    } catch (error) {
      console.error("Error creating simulated athlete discovery:", error);
      return null;
    }
  }
  /**
   * Simulate discovering a media partner
   * In production, this would use real APIs
   */
  async simulateMediaPartnerDiscovery(scout) {
    try {
      const prefixes = ["The", "All", "Inside", "Beyond", "Next", "Elite", "Pro", "Champion", "Future", "Game Day"];
      const sports = scout.sportFocus.length > 0 ? scout.sportFocus : ["Basketball", "Football", "Soccer", "Sports", "Athletics"];
      const suffixes = ["Talk", "Zone", "Nation", "Insider", "Report", "Network", "Hub", "Channel", "Central", "Focus", "Daily", "Weekly", "Podcast"];
      const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
      const sport = sports[Math.floor(Math.random() * sports.length)];
      const suffix = suffixes[Math.floor(Math.random() * suffixes.length)];
      const name = `${prefix} ${sport} ${suffix}`;
      const mediaTypes = scout.mediaTypes.length > 0 ? scout.mediaTypes : ["podcast", "instagram", "youtube", "tiktok"];
      const platform = mediaTypes[Math.floor(Math.random() * mediaTypes.length)];
      let url = "";
      if (platform === "podcast") {
        url = `https://podcasts.apple.com/us/podcast/${name.toLowerCase().replace(/ /g, "-")}`;
      } else {
        url = `https://www.${platform}.com/${name.toLowerCase().replace(/ /g, "")}`;
      }
      const followerCount = Math.floor(Math.random() * 9e4) + scout.followerThreshold;
      const engagementRate = (Math.random() * 14 + 1) / 100;
      const contentQuality = Math.floor(Math.random() * 31) + 70;
      const relevanceScore = Math.floor(Math.random() * 31) + 70;
      const partnershipPotential = Math.floor(Math.random() * 31) + 70;
      const [discovery] = await db.insert(mediaPartnerDiscoveries).values({
        scoutId: scout.id,
        name,
        platform,
        url,
        followerCount,
        averageEngagement: engagementRate,
        sports: scout.sportFocus.length > 0 ? scout.sportFocus : [sport],
        contentQuality,
        relevanceScore,
        partnershipPotential
        // Add more fields as needed
      }).returning();
      return discovery;
    } catch (error) {
      console.error("Error creating simulated media partner discovery:", error);
      return null;
    }
  }
  /**
   * Simulate discovering a city influencer
   * In production, this would use real APIs with location filtering
   */
  async simulateCityInfluencerDiscovery(scout, rank) {
    try {
      const firstNames = ["Michael", "James", "John", "Robert", "David", "William", "Mary", "Patricia", "Jennifer", "Linda", "Elizabeth", "Sarah"];
      const lastNames = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Miller", "Davis", "Garcia", "Rodriguez", "Wilson", "Martinez", "Anderson"];
      const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
      const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
      const fullName = `${firstName} ${lastName}`;
      const usernameOptions = [
        `${firstName.toLowerCase()}${lastName.toLowerCase()}`,
        `${firstName.toLowerCase()}_${lastName.toLowerCase()}`,
        `${scout.city.toLowerCase()}${firstName.charAt(0).toLowerCase()}${lastName.toLowerCase()}`,
        `${firstName.toLowerCase()}${lastName.toLowerCase()}_${scout.city.toLowerCase()}`,
        `the_real_${firstName.toLowerCase()}${lastName.charAt(0).toLowerCase()}`
      ];
      const username = `${usernameOptions[Math.floor(Math.random() * usernameOptions.length)]}${Math.floor(Math.random() * 100)}`;
      const platforms = scout.platforms.length > 0 ? scout.platforms : ["instagram", "tiktok", "youtube"];
      const platform = platforms[Math.floor(Math.random() * platforms.length)];
      const followerCount = Math.floor(Math.random() * 95e3) + scout.minFollowers;
      const engagementRate = (Math.random() * 18 + 2) / 100;
      const sports = scout.sportFocus.length > 0 ? scout.sportFocus : ["basketball", "football", "soccer"];
      const localityScore = Math.floor(Math.random() * 31) + 70;
      const [discovery] = await db.insert(cityInfluencerDiscoveries).values({
        scoutId: scout.id,
        name: fullName,
        username,
        platform,
        url: `https://www.${platform}.com/${username}`,
        followerCount,
        engagementRate,
        sports,
        localityScore,
        influenceRank: rank,
        // Rank within the city's top influencers
        bio: `${sports[0].charAt(0).toUpperCase() + sports[0].slice(1)} enthusiast and content creator from ${scout.city}, ${scout.state}. Bringing you the best local sports coverage!`
        // Add more fields as needed
      }).returning();
      return discovery;
    } catch (error) {
      console.error("Error creating simulated city influencer discovery:", error);
      return null;
    }
  }
  /**
   * Get all discovered athletes from a specific scout
   */
  async getAthleteDiscoveries(scoutId) {
    return db.select().from(athleteDiscoveries).where(eq9(athleteDiscoveries.scoutId, scoutId)).orderBy(desc3(athleteDiscoveries.discoveredAt));
  }
  /**
   * Get all discovered media partners from a specific scout
   */
  async getMediaPartnerDiscoveries(scoutId) {
    return db.select().from(mediaPartnerDiscoveries).where(eq9(mediaPartnerDiscoveries.scoutId, scoutId)).orderBy(desc3(mediaPartnerDiscoveries.discoveredAt));
  }
  /**
   * Get all discovered city influencers from a specific scout
   */
  async getCityInfluencerDiscoveries(scoutId) {
    return db.select().from(cityInfluencerDiscoveries).where(eq9(cityInfluencerDiscoveries.scoutId, scoutId)).orderBy(cityInfluencerDiscoveries.influenceRank);
  }
  /**
   * Generate a social media audit for an athlete
   */
  async generateSocialMediaAudit(userId, reportGeneratedBy) {
    try {
      const platforms = ["instagram", "twitter", "tiktok", "facebook", "youtube"];
      const randomPlatforms = [];
      for (let i = 0; i < Math.floor(Math.random() * 3) + 2; i++) {
        const platform = platforms[Math.floor(Math.random() * platforms.length)];
        if (!randomPlatforms.includes(platform)) {
          randomPlatforms.push(platform);
        }
      }
      const overallScore = Math.floor(Math.random() * 50) + 50;
      const redFlagCount = Math.floor(Math.random() * 5);
      const redFlagItems = [];
      const redFlagTypes = [
        "Inappropriate language",
        "Political commentary",
        "Controversial posts",
        "Unprofessional content",
        "Inconsistent messaging",
        "Negative comments about coaches/teammates"
      ];
      for (let i = 0; i < redFlagCount; i++) {
        redFlagItems.push({
          type: redFlagTypes[Math.floor(Math.random() * redFlagTypes.length)],
          count: Math.floor(Math.random() * 5) + 1,
          impact: Math.floor(Math.random() * 3) + 1,
          // 1-3 severity
          examples: [`Example post from ${randomPlatforms[0]}: "Lorem ipsum dolor sit amet..."`]
        });
      }
      const suggestionsList = [
        "Highlight more of your community service involvement",
        "Increase posting frequency about your training regimen",
        "Share more content about your academic achievements",
        "Consider creating a dedicated athlete page separate from personal account",
        "Add more team-focused content rather than individual highlights",
        "Engage more with college programs you're interested in",
        "Showcase your versatility across different positions/skills",
        "Remove or archive posts containing controversial language or topics",
        "Maintain consistency in the type of content you share"
      ];
      const improvementSuggestions = [];
      const suggestionCount = Math.floor(Math.random() * 4) + 2;
      for (let i = 0; i < suggestionCount; i++) {
        const suggestion = suggestionsList[Math.floor(Math.random() * suggestionsList.length)];
        if (!improvementSuggestions.includes(suggestion)) {
          improvementSuggestions.push(suggestion);
        }
      }
      const recruitmentImpactScore = Math.max(30, overallScore - redFlagCount * 5);
      const [audit] = await db.insert(socialMediaAudits).values({
        userId,
        overallScore,
        platformsAnalyzed: randomPlatforms,
        contentAnalysis: {
          postFrequency: `${Math.floor(Math.random() * 5) + 1} posts per week`,
          engagement: `${Math.floor(Math.random() * 15) + 5}% average engagement rate`,
          contentTypes: {
            athletic: Math.floor(Math.random() * 40) + 60,
            personal: Math.floor(Math.random() * 30) + 10,
            academic: Math.floor(Math.random() * 20) + 5,
            other: Math.floor(Math.random() * 10) + 5
          }
        },
        redFlagCount,
        redFlagItems,
        improvementSuggestions,
        positiveHighlights: {
          strengths: [
            "Strong presence of athletic achievements",
            "Good engagement with followers",
            "Consistent posting schedule",
            `Excellent ${randomPlatforms[0]} presence`
          ],
          topPosts: [
            {
              platform: randomPlatforms[0],
              engagement: Math.floor(Math.random() * 500) + 500,
              description: "Game-winning highlight video"
            },
            {
              platform: randomPlatforms[1] || randomPlatforms[0],
              engagement: Math.floor(Math.random() * 300) + 300,
              description: "Training session with coach"
            }
          ]
        },
        recruitmentImpactScore,
        reportGeneratedBy,
        sharedWithUser: false,
        userAcknowledged: false
      }).returning();
      return audit;
    } catch (error) {
      console.error("Error generating social media audit:", error);
      return null;
    }
  }
};
var athleteScoutService = new AthleteScoutService();

// server/index.ts
import net from "net";
var app = express2();
app.use(express2.json());
app.use(express2.urlencoded({ extended: false }));
app.use(cors({
  origin: true,
  // Allow all origins
  credentials: true,
  // Allow cookies to be sent
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"]
}));
var uploadsDir = path9.join(process.cwd(), "uploads");
if (!fs8.existsSync(uploadsDir)) {
  fs8.mkdirSync(uploadsDir, { recursive: true });
}
app.use("/uploads", express2.static(path9.join(process.cwd(), "uploads")));
app.use((req, res, next) => {
  const start = Date.now();
  const path10 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path10.startsWith("/api")) {
      let logLine = `${req.method} ${path10} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
(async () => {
  try {
    await createSchema();
    log("Database schema created successfully", "db");
    try {
      const apiKeys2 = await storage.getAllActiveApiKeys();
      if (apiKeys2 && apiKeys2.length > 0) {
        log(`Loading ${apiKeys2.length} API keys from database`);
        apiKeys2.forEach((key) => {
          const keyName = key.keyType.toUpperCase() + "_API_KEY";
          if (key.keyType === "openai") {
            process.env.OPENAI_API_KEY = key.keyValue;
            log("Set OPENAI_API_KEY from database");
          } else if (key.keyType === "stripe") {
            process.env.STRIPE_SECRET_KEY = key.keyValue;
            log("Set STRIPE_SECRET_KEY from database");
          } else if (key.keyType === "sendgrid") {
            process.env.SENDGRID_API_KEY = key.keyValue;
            log("Set SENDGRID_API_KEY from database");
          } else if (key.keyType === "twilio") {
            process.env.TWILIO_AUTH_TOKEN = key.keyValue;
            log("Set TWILIO_AUTH_TOKEN from database");
          } else {
            process.env[keyName] = key.keyValue;
            log(`Set ${keyName} from database`);
          }
        });
      } else {
        log("No API keys found in database", "db");
      }
    } catch (err) {
      log(`Error loading API keys from database: ${err}`, "db");
    }
  } catch (error) {
    log(`Error creating database schema: ${error}`, "db");
  }
  const server = await registerRoutes(app);
  app.use((err, _req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const findAvailablePort = async (startPort) => {
    return new Promise((resolve) => {
      const netServer = net.createServer();
      netServer.listen(startPort, "0.0.0.0", () => {
        const port2 = netServer.address().port;
        netServer.close(() => resolve(port2));
      });
      netServer.on("error", () => {
        resolve(findAvailablePort(startPort + 1));
      });
    });
  };
  const port = await findAvailablePort(5e3);
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true
  }, () => {
    log(`serving on port ${port}`);
    openAIService.hasValidApiKey().then(async (hasKey) => {
      if (hasKey) {
        log("\u2705 OpenAI API key validated successfully");
        log("Initializing AI blog generator...");
        try {
          await initializeBlogGeneration();
          log("AI blog generator initialized successfully");
          log("Initializing Transfer Portal Service...");
          const transferPortalInitialized = await transferPortalService.initialize();
          log(`Transfer Portal Service initialization ${transferPortalInitialized ? "successful" : "failed"}`);
          log("Initializing Athlete Scout Service...");
          const athleteScoutInitialized = await athleteScoutService.initialize();
          log(`Athlete Scout Service initialization ${athleteScoutInitialized ? "successful" : "failed"}`);
          try {
            const initialMonitor = await transferPortalService.createMonitor(
              "NCAA Football Transfer Portal Tracker",
              "Monitors NCAA football transfer portal for new entries and roster changes",
              "football",
              "player-portal-entries",
              1,
              // Admin user ID
              {
                divisions: ["D1-FBS", "D1-FCS", "D2"],
                conferences: ["SEC", "Big Ten", "ACC", "Big 12", "Pac-12"],
                updateFrequency: 360,
                // 6 minutes
                positionGroups: ["QB", "RB", "WR", "TE", "OL", "DL", "LB", "CB", "S"]
              }
            );
            if (initialMonitor) {
              log("Created initial Football Transfer Portal monitor");
            }
            const initialScout = await athleteScoutService.createScout(
              "National Football & Basketball Talent Scout",
              "Discovers promising football and basketball athletes on social media",
              1,
              // Admin user ID
              {
                sportFocus: ["football", "basketball"],
                platformsToSearch: ["instagram", "tiktok", "twitter"],
                ageRangeMin: 14,
                ageRangeMax: 18
              }
            );
            if (initialScout) {
              log("Created initial Athlete Social Media scout");
            }
            const initialMediaScout = await athleteScoutService.createMediaScout(
              "Sports Podcast & Instagram Partnership Scout",
              "Discovers sports media outlets for cross-promotion opportunities",
              1,
              // Admin user ID
              ["podcast", "instagram", "youtube"],
              // Media types
              ["football", "basketball", "multi-sport"],
              // Sport focus
              {
                followerThreshold: 5e3,
                keywordsToTrack: ["athlete", "recruiting", "high school", "college", "sports"]
              }
            );
            if (initialMediaScout) {
              log("Created initial Media Partnership scout");
            }
          } catch (err) {
            log(`Error creating default scouts/monitors: ${err}`);
          }
        } catch (err) {
          log(`Error initializing AI blog generator: ${err}`);
        }
      } else {
        log("\u26A0\uFE0F No valid OpenAI API key found. AI features will be limited.");
        log("Please update the API key in the admin panel or set OPENAI_API_KEY environment variable.");
      }
    }).catch((error) => {
      log(`Error checking OpenAI API key: ${error}`, "error");
    });
  });
})();
