# Go4It Sports Platform
Version: 1.0.1
Deployment date: 2025-04-25

## Overview
The Go4It Sports platform is designed for student athletes aged 12-18, with a specialized approach to supporting neurodivergent individuals through comprehensive development tools and personalized insights.

## Production Deployment
This package contains a production-ready build of the Go4It Sports platform for deployment to https://go4itsports.org.

## Directory Structure
- `dist/`: Frontend static files for Nginx
- `server/`: Backend API server files
- `shared/`: Shared code including database schema
- `uploads/`: User uploaded content
- `logs/`: Application logs

## Getting Started
1. Set up your server environment (Node.js, PostgreSQL, Nginx)
2. Configure environment variables in `.env`
3. Start the API server with `./start.sh`
4. Configure Nginx using the provided `nginx.conf`

## Technologies
- React.js with TypeScript frontend
- Node.js backend with intelligent performance analysis
- PostgreSQL database with Drizzle ORM
- WebSocket for real-time features
- OpenAI and Anthropic Claude integration for AI coaching

## Documentation
- `DEPLOYMENT.md`: Detailed deployment instructions
- `RELEASE_NOTES.md`: Changes in this version
- `.env.example`: Environment variable template

## Support
For technical support, contact support@go4itsports.org.
