#!/bin/bash
# Go4It Sports Production Start Script
# Version: 1.0.1

# Ensure we're in the correct directory
cd "$(dirname "$0")"

# Load environment variables if .env exists
if [ -f .env ]; then
  export $(grep -v '^#' .env | xargs)
fi

# Set production environment
export NODE_ENV=production

# Start the server
echo "Starting Go4It Sports API Server..."
echo "Environment: $NODE_ENV"
echo "Version: 1.0.1"

# Run the server
node server.js