# Go4It Sports Deployment Guide
Version: 1.0.1

This guide provides step-by-step instructions for deploying the Go4It Sports platform to a production environment.

## Server Requirements
- Ubuntu 20.04 LTS or newer
- Node.js 20.x or newer
- PostgreSQL 14.x or newer
- Nginx 1.20.x or newer
- 2+ CPU cores
- 4+ GB RAM
- 20+ GB SSD storage

## Step 1: Prepare the Server
```bash
# Update the system
sudo apt update
sudo apt upgrade -y

# Install required packages
sudo apt install -y nginx postgresql postgresql-contrib certbot python3-certbot-nginx

# Install Node.js 20.x
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install PM2 for process management
sudo npm install -g pm2
```

## Step 2: Set up the Database
```bash
# Create a database user and database
sudo -u postgres psql -c "CREATE USER go4it WITH PASSWORD 'your_secure_password';"
sudo -u postgres psql -c "CREATE DATABASE go4it_sports OWNER go4it;"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE go4it_sports TO go4it;"
```

## Step 3: Deploy the Application
```bash
# Create application directory
sudo mkdir -p /var/www/go4itsports.org
sudo chown $USER:$USER /var/www/go4itsports.org

# Extract deployment package
unzip go4it-deployment-*.zip -d /var/www/go4itsports.org/

# Navigate to application directory
cd /var/www/go4itsports.org

# Run pre-deployment check
./pre-deployment-check.sh

# Install dependencies
npm install --production

# Configure environment variables
cp .env.example .env
nano .env  # Edit with your specific values
```

## Step 4: Configure Nginx
```bash
# Copy Nginx configuration
sudo cp nginx.conf /etc/nginx/sites-available/go4itsports.org

# Create symbolic link
sudo ln -s /etc/nginx/sites-available/go4itsports.org /etc/nginx/sites-enabled/

# Test and reload Nginx
sudo nginx -t
sudo systemctl reload nginx
```

## Step 5: Set up SSL with Let's Encrypt
```bash
sudo certbot --nginx -d go4itsports.org -d www.go4itsports.org
```

## Step 6: Start the Application
```bash
# Using PM2 for process management
pm2 start server.js --name go4it-api
pm2 save
pm2 startup

# Alternatively, use the start script
./start.sh
```

## Step 7: Set up Monitoring and Backups
```bash
# Set up daily database backups
sudo mkdir -p /var/backups/go4itsports

# Create backup script
sudo nano /etc/cron.daily/backup-go4itsports.sh

# Add this content:
#!/bin/bash
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
BACKUP_DIR="/var/backups/go4itsports"
sudo -u postgres pg_dump go4it_sports > "$BACKUP_DIR/go4it_sports_$TIMESTAMP.sql"
find "$BACKUP_DIR" -name "go4it_sports_*.sql" -mtime +30 -delete

# Make the script executable
sudo chmod +x /etc/cron.daily/backup-go4itsports.sh

# Set up health check monitoring
(crontab -l 2>/dev/null; echo "0 * * * * cd /var/www/go4itsports.org && node healthcheck.js >> /var/www/go4itsports.org/logs/health-checks.log 2>&1") | crontab -
```

## Step 8: Final Verification
See the `FINAL_DEPLOYMENT_CHECKLIST.md` file for a comprehensive deployment verification checklist.

## Troubleshooting
- Check application logs: `tail -f /var/www/go4itsports.org/logs/app.log`
- Check Nginx logs: `sudo tail -f /var/log/nginx/error.log`
- Run health check: `node healthcheck.js`
- Restart the application: `pm2 restart go4it-api`
- Verify database connection: `psql -U go4it -h localhost -d go4it_sports`

For additional support, contact support@go4itsports.org
