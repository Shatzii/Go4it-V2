/**
 * Go4It Sports API Server
 * Production Entry Point
 * Version: 1.0.1
 */

// Load environment variables
require('dotenv').config();

// Force production mode
process.env.NODE_ENV = 'production';

// Handle graceful shutdown
process.on('SIGINT', () => {
  console.log('Received SIGINT. Shutting down gracefully...');
  
  // Allow 10 seconds for shutdown operations
  setTimeout(() => {
    console.error('Graceful shutdown timed out. Forcing exit.');
    process.exit(1);
  }, 10000);
  
  // Attempt clean shutdown
  try {
    // Load the module to perform clean shutdown
    require('./server/production-server').shutdown()
      .then(() => {
        console.log('Graceful shutdown completed.');
        process.exit(0);
      })
      .catch(err => {
        console.error('Error during shutdown:', err);
        process.exit(1);
      });
  } catch (error) {
    console.error('Fatal error during shutdown:', error);
    process.exit(1);
  }
});

// Start the server
console.log('Starting Go4It Sports API Server...');
console.log('Environment: ' + process.env.NODE_ENV);
console.log('Version: 1.0.1');

// Load the production server
require('./server/production-server.js');
