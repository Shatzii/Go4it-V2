/**
 * Go4It Sports API Server
 * Production Entry Point
 * Version: 1.0.1
 */

// Load environment variables
require('dotenv').config();

// Force production mode
process.env.NODE_ENV = 'production';

// Start the server
console.log('Starting Go4It Sports API Server...');
console.log('Environment: ' + process.env.NODE_ENV);
console.log('Version: 1.0.1');

// Load the production server
require('./production-server.js');
