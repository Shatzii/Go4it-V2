#!/bin/bash
# Go4It Sports Installation Wizard
# Version: 1.0.1

# Ensure we're in the correct directory
cd "$(dirname "$0")"

# Check if node is installed
if ! command -v node &> /dev/null; then
  echo "Error: Node.js is not installed"
  echo "Please install Node.js before running the installation wizard"
  exit 1
fi

# Check if required packages are installed
echo "Installing required packages..."
npm install express open dotenv pg

# Start the installation wizard
echo "Starting Go4It Sports Installation Wizard..."
node install-wizard.js
