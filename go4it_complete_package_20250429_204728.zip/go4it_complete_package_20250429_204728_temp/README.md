# Go4It Sports - Complete Deployment Package

This package contains everything you need to deploy the Go4It Sports platform, including:

1. The main Go4It Sports application
2. Monaco Editor + StarCoder AI integration
3. Visual Uploader & Deployment Tool
4. All necessary scripts and configuration files

## Quick Start

For a complete automated deployment, simply run:

```bash
chmod +x deploy_all.sh
./deploy_all.sh
```

This will:
- Create the necessary directory structure
- Deploy the main application
- Set up Monaco Editor with StarCoder AI integration
- Install the Visual Uploader tool
- Verify the deployment

## Package Contents

### Main Application
- `/client/` - Frontend React application
- `/server/` - Backend Node.js application
- `/shared/` - Shared code between client and server
- `/public/` - Static public assets

### Tools
- `/tools/go4it_visual_uploader.js` - Visual Uploader JavaScript
- `/tools/go4it_visual_uploader.html` - Visual Uploader HTML
- `/tools/visual_monaco_integration.css` - CSS styles for Monaco integration

### Editor Integration
- `/editor_integration/direct_integration.js` - StarCoder integration for Monaco
- `/editor_integration/monaco_integration_instructions.md` - Setup instructions
- `/editor_integration/go4it_monaco_integration.sh` - Integration script

### Scripts
- `/scripts/` - Various deployment and utility scripts
- `/deploy_all.sh` - Main deployment script

## Manual Deployment

If you prefer to deploy components individually:

1. **Deploy Main Application**:
   ```bash
   ./scripts/deploy.sh
   ```

2. **Set up Monaco Editor + StarCoder**:
   ```bash
   ./editor_integration/go4it_monaco_integration.sh
   ```

3. **Install Visual Uploader**:
   ```bash
   mkdir -p /var/www/html/tools
   cp ./tools/go4it_visual_uploader.* /var/www/html/tools/
   ```

## After Deployment

After deployment, you can access:

- Main application: `http://your-domain.com/`
- Visual Uploader: `http://your-domain.com/tools/go4it_visual_uploader.html`

## Troubleshooting

If you encounter issues:

1. Check the deployment logs
2. Verify file permissions
3. Ensure all services are running (Node.js, database, StarCoder API)
4. Run the verification script: `./scripts/verify_deployment.sh`

## Support

For assistance, please contact Go4It Sports support.
