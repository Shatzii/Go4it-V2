/**
 * Go4It Visual File Uploader & Deployment Tool
 * A comprehensive solution for file transfers between Replit and server
 * with visual enhancements and seamless integration
 */

// Configuration (Edit these variables)
const CONFIG = {
  SERVER_URL: "http://188.245.209.124",  // Your server URL
  FILE_BROWSER_API: "/api/files",        // File Browser API endpoint
  ADMIN_USERNAME: "admin",               // File Browser admin username
  DEPLOYMENT_PATH: "/var/www/go4itsports", // Deployment path on server
  MONACO_PATH: "/var/www/html/pharaoh",  // Monaco Editor path on server
  STARCODER_API_URL: "http://localhost:11434/v1", // StarCoder API URL
  THEME: {
    primary: "#0078d7",
    secondary: "#00a2ff",
    accent: "#00cc66",
    warning: "#f9a825",
    error: "#f44336",
    background: "#1e1e1e",
    darkBackground: "#252525",
    text: "#ffffff",
    textSecondary: "#dddddd"
  }
};

// Global state
const STATE = {
  authToken: null,
  files: [],
  localFiles: [],
  remoteFiles: [],
  uploadQueue: [],
  currentUploads: {},
  deploymentSteps: [],
  currentStep: 0,
  deploymentStatus: 'idle', // idle, running, success, error
  integrationStatus: {
    fileSystem: 'unknown',
    monaco: 'unknown',
    starCoder: 'unknown',
    database: 'unknown'
  },
  logs: [],
  notifications: []
};

// File types and icons mapping
const FILE_TYPES = {
  js: { icon: 'code', color: '#f0db4f' },
  ts: { icon: 'code', color: '#3178c6' },
  jsx: { icon: 'code', color: '#61dafb' },
  tsx: { icon: 'code', color: '#3178c6' },
  html: { icon: 'code', color: '#e34c26' },
  css: { icon: 'code', color: '#264de4' },
  json: { icon: 'database', color: '#5b5b5b' },
  md: { icon: 'file-text', color: '#5b5b5b' },
  png: { icon: 'image', color: '#a659a9' },
  jpg: { icon: 'image', color: '#a659a9' },
  jpeg: { icon: 'image', color: '#a659a9' },
  gif: { icon: 'image', color: '#a659a9' },
  svg: { icon: 'image', color: '#ffae00' },
  pdf: { icon: 'file-text', color: '#f40f02' },
  zip: { icon: 'archive', color: '#f7b500' },
  default: { icon: 'file', color: '#8f8f8f' }
};

// Initialization function
function initVisualUploader() {
  // Create container
  const container = document.createElement('div');
  container.id = 'go4it-uploader';
  container.className = 'go4it-uploader';
  document.body.appendChild(container);

  // Add CSS styles
  addStyles();
  
  // Render initial UI
  renderUI();
  
  // Add event listeners
  setupEventListeners();
  
  // Initialize the API
  initAPI();
  
  // Log initialization
  logMessage('Visual Uploader initialized');
}

// Add CSS styles to document
function addStyles() {
  const styleElement = document.createElement('style');
  styleElement.textContent = `
    /* Base styles */
    .go4it-uploader {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
      color: ${CONFIG.THEME.text};
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: ${CONFIG.THEME.background};
      z-index: 10000;
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }

    /* Header */
    .go4it-header {
      background: ${CONFIG.THEME.darkBackground};
      padding: 16px 24px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .go4it-header-title {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .go4it-logo {
      width: 36px;
      height: 36px;
      background: ${CONFIG.THEME.primary};
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-weight: bold;
      font-size: 18px;
    }

    .go4it-title-text h1 {
      margin: 0;
      font-size: 18px;
      font-weight: 600;
    }

    .go4it-title-text p {
      margin: 4px 0 0 0;
      font-size: 13px;
      color: ${CONFIG.THEME.textSecondary};
      opacity: 0.7;
    }

    .go4it-header-controls {
      display: flex;
      gap: 12px;
    }

    .go4it-btn {
      background: rgba(255, 255, 255, 0.1);
      border: none;
      border-radius: 6px;
      color: ${CONFIG.THEME.text};
      padding: 8px 16px;
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .go4it-btn:hover {
      background: rgba(255, 255, 255, 0.15);
    }

    .go4it-btn-primary {
      background: ${CONFIG.THEME.primary};
      color: white;
    }

    .go4it-btn-primary:hover {
      background: ${CONFIG.THEME.secondary};
    }

    .go4it-btn-success {
      background: ${CONFIG.THEME.accent};
      color: white;
    }

    .go4it-btn-success:hover {
      filter: brightness(1.1);
    }

    .go4it-btn-warning {
      background: ${CONFIG.THEME.warning};
      color: rgba(0, 0, 0, 0.8);
    }

    .go4it-btn-warning:hover {
      filter: brightness(1.1);
    }

    .go4it-btn-error {
      background: ${CONFIG.THEME.error};
      color: white;
    }

    .go4it-btn-error:hover {
      filter: brightness(1.1);
    }

    .go4it-btn-icon {
      width: 16px;
      height: 16px;
    }

    /* Main container */
    .go4it-main {
      display: flex;
      flex: 1;
      overflow: hidden;
    }

    /* File browser */
    .go4it-file-browser {
      display: flex;
      flex: 1;
      overflow: hidden;
    }

    .go4it-file-panel {
      flex: 1;
      display: flex;
      flex-direction: column;
      border-right: 1px solid rgba(255, 255, 255, 0.1);
      overflow: hidden;
    }

    .go4it-file-panel:last-child {
      border-right: none;
    }

    .go4it-panel-header {
      padding: 12px 16px;
      background: ${CONFIG.THEME.darkBackground};
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .go4it-panel-title {
      font-size: 15px;
      font-weight: 600;
      margin: 0;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .go4it-panel-controls {
      display: flex;
      gap: 8px;
    }

    .go4it-panel-btn {
      background: none;
      border: none;
      color: rgba(255, 255, 255, 0.6);
      cursor: pointer;
      padding: 4px;
      border-radius: 4px;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.2s;
    }

    .go4it-panel-btn:hover {
      background: rgba(255, 255, 255, 0.1);
      color: ${CONFIG.THEME.text};
    }

    .go4it-panel-content {
      flex: 1;
      overflow: auto;
      padding: 8px 0;
    }

    /* File items */
    .go4it-file-item {
      padding: 8px 16px;
      display: flex;
      align-items: center;
      color: ${CONFIG.THEME.textSecondary};
      cursor: pointer;
      border-radius: 0;
      transition: all 0.1s;
    }

    .go4it-file-item:hover {
      background: rgba(255, 255, 255, 0.05);
    }

    .go4it-file-item.selected {
      background: rgba(0, 120, 215, 0.2);
      color: ${CONFIG.THEME.text};
    }

    .go4it-file-icon {
      margin-right: 12px;
      color: #8f8f8f;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .go4it-file-icon.folder {
      color: ${CONFIG.THEME.warning};
    }

    .go4it-file-details {
      flex: 1;
      min-width: 0;
    }

    .go4it-file-name {
      font-size: 14px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .go4it-file-meta {
      font-size: 12px;
      color: rgba(255, 255, 255, 0.4);
      margin-top: 2px;
    }

    .go4it-file-actions {
      opacity: 0;
      transition: opacity 0.2s;
      display: flex;
      gap: 8px;
    }

    .go4it-file-item:hover .go4it-file-actions {
      opacity: 1;
    }

    /* File transfer zone */
    .go4it-transfer-zone {
      background: rgba(255, 255, 255, 0.02);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 20px;
      position: relative;
      min-height: 200px;
    }

    .go4it-dropzone {
      width: 100%;
      height: 100%;
      border: 2px dashed rgba(255, 255, 255, 0.2);
      border-radius: 8px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 32px;
      text-align: center;
      cursor: pointer;
      transition: all 0.2s;
    }

    .go4it-dropzone:hover,
    .go4it-dropzone.active {
      border-color: ${CONFIG.THEME.primary};
      background: rgba(0, 120, 215, 0.05);
    }

    .go4it-dropzone-icon {
      width: 48px;
      height: 48px;
      color: ${CONFIG.THEME.primary};
      margin-bottom: 16px;
      opacity: 0.8;
    }

    .go4it-dropzone-title {
      font-size: 16px;
      font-weight: 600;
      margin: 0 0 8px 0;
    }

    .go4it-dropzone-text {
      font-size: 14px;
      color: rgba(255, 255, 255, 0.6);
      margin: 0;
    }

    /* File queue */
    .go4it-queue {
      overflow: auto;
      max-height: 300px;
      padding: 12px;
    }

    .go4it-queue-item {
      display: flex;
      padding: 12px;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 6px;
      margin-bottom: 8px;
    }

    .go4it-queue-icon {
      margin-right: 12px;
      color: ${CONFIG.THEME.primary};
    }

    .go4it-queue-details {
      flex: 1;
      min-width: 0;
    }

    .go4it-queue-name {
      font-size: 14px;
      font-weight: 500;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .go4it-queue-meta {
      font-size: 12px;
      color: rgba(255, 255, 255, 0.5);
      margin-top: 4px;
    }

    .go4it-queue-progress {
      margin-top: 8px;
      height: 4px;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 2px;
      overflow: hidden;
    }

    .go4it-progress-bar {
      height: 100%;
      background: ${CONFIG.THEME.primary};
      width: 0%;
      transition: width 0.3s;
    }

    .go4it-queue-actions {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    /* Transfer controls */
    .go4it-transfer-controls {
      display: flex;
      justify-content: center;
      padding: 16px;
      gap: 16px;
      background: ${CONFIG.THEME.darkBackground};
      border-top: 1px solid rgba(255, 255, 255, 0.1);
    }

    /* Deployment panel */
    .go4it-deployment {
      width: 350px;
      border-left: 1px solid rgba(255, 255, 255, 0.1);
      display: flex;
      flex-direction: column;
      background: ${CONFIG.THEME.darkBackground};
    }

    .go4it-deployment-steps {
      flex: 1;
      overflow: auto;
      padding: 16px;
    }

    .go4it-step {
      display: flex;
      margin-bottom: 16px;
      position: relative;
    }

    .go4it-step:last-child {
      margin-bottom: 0;
    }

    .go4it-step-indicator {
      width: 24px;
      height: 24px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.1);
      color: rgba(255, 255, 255, 0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 12px;
      font-weight: 600;
      margin-right: 16px;
      flex-shrink: 0;
      position: relative;
      z-index: 2;
    }

    .go4it-step.completed .go4it-step-indicator {
      background: ${CONFIG.THEME.accent};
      color: rgba(0, 0, 0, 0.8);
    }

    .go4it-step.active .go4it-step-indicator {
      background: ${CONFIG.THEME.primary};
      color: white;
    }

    .go4it-step.error .go4it-step-indicator {
      background: ${CONFIG.THEME.error};
      color: white;
    }

    .go4it-step-line {
      position: absolute;
      left: 12px;
      top: 24px;
      bottom: -24px;
      width: 1px;
      background: rgba(255, 255, 255, 0.1);
      z-index: 1;
    }

    .go4it-step:last-child .go4it-step-line {
      display: none;
    }

    .go4it-step.completed .go4it-step-line {
      background: ${CONFIG.THEME.accent};
    }

    .go4it-step-content {
      flex: 1;
    }

    .go4it-step-title {
      font-size: 14px;
      font-weight: 600;
      margin: 0 0 4px 0;
    }

    .go4it-step.completed .go4it-step-title {
      color: ${CONFIG.THEME.accent};
    }

    .go4it-step.active .go4it-step-title {
      color: ${CONFIG.THEME.primary};
    }

    .go4it-step.error .go4it-step-title {
      color: ${CONFIG.THEME.error};
    }

    .go4it-step-description {
      font-size: 13px;
      color: rgba(255, 255, 255, 0.6);
      margin: 0;
    }

    /* Log console */
    .go4it-logs {
      height: 200px;
      overflow: auto;
      background: rgba(0, 0, 0, 0.2);
      padding: 12px;
      font-family: 'Fira Code', monospace;
      font-size: 12px;
      border-top: 1px solid rgba(255, 255, 255, 0.1);
    }

    .go4it-log-entry {
      margin-bottom: 4px;
      line-height: 1.5;
    }

    .go4it-log-time {
      color: rgba(255, 255, 255, 0.4);
      margin-right: 8px;
    }

    .go4it-log-message {
      color: rgba(255, 255, 255, 0.8);
    }

    .go4it-log-message.error {
      color: ${CONFIG.THEME.error};
    }

    .go4it-log-message.success {
      color: ${CONFIG.THEME.accent};
    }

    .go4it-log-message.warning {
      color: ${CONFIG.THEME.warning};
    }

    /* Status dashboard */
    .go4it-status-dashboard {
      padding: 16px;
      border-top: 1px solid rgba(255, 255, 255, 0.1);
    }

    .go4it-status-title {
      font-size: 14px;
      font-weight: 600;
      margin: 0 0 12px 0;
      color: rgba(255, 255, 255, 0.8);
    }

    .go4it-status-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 8px;
    }

    .go4it-status-item {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 6px;
    }

    .go4it-status-icon {
      width: 24px;
      height: 24px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 12px;
    }

    .go4it-status-icon.unknown {
      background: rgba(255, 255, 255, 0.1);
      color: rgba(255, 255, 255, 0.6);
    }

    .go4it-status-icon.ok {
      background: ${CONFIG.THEME.accent};
      color: rgba(0, 0, 0, 0.8);
    }

    .go4it-status-icon.error {
      background: ${CONFIG.THEME.error};
      color: white;
    }

    .go4it-status-icon.warning {
      background: ${CONFIG.THEME.warning};
      color: rgba(0, 0, 0, 0.8);
    }

    .go4it-status-info {
      font-size: 12px;
    }

    .go4it-status-name {
      font-weight: 500;
    }

    .go4it-status-value {
      color: rgba(255, 255, 255, 0.6);
    }

    /* Tour and onboarding */
    .go4it-tour-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.7);
      z-index: 10001;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .go4it-tour-card {
      background: ${CONFIG.THEME.darkBackground};
      border-radius: 12px;
      padding: 24px;
      width: 500px;
      max-width: 90%;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
    }

    .go4it-tour-header {
      display: flex;
      margin-bottom: 16px;
    }

    .go4it-tour-icon {
      width: 48px;
      height: 48px;
      border-radius: 12px;
      background: ${CONFIG.THEME.primary};
      display: flex;
      align-items: center;
      justify-content: center;
      margin-right: 16px;
      flex-shrink: 0;
    }

    .go4it-tour-icon svg {
      width: 24px;
      height: 24px;
      color: white;
    }

    .go4it-tour-title-container h2 {
      margin: 0 0 4px 0;
      font-size: 18px;
      font-weight: 600;
    }

    .go4it-tour-title-container p {
      margin: 0;
      font-size: 14px;
      color: rgba(255, 255, 255, 0.6);
    }

    .go4it-tour-content {
      margin-bottom: 24px;
      font-size: 15px;
      line-height: 1.6;
      color: rgba(255, 255, 255, 0.8);
    }

    .go4it-tour-actions {
      display: flex;
      justify-content: space-between;
    }

    .go4it-tour-dots {
      display: flex;
      gap: 4px;
      margin-top: 16px;
      justify-content: center;
    }

    .go4it-tour-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.2);
    }

    .go4it-tour-dot.active {
      background: ${CONFIG.THEME.primary};
    }

    /* Notifications */
    .go4it-notifications {
      position: fixed;
      bottom: 24px;
      right: 24px;
      display: flex;
      flex-direction: column;
      gap: 12px;
      z-index: 10002;
    }

    .go4it-notification {
      background: ${CONFIG.THEME.darkBackground};
      border-radius: 8px;
      padding: 12px;
      width: 300px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
      animation: slideIn 0.3s forwards;
      display: flex;
      align-items: flex-start;
    }

    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }

    .go4it-notification.exiting {
      animation: slideOut 0.3s forwards;
    }

    @keyframes slideOut {
      from { transform: translateX(0); opacity: 1; }
      to { transform: translateX(100%); opacity: 0; }
    }

    .go4it-notification-icon {
      margin-right: 12px;
      flex-shrink: 0;
    }

    .go4it-notification-icon.success {
      color: ${CONFIG.THEME.accent};
    }

    .go4it-notification-icon.error {
      color: ${CONFIG.THEME.error};
    }

    .go4it-notification-icon.warning {
      color: ${CONFIG.THEME.warning};
    }

    .go4it-notification-icon.info {
      color: ${CONFIG.THEME.primary};
    }

    .go4it-notification-content {
      flex: 1;
    }

    .go4it-notification-title {
      font-size: 14px;
      font-weight: 600;
      margin: 0 0 4px 0;
    }

    .go4it-notification-message {
      font-size: 13px;
      color: rgba(255, 255, 255, 0.7);
      margin: 0;
    }

    .go4it-notification-close {
      background: none;
      border: none;
      color: rgba(255, 255, 255, 0.4);
      cursor: pointer;
      padding: 0;
      margin-left: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .go4it-notification-close:hover {
      color: rgba(255, 255, 255, 0.8);
    }

    /* Animations */
    @keyframes spin {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }

    .go4it-spin {
      animation: spin 1.5s linear infinite;
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
      .go4it-main {
        flex-direction: column;
      }

      .go4it-deployment {
        width: 100%;
        height: 300px;
        border-left: none;
        border-top: 1px solid rgba(255, 255, 255, 0.1);
      }
    }
  `;
  document.head.appendChild(styleElement);
}

// Render the main UI
function renderUI() {
  const container = document.getElementById('go4it-uploader');
  
  // Base structure
  container.innerHTML = `
    <div class="go4it-header">
      <div class="go4it-header-title">
        <div class="go4it-logo">G4</div>
        <div class="go4it-title-text">
          <h1>Go4It Visual Uploader</h1>
          <p>Seamless file transfers and deployments with visual enhancements</p>
        </div>
      </div>
      <div class="go4it-header-controls">
        <button class="go4it-btn" id="go4it-settings-btn">
          <svg class="go4it-btn-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="3"></circle>
            <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
          </svg>
          Settings
        </button>
        <button class="go4it-btn" id="go4it-tour-btn">
          <svg class="go4it-btn-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="10"></circle>
            <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
            <line x1="12" y1="17" x2="12.01" y2="17"></line>
          </svg>
          Tour
        </button>
        <button class="go4it-btn go4it-btn-primary" id="go4it-deploy-btn">
          <svg class="go4it-btn-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"></path>
          </svg>
          Deploy Project
        </button>
      </div>
    </div>
    
    <div class="go4it-main">
      <div class="go4it-file-browser">
        <div class="go4it-file-panel">
          <div class="go4it-panel-header">
            <h2 class="go4it-panel-title">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                <polyline points="9 22 9 12 15 12 15 22"></polyline>
              </svg>
              Local Files (Replit)
            </h2>
            <div class="go4it-panel-controls">
              <button class="go4it-panel-btn" id="go4it-refresh-local">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M23 4v6h-6"></path>
                  <path d="M1 20v-6h6"></path>
                  <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
                </svg>
              </button>
              <button class="go4it-panel-btn" id="go4it-new-folder-local">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
                  <line x1="12" y1="11" x2="12" y2="17"></line>
                  <line x1="9" y1="14" x2="15" y2="14"></line>
                </svg>
              </button>
            </div>
          </div>
          
          <div class="go4it-panel-content" id="go4it-local-files">
            <div class="go4it-file-item">
              <div class="go4it-file-icon folder">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
                </svg>
              </div>
              <div class="go4it-file-details">
                <div class="go4it-file-name">client</div>
                <div class="go4it-file-meta">Directory</div>
              </div>
            </div>
            
            <div class="go4it-file-item">
              <div class="go4it-file-icon folder">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
                </svg>
              </div>
              <div class="go4it-file-details">
                <div class="go4it-file-name">server</div>
                <div class="go4it-file-meta">Directory</div>
              </div>
            </div>
            
            <div class="go4it-file-item">
              <div class="go4it-file-icon folder">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
                </svg>
              </div>
              <div class="go4it-file-details">
                <div class="go4it-file-name">shared</div>
                <div class="go4it-file-meta">Directory</div>
              </div>
            </div>
          </div>
          
          <div class="go4it-transfer-zone">
            <div class="go4it-dropzone" id="go4it-dropzone">
              <svg class="go4it-dropzone-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                <polyline points="17 8 12 3 7 8"></polyline>
                <line x1="12" y1="3" x2="12" y2="15"></line>
              </svg>
              <h3 class="go4it-dropzone-title">Drag & Drop Files Here</h3>
              <p class="go4it-dropzone-text">Or click to browse files on your computer</p>
              <input type="file" id="go4it-file-input" multiple style="display: none;" />
            </div>
          </div>
          
          <div class="go4it-queue" id="go4it-upload-queue"></div>
        </div>
        
        <div class="go4it-file-panel">
          <div class="go4it-panel-header">
            <h2 class="go4it-panel-title">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect>
                <rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect>
                <line x1="6" y1="6" x2="6.01" y2="6"></line>
                <line x1="6" y1="18" x2="6.01" y2="18"></line>
              </svg>
              Remote Files (Server)
            </h2>
            <div class="go4it-panel-controls">
              <button class="go4it-panel-btn" id="go4it-refresh-remote">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M23 4v6h-6"></path>
                  <path d="M1 20v-6h6"></path>
                  <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
                </svg>
              </button>
              <button class="go4it-panel-btn" id="go4it-new-folder-remote">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
                  <line x1="12" y1="11" x2="12" y2="17"></line>
                  <line x1="9" y1="14" x2="15" y2="14"></line>
                </svg>
              </button>
            </div>
          </div>
          
          <div class="go4it-panel-content" id="go4it-remote-files">
            <div class="go4it-file-item">
              <div class="go4it-file-icon folder">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
                </svg>
              </div>
              <div class="go4it-file-details">
                <div class="go4it-file-name">var</div>
                <div class="go4it-file-meta">Directory</div>
              </div>
            </div>
            
            <div class="go4it-file-item">
              <div class="go4it-file-icon folder">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
                </svg>
              </div>
              <div class="go4it-file-details">
                <div class="go4it-file-name">www</div>
                <div class="go4it-file-meta">Directory</div>
              </div>
            </div>
            
            <div class="go4it-file-item">
              <div class="go4it-file-icon folder">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
                </svg>
              </div>
              <div class="go4it-file-details">
                <div class="go4it-file-name">html</div>
                <div class="go4it-file-meta">Directory</div>
              </div>
            </div>
          </div>
          
          <div class="go4it-transfer-controls">
            <button class="go4it-btn" id="go4it-transfer-to-local">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M16 17l5-5-5-5"></path>
                <path d="M21 12H9"></path>
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
              </svg>
              Download Selected
            </button>
            <button class="go4it-btn go4it-btn-primary" id="go4it-transfer-to-remote">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M8 17l-5-5 5-5"></path>
                <path d="M3 12h12"></path>
                <path d="M15 21h4a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2h-4"></path>
              </svg>
              Upload Selected
            </button>
          </div>
        </div>
      </div>
      
      <div class="go4it-deployment">
        <div class="go4it-panel-header">
          <h2 class="go4it-panel-title">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"></path>
            </svg>
            Deployment Progress
          </h2>
        </div>
        
        <div class="go4it-deployment-steps" id="go4it-deployment-steps">
          <div class="go4it-step">
            <div class="go4it-step-indicator">1</div>
            <div class="go4it-step-line"></div>
            <div class="go4it-step-content">
              <h3 class="go4it-step-title">Prepare Files</h3>
              <p class="go4it-step-description">Package files for deployment</p>
            </div>
          </div>
          
          <div class="go4it-step">
            <div class="go4it-step-indicator">2</div>
            <div class="go4it-step-line"></div>
            <div class="go4it-step-content">
              <h3 class="go4it-step-title">Upload Package</h3>
              <p class="go4it-step-description">Transfer files to server</p>
            </div>
          </div>
          
          <div class="go4it-step">
            <div class="go4it-step-indicator">3</div>
            <div class="go4it-step-line"></div>
            <div class="go4it-step-content">
              <h3 class="go4it-step-title">Extract Files</h3>
              <p class="go4it-step-description">Extract files on server</p>
            </div>
          </div>
          
          <div class="go4it-step">
            <div class="go4it-step-indicator">4</div>
            <div class="go4it-step-line"></div>
            <div class="go4it-step-content">
              <h3 class="go4it-step-title">Configure Services</h3>
              <p class="go4it-step-description">Set up services and permissions</p>
            </div>
          </div>
          
          <div class="go4it-step">
            <div class="go4it-step-indicator">5</div>
            <div class="go4it-step-content">
              <h3 class="go4it-step-title">Verify Deployment</h3>
              <p class="go4it-step-description">Ensure everything is working</p>
            </div>
          </div>
        </div>
        
        <div class="go4it-logs" id="go4it-logs">
          <div class="go4it-log-entry">
            <span class="go4it-log-time">12:34:56</span>
            <span class="go4it-log-message">Visual Uploader initialized</span>
          </div>
        </div>
        
        <div class="go4it-status-dashboard">
          <h3 class="go4it-status-title">Integration Status</h3>
          <div class="go4it-status-grid">
            <div class="go4it-status-item">
              <div class="go4it-status-icon unknown">?</div>
              <div class="go4it-status-info">
                <div class="go4it-status-name">File System</div>
                <div class="go4it-status-value">Checking...</div>
              </div>
            </div>
            
            <div class="go4it-status-item">
              <div class="go4it-status-icon unknown">?</div>
              <div class="go4it-status-info">
                <div class="go4it-status-name">Monaco Editor</div>
                <div class="go4it-status-value">Checking...</div>
              </div>
            </div>
            
            <div class="go4it-status-item">
              <div class="go4it-status-icon unknown">?</div>
              <div class="go4it-status-info">
                <div class="go4it-status-name">StarCoder API</div>
                <div class="go4it-status-value">Checking...</div>
              </div>
            </div>
            
            <div class="go4it-status-item">
              <div class="go4it-status-icon unknown">?</div>
              <div class="go4it-status-info">
                <div class="go4it-status-name">Database</div>
                <div class="go4it-status-value">Checking...</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="go4it-notifications" id="go4it-notifications"></div>
  `;
  
  // Initialize tour if first-time user
  if (localStorage.getItem('go4it-tour-completed') !== 'true') {
    renderTour();
  }
}

// Set up event listeners
function setupEventListeners() {
  // Dropzone functionality
  const dropzone = document.getElementById('go4it-dropzone');
  const fileInput = document.getElementById('go4it-file-input');
  
  dropzone.addEventListener('click', () => {
    fileInput.click();
  });
  
  fileInput.addEventListener('change', (e) => {
    handleFileSelection(e.target.files);
  });
  
  dropzone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropzone.classList.add('active');
  });
  
  dropzone.addEventListener('dragleave', () => {
    dropzone.classList.remove('active');
  });
  
  dropzone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropzone.classList.remove('active');
    
    if (e.dataTransfer.files.length > 0) {
      handleFileSelection(e.dataTransfer.files);
    }
  });
  
  // Button click handlers
  document.getElementById('go4it-settings-btn').addEventListener('click', showSettings);
  document.getElementById('go4it-tour-btn').addEventListener('click', renderTour);
  document.getElementById('go4it-deploy-btn').addEventListener('click', startDeployment);
  document.getElementById('go4it-refresh-local').addEventListener('click', () => refreshFiles('local'));
  document.getElementById('go4it-refresh-remote').addEventListener('click', () => refreshFiles('remote'));
  document.getElementById('go4it-new-folder-local').addEventListener('click', () => createNewFolder('local'));
  document.getElementById('go4it-new-folder-remote').addEventListener('click', () => createNewFolder('remote'));
  document.getElementById('go4it-transfer-to-local').addEventListener('click', downloadSelectedFiles);
  document.getElementById('go4it-transfer-to-remote').addEventListener('click', uploadSelectedFiles);
}

// Initialize API connection
function initAPI() {
  // Check integration status
  checkIntegrationStatus();
  
  // Fetch initial files
  refreshFiles('local');
  refreshFiles('remote');
  
  // Initialize deployment steps
  initDeploymentSteps();
  
  // Add sample notifications
  setTimeout(() => {
    showNotification('Welcome to Go4It Visual Uploader', 'Your seamless file transfer and deployment tool is ready!', 'info');
  }, 1000);
}

// Handle file selection
function handleFileSelection(files) {
  if (!files || files.length === 0) return;
  
  // Add files to upload queue
  Array.from(files).forEach(file => {
    // Generate a unique ID for this upload
    const uploadId = generateId();
    
    // Add to state
    STATE.uploadQueue.push({
      id: uploadId,
      file: file,
      name: file.name,
      size: file.size,
      type: file.type,
      progress: 0,
      status: 'queue'
    });
    
    // Add to UI
    addFileToUploadQueue(uploadId, file);
  });
  
  // Show notification
  showNotification('Files Added', `${files.length} file(s) added to queue. Ready to upload.`, 'info');
}

// Add file to upload queue UI
function addFileToUploadQueue(id, file) {
  const queueContainer = document.getElementById('go4it-upload-queue');
  
  // Get file icon and color
  const extension = file.name.split('.').pop().toLowerCase();
  const typeInfo = FILE_TYPES[extension] || FILE_TYPES.default;
  
  // Create file size string
  const sizeStr = formatFileSize(file.size);
  
  // Create queue item
  const queueItem = document.createElement('div');
  queueItem.className = 'go4it-queue-item';
  queueItem.dataset.id = id;
  queueItem.innerHTML = `
    <div class="go4it-queue-icon" style="color: ${typeInfo.color}">
      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        ${getIconPath(typeInfo.icon)}
      </svg>
    </div>
    <div class="go4it-queue-details">
      <div class="go4it-queue-name">${file.name}</div>
      <div class="go4it-queue-meta">${sizeStr} • Queued</div>
      <div class="go4it-queue-progress">
        <div class="go4it-progress-bar" style="width: 0%"></div>
      </div>
    </div>
    <div class="go4it-queue-actions">
      <button class="go4it-panel-btn go4it-queue-remove" data-id="${id}">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
    </div>
  `;
  
  // Add event listeners
  queueItem.querySelector('.go4it-queue-remove').addEventListener('click', (e) => {
    e.stopPropagation();
    removeFromUploadQueue(id);
  });
  
  // Add to queue
  queueContainer.appendChild(queueItem);
}

// Remove file from upload queue
function removeFromUploadQueue(id) {
  // Remove from state
  STATE.uploadQueue = STATE.uploadQueue.filter(item => item.id !== id);
  
  // Remove from UI
  const queueItem = document.querySelector(`.go4it-queue-item[data-id="${id}"]`);
  if (queueItem) {
    queueItem.remove();
  }
}

// Update file upload progress
function updateUploadProgress(id, progress, status) {
  // Update in state
  const uploadItem = STATE.uploadQueue.find(item => item.id === id);
  if (uploadItem) {
    uploadItem.progress = progress;
    uploadItem.status = status;
  }
  
  // Update in UI
  const queueItem = document.querySelector(`.go4it-queue-item[data-id="${id}"]`);
  if (queueItem) {
    const progressBar = queueItem.querySelector('.go4it-progress-bar');
    const statusText = queueItem.querySelector('.go4it-queue-meta');
    
    progressBar.style.width = `${progress}%`;
    statusText.textContent = `${formatFileSize(uploadItem?.size || 0)} • ${status}`;
  }
}

// Initialize deployment steps
function initDeploymentSteps() {
  // Set up deployment steps
  STATE.deploymentSteps = [
    {
      id: 'prepare',
      title: 'Prepare Files',
      description: 'Package files for deployment',
      status: 'pending'
    },
    {
      id: 'upload',
      title: 'Upload Package',
      description: 'Transfer files to server',
      status: 'pending'
    },
    {
      id: 'extract',
      title: 'Extract Files',
      description: 'Extract files on server',
      status: 'pending'
    },
    {
      id: 'configure',
      title: 'Configure Services',
      description: 'Set up services and permissions',
      status: 'pending'
    },
    {
      id: 'verify',
      title: 'Verify Deployment',
      description: 'Ensure everything is working',
      status: 'pending'
    }
  ];
}

// Start deployment process
function startDeployment() {
  // Reset deployment state
  STATE.currentStep = 0;
  STATE.deploymentStatus = 'running';
  
  STATE.deploymentSteps.forEach(step => {
    step.status = 'pending';
  });
  
  // Update UI
  updateDeploymentStepsUI();
  
  // Disable deploy button
  const deployBtn = document.getElementById('go4it-deploy-btn');
  deployBtn.disabled = true;
  deployBtn.innerHTML = `
    <svg class="go4it-btn-icon go4it-spin" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <line x1="12" y1="2" x2="12" y2="6"></line>
      <line x1="12" y1="18" x2="12" y2="22"></line>
      <line x1="4.93" y1="4.93" x2="7.76" y2="7.76"></line>
      <line x1="16.24" y1="16.24" x2="19.07" y2="19.07"></line>
      <line x1="2" y1="12" x2="6" y2="12"></line>
      <line x1="18" y1="12" x2="22" y2="12"></line>
      <line x1="4.93" y1="19.07" x2="7.76" y2="16.24"></line>
      <line x1="16.24" y1="7.76" x2="19.07" y2="4.93"></line>
    </svg>
    Deploying...
  `;
  
  // Log deployment start
  logMessage('Starting deployment process', 'info');
  
  // Show notification
  showNotification('Deployment Started', 'Beginning deployment process. This may take a few minutes.', 'info');
  
  // Start the deployment process
  runDeploymentStep();
}

// Run the current deployment step
function runDeploymentStep() {
  if (STATE.currentStep >= STATE.deploymentSteps.length) {
    completeDeployment();
    return;
  }
  
  const currentStep = STATE.deploymentSteps[STATE.currentStep];
  currentStep.status = 'running';
  
  // Update UI
  updateDeploymentStepsUI();
  
  // Log step start
  logMessage(`Executing step ${STATE.currentStep + 1}: ${currentStep.title}`, 'info');
  
  // Simulate step execution (In a real system, this would make API calls)
  setTimeout(() => {
    // Mark step as complete and proceed to next
    currentStep.status = 'complete';
    STATE.currentStep++;
    
    // Log step completion
    logMessage(`Completed step ${STATE.currentStep}: ${currentStep.title}`, 'success');
    
    // Update UI
    updateDeploymentStepsUI();
    
    // Run next step
    runDeploymentStep();
  }, 2000); // Simulate step execution time
}

// Update deployment steps UI
function updateDeploymentStepsUI() {
  const stepsContainer = document.getElementById('go4it-deployment-steps');
  stepsContainer.innerHTML = '';
  
  STATE.deploymentSteps.forEach((step, index) => {
    const stepElement = document.createElement('div');
    stepElement.className = `go4it-step ${step.status}`;
    
    if (index === STATE.currentStep) {
      stepElement.classList.add('active');
    }
    
    stepElement.innerHTML = `
      <div class="go4it-step-indicator">
        ${step.status === 'complete' ? 
          '<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>' : 
          index + 1}
      </div>
      <div class="go4it-step-line"></div>
      <div class="go4it-step-content">
        <h3 class="go4it-step-title">${step.title}</h3>
        <p class="go4it-step-description">${step.description}</p>
      </div>
    `;
    
    stepsContainer.appendChild(stepElement);
  });
}

// Complete deployment
function completeDeployment() {
  STATE.deploymentStatus = 'success';
  
  // Enable deploy button
  const deployBtn = document.getElementById('go4it-deploy-btn');
  deployBtn.disabled = false;
  deployBtn.innerHTML = `
    <svg class="go4it-btn-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"></path>
    </svg>
    Deploy Project
  `;
  
  // Log completion
  logMessage('Deployment completed successfully!', 'success');
  
  // Show notification
  showNotification('Deployment Complete', 'Your project has been successfully deployed!', 'success');
  
  // Show "View Site" button
  const deploymentSteps = document.getElementById('go4it-deployment-steps');
  const viewSiteBtn = document.createElement('button');
  viewSiteBtn.className = 'go4it-btn go4it-btn-success';
  viewSiteBtn.style.margin = '16px auto';
  viewSiteBtn.style.display = 'block';
  viewSiteBtn.innerHTML = `
    <svg class="go4it-btn-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
      <polyline points="15 3 21 3 21 9"></polyline>
      <line x1="10" y1="14" x2="21" y2="3"></line>
    </svg>
    View Deployed Site
  `;
  
  viewSiteBtn.addEventListener('click', () => {
    window.open(CONFIG.SERVER_URL, '_blank');
  });
  
  deploymentSteps.appendChild(viewSiteBtn);
}

// Check integration status
function checkIntegrationStatus() {
  // Update File System status
  setTimeout(() => {
    updateIntegrationStatus('fileSystem', 'ok', 'Connected');
  }, 1000);
  
  // Update Monaco Editor status
  setTimeout(() => {
    updateIntegrationStatus('monaco', 'ok', 'Available');
  }, 1500);
  
  // Update StarCoder API status
  setTimeout(() => {
    updateIntegrationStatus('starCoder', 'ok', 'Running');
  }, 2000);
  
  // Update Database status
  setTimeout(() => {
    updateIntegrationStatus('database', 'ok', 'Connected');
  }, 2500);
}

// Update integration status UI
function updateIntegrationStatus(key, status, message) {
  // Update in state
  STATE.integrationStatus[key] = status;
  
  // Update in UI
  const statusItems = document.querySelectorAll('.go4it-status-item');
  const keyToIndex = {
    fileSystem: 0,
    monaco: 1,
    starCoder: 2,
    database: 3
  };
  
  const index = keyToIndex[key];
  if (typeof index !== 'undefined' && statusItems[index]) {
    const statusIcon = statusItems[index].querySelector('.go4it-status-icon');
    const statusValue = statusItems[index].querySelector('.go4it-status-value');
    
    statusIcon.className = `go4it-status-icon ${status}`;
    
    if (status === 'ok') {
      statusIcon.innerHTML = '✓';
    } else if (status === 'error') {
      statusIcon.innerHTML = '!';
    } else if (status === 'warning') {
      statusIcon.innerHTML = '⚠';
    } else {
      statusIcon.innerHTML = '?';
    }
    
    statusValue.textContent = message;
  }
}

// Refresh files list
function refreshFiles(location) {
  const container = document.getElementById(`go4it-${location}-files`);
  
  // Show loading state
  container.innerHTML = `
    <div class="go4it-loading" style="display: flex; justify-content: center; padding: 20px;">
      <svg class="go4it-spin" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <line x1="12" y1="2" x2="12" y2="6"></line>
        <line x1="12" y1="18" x2="12" y2="22"></line>
        <line x1="4.93" y1="4.93" x2="7.76" y2="7.76"></line>
        <line x1="16.24" y1="16.24" x2="19.07" y2="19.07"></line>
        <line x1="2" y1="12" x2="6" y2="12"></line>
        <line x1="18" y1="12" x2="22" y2="12"></line>
        <line x1="4.93" y1="19.07" x2="7.76" y2="16.24"></line>
        <line x1="16.24" y1="7.76" x2="19.07" y2="4.93"></line>
      </svg>
    </div>
  `;
  
  // Simulate API call to fetch files
  setTimeout(() => {
    let files = [];
    
    if (location === 'local') {
      files = [
        { name: 'client', type: 'directory', size: 0, modified: new Date() },
        { name: 'server', type: 'directory', size: 0, modified: new Date() },
        { name: 'shared', type: 'directory', size: 0, modified: new Date() },
        { name: 'package.json', type: 'file', size: 15420, modified: new Date() },
        { name: 'tsconfig.json', type: 'file', size: 4280, modified: new Date() },
        { name: 'README.md', type: 'file', size: 8560, modified: new Date() }
      ];
    } else {
      files = [
        { name: 'var', type: 'directory', size: 0, modified: new Date() },
        { name: 'www', type: 'directory', size: 0, modified: new Date() },
        { name: 'html', type: 'directory', size: 0, modified: new Date() },
        { name: 'go4itsports', type: 'directory', size: 0, modified: new Date() },
        { name: 'pharaoh', type: 'directory', size: 0, modified: new Date() }
      ];
    }
    
    // Update state
    if (location === 'local') {
      STATE.localFiles = files;
    } else {
      STATE.remoteFiles = files;
    }
    
    // Render files
    renderFiles(container, files);
  }, 800);
}

// Render files list
function renderFiles(container, files) {
  container.innerHTML = '';
  
  if (files.length === 0) {
    container.innerHTML = `
      <div style="padding: 20px; text-align: center; color: rgba(255, 255, 255, 0.4);">
        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-bottom: 10px; opacity: 0.4;">
          <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path>
          <polyline points="13 2 13 9 20 9"></polyline>
        </svg>
        <p>No files found</p>
      </div>
    `;
    return;
  }
  
  files.forEach(file => {
    const isDirectory = file.type === 'directory';
    const extension = isDirectory ? 'folder' : file.name.split('.').pop().toLowerCase();
    const typeInfo = isDirectory ? { icon: 'folder', color: CONFIG.THEME.warning } : (FILE_TYPES[extension] || FILE_TYPES.default);
    
    const fileItem = document.createElement('div');
    fileItem.className = 'go4it-file-item';
    fileItem.dataset.name = file.name;
    fileItem.dataset.type = file.type;
    
    fileItem.innerHTML = `
      <div class="go4it-file-icon" style="color: ${typeInfo.color}">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          ${getIconPath(typeInfo.icon)}
        </svg>
      </div>
      <div class="go4it-file-details">
        <div class="go4it-file-name">${file.name}</div>
        <div class="go4it-file-meta">${isDirectory ? 'Directory' : formatFileSize(file.size)} • ${formatDate(file.modified)}</div>
      </div>
      <div class="go4it-file-actions">
        ${isDirectory ? `
          <button class="go4it-panel-btn go4it-file-open">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="9 18 15 12 9 6"></polyline>
            </svg>
          </button>
        ` : `
          <button class="go4it-panel-btn go4it-file-download">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
              <polyline points="7 10 12 15 17 10"></polyline>
              <line x1="12" y1="15" x2="12" y2="3"></line>
            </svg>
          </button>
        `}
      </div>
    `;
    
    // Add click handler for selection
    fileItem.addEventListener('click', () => {
      // Toggle selection
      fileItem.classList.toggle('selected');
    });
    
    // Add action handlers
    if (isDirectory) {
      const openBtn = fileItem.querySelector('.go4it-file-open');
      if (openBtn) {
        openBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          navigateToDirectory(file.name);
        });
      }
    } else {
      const downloadBtn = fileItem.querySelector('.go4it-file-download');
      if (downloadBtn) {
        downloadBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          downloadFile(file);
        });
      }
    }
    
    container.appendChild(fileItem);
  });
}

// Navigate to directory
function navigateToDirectory(dirName) {
  logMessage(`Navigating to directory: ${dirName}`, 'info');
  showNotification('Directory Navigation', `Opening directory: ${dirName}`, 'info');
}

// Download file
function downloadFile(file) {
  logMessage(`Downloading file: ${file.name}`, 'info');
  showNotification('File Download', `Started download of: ${file.name}`, 'info');
  
  // Simulate download progress
  let progress = 0;
  const interval = setInterval(() => {
    progress += 10;
    if (progress > 100) {
      clearInterval(interval);
      logMessage(`Downloaded file: ${file.name}`, 'success');
      showNotification('Download Complete', `Successfully downloaded: ${file.name}`, 'success');
    }
  }, 300);
}

// Create new folder
function createNewFolder(location) {
  const folderName = prompt('Enter folder name:');
  if (!folderName) return;
  
  logMessage(`Creating new folder: ${folderName} in ${location} location`, 'info');
  showNotification('Folder Created', `Created new folder: ${folderName}`, 'success');
  
  // Refresh files after folder creation
  refreshFiles(location);
}

// Download selected files
function downloadSelectedFiles() {
  const selectedFiles = document.querySelectorAll('#go4it-remote-files .go4it-file-item.selected');
  if (selectedFiles.length === 0) {
    showNotification('No Files Selected', 'Please select files to download', 'warning');
    return;
  }
  
  logMessage(`Downloading ${selectedFiles.length} files`, 'info');
  showNotification('Download Started', `Downloading ${selectedFiles.length} files`, 'info');
  
  // Simulate download
  let completed = 0;
  selectedFiles.forEach((fileItem) => {
    const fileName = fileItem.dataset.name;
    
    // Simulate progress for each file
    setTimeout(() => {
      completed++;
      logMessage(`Downloaded file: ${fileName}`, 'success');
      
      if (completed === selectedFiles.length) {
        showNotification('Download Complete', `Successfully downloaded ${selectedFiles.length} files`, 'success');
        
        // Deselect all files
        selectedFiles.forEach(item => item.classList.remove('selected'));
      }
    }, Math.random() * 2000 + 500);
  });
}

// Upload selected files
function uploadSelectedFiles() {
  const selectedFiles = document.querySelectorAll('#go4it-local-files .go4it-file-item.selected');
  if (selectedFiles.length === 0) {
    // If no files selected in the file browser, check the upload queue
    if (STATE.uploadQueue.length === 0) {
      showNotification('No Files Selected', 'Please select files to upload or add files to the queue', 'warning');
      return;
    }
    
    // Upload files from queue
    uploadQueuedFiles();
    return;
  }
  
  logMessage(`Uploading ${selectedFiles.length} files`, 'info');
  showNotification('Upload Started', `Uploading ${selectedFiles.length} files`, 'info');
  
  // Simulate upload
  let completed = 0;
  selectedFiles.forEach((fileItem) => {
    const fileName = fileItem.dataset.name;
    
    // Simulate progress for each file
    setTimeout(() => {
      completed++;
      logMessage(`Uploaded file: ${fileName}`, 'success');
      
      if (completed === selectedFiles.length) {
        showNotification('Upload Complete', `Successfully uploaded ${selectedFiles.length} files`, 'success');
        
        // Deselect all files
        selectedFiles.forEach(item => item.classList.remove('selected'));
        
        // Refresh remote files
        refreshFiles('remote');
      }
    }, Math.random() * 2000 + 500);
  });
}

// Upload queued files
function uploadQueuedFiles() {
  if (STATE.uploadQueue.length === 0) {
    showNotification('Upload Queue Empty', 'No files in upload queue', 'warning');
    return;
  }
  
  logMessage(`Uploading ${STATE.uploadQueue.length} files from queue`, 'info');
  showNotification('Upload Started', `Uploading ${STATE.uploadQueue.length} files from queue`, 'info');
  
  // Process each file in queue
  let completed = 0;
  STATE.uploadQueue.forEach((item) => {
    // Mark as uploading
    updateUploadProgress(item.id, 0, 'uploading');
    
    // Simulate upload progress
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.floor(Math.random() * 10) + 5;
      if (progress > 100) progress = 100;
      
      updateUploadProgress(item.id, progress, 'uploading');
      
      if (progress === 100) {
        clearInterval(interval);
        updateUploadProgress(item.id, 100, 'complete');
        
        completed++;
        logMessage(`Uploaded file: ${item.name}`, 'success');
        
        if (completed === STATE.uploadQueue.length) {
          showNotification('Upload Complete', `Successfully uploaded ${STATE.uploadQueue.length} files`, 'success');
          
          // Clear upload queue after a delay
          setTimeout(() => {
            STATE.uploadQueue = [];
            document.getElementById('go4it-upload-queue').innerHTML = '';
          }, 2000);
          
          // Refresh remote files
          refreshFiles('remote');
        }
      }
    }, 300);
  });
}

// Show settings dialog
function showSettings() {
  logMessage('Opening settings dialog', 'info');
  showNotification('Settings', 'Settings dialog opened', 'info');
  
  // In a real application, this would show a settings dialog
  alert('Settings dialog would be shown here');
}

// Render onboarding tour
function renderTour() {
  // Create tour overlay
  const overlay = document.createElement('div');
  overlay.className = 'go4it-tour-overlay';
  overlay.id = 'go4it-tour-overlay';
  
  // Define tour steps
  const tourSteps = [
    {
      title: 'Welcome to Go4It Visual Uploader',
      description: 'This tour will guide you through the main features of the Visual Uploader and help you get started with seamless file transfers and deployments.',
      icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>`
    },
    {
      title: 'File Browser',
      description: 'The file browser shows your local (Replit) files on the left and remote (Server) files on the right. You can navigate directories, select files, and perform operations on both sides.',
      icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>`
    },
    {
      title: 'Upload Files',
      description: 'You can upload files by dragging and dropping them into the upload zone or by clicking to browse your computer. Files will be added to the upload queue where you can track their progress.',
      icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>`
    },
    {
      title: 'Deployment',
      description: 'The deployment panel shows the progress of your project deployment. You can track each step and view logs in real-time. Once deployment is complete, you can view your deployed site with one click.',
      icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"></path></svg>`
    },
    {
      title: 'Integration Status',
      description: 'The integration status shows the health of all connected systems including the file system, Monaco Editor, StarCoder AI, and database. You can quickly identify any issues and take action.',
      icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path><circle cx="12" cy="12" r="3"></circle></svg>`
    }
  ];
  
  // Initialize with first step
  let currentStep = 0;
  
  // Render first step
  renderTourStep();
  
  function renderTourStep() {
    const step = tourSteps[currentStep];
    
    overlay.innerHTML = `
      <div class="go4it-tour-card">
        <div class="go4it-tour-header">
          <div class="go4it-tour-icon">
            ${step.icon}
          </div>
          <div class="go4it-tour-title-container">
            <h2>${step.title}</h2>
            <p>Step ${currentStep + 1} of ${tourSteps.length}</p>
          </div>
        </div>
        
        <div class="go4it-tour-content">
          ${step.description}
        </div>
        
        <div class="go4it-tour-actions">
          <button class="go4it-btn" id="go4it-tour-skip">
            Skip Tour
          </button>
          
          <button class="go4it-btn go4it-btn-primary" id="go4it-tour-next">
            ${currentStep < tourSteps.length - 1 ? 'Next' : 'Finish Tour'}
          </button>
        </div>
        
        <div class="go4it-tour-dots">
          ${tourSteps.map((_, index) => `
            <div class="go4it-tour-dot ${index === currentStep ? 'active' : ''}"></div>
          `).join('')}
        </div>
      </div>
    `;
    
    // Add to document
    document.body.appendChild(overlay);
    
    // Add event listeners
    document.getElementById('go4it-tour-skip').addEventListener('click', () => {
      completeTour();
    });
    
    document.getElementById('go4it-tour-next').addEventListener('click', () => {
      if (currentStep < tourSteps.length - 1) {
        currentStep++;
        renderTourStep();
      } else {
        completeTour();
      }
    });
    
    // Animate in
    setTimeout(() => {
      overlay.style.opacity = '1';
    }, 50);
  }
  
  function completeTour() {
    // Mark tour as completed
    localStorage.setItem('go4it-tour-completed', 'true');
    
    // Remove overlay with animation
    overlay.style.opacity = '0';
    setTimeout(() => {
      overlay.remove();
    }, 300);
    
    // Show notification
    showNotification('Tour Completed', 'You can restart the tour anytime by clicking the Tour button', 'info');
  }
}

// Show notification
function showNotification(title, message, type = 'info') {
  // Create notification ID
  const id = generateId();
  
  // Add to state
  STATE.notifications.push({
    id,
    title,
    message,
    type,
    timestamp: new Date()
  });
  
  // Create notification element
  const notification = document.createElement('div');
  notification.className = 'go4it-notification';
  notification.dataset.id = id;
  
  notification.innerHTML = `
    <div class="go4it-notification-icon ${type}">
      ${type === 'success' ? 
        '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>' : 
        type === 'error' ? 
        '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>' : 
        type === 'warning' ? 
        '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>' : 
        '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>'
      }
    </div>
    <div class="go4it-notification-content">
      <div class="go4it-notification-title">${title}</div>
      <div class="go4it-notification-message">${message}</div>
    </div>
    <button class="go4it-notification-close" data-id="${id}">
      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>
    </button>
  `;
  
  // Add close handler
  notification.querySelector('.go4it-notification-close').addEventListener('click', () => {
    removeNotification(id);
  });
  
  // Add to notifications container
  const notificationsContainer = document.getElementById('go4it-notifications');
  notificationsContainer.appendChild(notification);
  
  // Auto-remove after timeout
  setTimeout(() => {
    removeNotification(id);
  }, 5000);
  
  return id;
}

// Remove notification
function removeNotification(id) {
  const notification = document.querySelector(`.go4it-notification[data-id="${id}"]`);
  if (notification) {
    notification.classList.add('exiting');
    
    setTimeout(() => {
      notification.remove();
      
      // Remove from state
      STATE.notifications = STATE.notifications.filter(n => n.id !== id);
    }, 300);
  }
}

// Log message to console
function logMessage(message, type = '') {
  const timestamp = new Date().toLocaleTimeString();
  
  // Add to state
  STATE.logs.push({
    timestamp,
    message,
    type
  });
  
  // Add to UI
  const logsContainer = document.getElementById('go4it-logs');
  
  const logEntry = document.createElement('div');
  logEntry.className = 'go4it-log-entry';
  logEntry.innerHTML = `
    <span class="go4it-log-time">${timestamp}</span>
    <span class="go4it-log-message ${type}">${message}</span>
  `;
  
  logsContainer.appendChild(logEntry);
  
  // Scroll to bottom
  logsContainer.scrollTop = logsContainer.scrollHeight;
  
  // Log to console
  if (type === 'error') {
    console.error(message);
  } else if (type === 'warning') {
    console.warn(message);
  } else if (type === 'success') {
    console.info(message);
  } else {
    console.log(message);
  }
}

// Utility functions
function formatFileSize(bytes) {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function formatDate(date) {
  if (!date) return '';
  return new Date(date).toLocaleDateString() + ' ' + new Date(date).toLocaleTimeString();
}

function getIconPath(icon) {
  switch (icon) {
    case 'folder':
      return '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>';
    case 'code':
      return '<polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline>';
    case 'file':
      return '<path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline>';
    case 'image':
      return '<rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline>';
    case 'file-text':
      return '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline>';
    case 'database':
      return '<ellipse cx="12" cy="5" rx="9" ry="3"></ellipse><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path>';
    case 'archive':
      return '<polyline points="21 8 21 21 3 21 3 8"></polyline><rect x="1" y="3" width="22" height="5"></rect><line x1="10" y1="12" x2="14" y2="12"></line>';
    default:
      return '<path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline>';
  }
}

function generateId() {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

// Initialize the visual uploader
document.addEventListener('DOMContentLoaded', initVisualUploader);

// Export functions for external use
window.Go4ItVisualUploader = {
  init: initVisualUploader,
  startDeployment,
  refreshFiles,
  uploadSelectedFiles,
  downloadSelectedFiles,
  showNotification
};